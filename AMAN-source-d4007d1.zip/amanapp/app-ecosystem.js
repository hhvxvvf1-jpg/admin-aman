/**
 * AMAN Ecosystem Module
 * Women, Girls, Child Protection, Audio Reporting, Follow-Up, Response Dashboard & Partners
 */
(function () {
  const TXT = {
    ar: {
      womenTitle: 'فضاء أمان للنساء',
      womenSub: 'مساحة آمنة وسرية لطلب المساعدة والتوجيه القانوني والاجتماعي. لستِ وحدكِ.',
      girlsTitle: 'فضاء أمان للفتيات',
      girlsSub: 'معلومات مبسطة وآمنة لمواجهة التنمر والتحرش، وطلب المساعدة من مختصين موثوقين.',
      childTitle: 'فضاء أمان للأطفال',
      childSub: 'أنتَ في أمان هنا. لا تحتاج لكتابة اسمك الكامل أو عنوانك. يمكنك التحدث أو الكتابة لطلب المساعدة.',
      childNext: 'ماذا يحدث بعد إرسال الطلب؟ سيقرأ طلبك مختص بشري مدرب لحماية الأطفال وسيوضح لك الخطوة الآمنة التالية.',
      emergencyNote: 'في حالة الخطر الفوري: الشرطة 19 · الدرك 177 · الإسعاف 15 · خط المساندة 8350',
      category: 'نوع الدعم أو الحماية',
      urgency: 'درجة الاستعجال',
      urgNormal: 'عادي',
      urgHigh: 'مستعجل',
      urgUrgent: 'خطر فوري',
      desc: 'اشرحي/اشرح ما حدث (اختياري)',
      safeContact: 'وسيلة تواصل آمنة (اختياري - فقط إذا كان ذلك آمناً)',
      city: 'المدينة (مثال: العيون)',
      recordStart: 'بدء التسجيل الصوتي',
      recordStop: 'إيقاف التسجيل',
      recordDelete: 'حذف وإعادة التسجيل',
      submitBtn: 'إرسال الطلب بسرية',
      submittedOk: 'تم استلام طلبك بنجاح. احتفظي/احتفظ برمز المتابعة:',
      followupTitle: 'متابعة حالة الطلب',
      followupPlaceholder: 'أدخلي رمز المتابعة (مثال: AMW-...)',
      followupBtn: 'تحقق من الحالة',
      partnersTitle: 'بوابة الشركاء ودليل الخدمات (العيون - المغرب)',
      responseTitle: 'لوحة التدخل المهني (AMAN Response)',
      loginBtn: 'تسجيل الدخول المهني',
      email: 'البريد المهني',
      password: 'كلمة المرور'
    },
    fr: {
      womenTitle: 'Espace AMAN Femmes',
      womenSub: 'Un espace sûr et confidentiel pour demander de l’aide et une orientation juridique et sociale.',
      girlsTitle: 'Espace AMAN Filles',
      girlsSub: 'Ressources adaptées contre le harcèlement et les violences, et accès à des professionnels de confiance.',
      childTitle: 'Espace AMAN Enfants',
      childSub: 'Tu es en sécurité ici. Tu n’es pas obligé(e) de donner ton nom complet ou ton adresse.',
      childNext: 'Que se passe-t-il après ? Un professionnel qualifié en protection de l’enfance examinera ta demande.',
      emergencyNote: 'Danger immédiat : Police 19 · Gendarmerie 177 · SAMU 15 · Ligne UNFM 8350',
      category: 'Catégorie de soutien',
      urgency: 'Niveau d’urgence',
      urgNormal: 'Normal',
      urgHigh: 'Élevé',
      urgUrgent: 'Urgence immédiate',
      desc: 'Décrivez la situation (facultatif)',
      safeContact: 'Contact sûr (facultatif - uniquement si sans danger)',
      city: 'Ville (ex: Laâyoune)',
      recordStart: 'Enregistrer un message vocal',
      recordStop: 'Arrêter l’enregistrement',
      recordDelete: 'Supprimer et réenregistrer',
      submitBtn: 'Envoyer confidentiellement',
      submittedOk: 'Demande enregistrée. Conservez votre code de suivi :',
      followupTitle: 'Suivi de demande',
      followupPlaceholder: 'Code de suivi (ex: AMW-...)',
      followupBtn: 'Vérifier le statut',
      partnersTitle: 'Portail Partenaires & Annuaire (Pilote Laâyoune)',
      responseTitle: 'Tableau de bord professionnel (AMAN Response)',
      loginBtn: 'Connexion professionnelle',
      email: 'Email professionnel',
      password: 'Mot de passe'
    },
    en: {
      womenTitle: 'AMAN Women Space',
      womenSub: 'A safe, confidential space to request support, legal guidance, and referrals.',
      girlsTitle: 'AMAN Girls Space',
      girlsSub: 'Age-appropriate resources against bullying and harassment, and access to trusted professionals.',
      childTitle: 'AMAN Child Protection',
      childSub: 'You are safe here. You do not have to share your full name or address to ask for help.',
      childNext: 'What happens next? A trained child-protection professional will review your request.',
      emergencyNote: 'Immediate danger: Police 19 · Gendarmerie 177 · Ambulance 15 · UNFM 8350',
      category: 'Support Category',
      urgency: 'Urgency Level',
      urgNormal: 'Normal',
      urgHigh: 'High',
      urgUrgent: 'Immediate Danger',
      desc: 'Describe what happened (optional)',
      safeContact: 'Safe contact (optional - only if safe)',
      city: 'City (e.g. Laâyoune)',
      recordStart: 'Start Voice Recording',
      recordStop: 'Stop Recording',
      recordDelete: 'Delete & Re-record',
      submitBtn: 'Submit Confidentially',
      submittedOk: 'Request received. Save your follow-up reference code:',
      followupTitle: 'Case Follow-Up',
      followupPlaceholder: 'Enter reference code (e.g. AMW-...)',
      followupBtn: 'Check Status',
      partnersTitle: 'Partner Portal & Services Directory (Laâyoune Pilot)',
      responseTitle: 'Professional Case Management (AMAN Response)',
      loginBtn: 'Professional Login',
      email: 'Professional Email',
      password: 'Password'
    }
  };

  function langKey() {
    const l = typeof L === 'number' ? L : 0;
    return ['ar', 'fr', 'en'][l] || 'ar';
  }
  function tr(k) {
    return (TXT[langKey()] && TXT[langKey()][k]) || TXT.ar[k] || k;
  }

  let mediaRecorder = null;
  let audioChunks = [];
  let recordedBase64 = null;
  let recordedMime = 'audio/webm';
  let recordSeconds = 0;
  let recordTimer = null;

  window.amanStartAudio = async function () {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunks = [];
      recordedBase64 = null;
      recordSeconds = 0;
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunks.push(e.data); };
      mediaRecorder.onstop = () => {
        clearInterval(recordTimer);
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunks, { type: mediaRecorder.mimeType || 'audio/webm' });
        recordedMime = blob.type || 'audio/webm';
        const reader = new FileReader();
        reader.onloadend = () => {
          recordedBase64 = String(reader.result).split(',')[1];
          const prev = document.getElementById('aman-audio-preview');
          if (prev) {
            prev.src = URL.createObjectURL(blob);
            prev.style.display = 'block';
          }
        };
        reader.readAsDataURL(blob);
      };
      mediaRecorder.start();
      recordTimer = setInterval(() => {
        recordSeconds += 1;
        const el = document.getElementById('aman-rec-time');
        if (el) el.textContent = recordSeconds + 's';
      }, 1000);
    } catch (e) {
      alert('Microphone access is required for voice reporting.');
    }
  };

  window.amanStopAudio = function () {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
    }
  };

  window.amanClearAudio = function () {
    recordedBase64 = null;
    recordSeconds = 0;
    const prev = document.getElementById('aman-audio-preview');
    if (prev) { prev.src = ''; prev.style.display = 'none'; }
    const el = document.getElementById('aman-rec-time');
    if (el) el.textContent = '0s';
  };

  window.amanSubmitReport = async function (e, group) {
    e.preventDefault();
    const f = e.target;
    const statusEl = document.getElementById('aman-report-status');
    const payload = {
      beneficiaryGroup: group,
      category: f.category.value,
      urgency: f.urgency.value,
      preferredLanguage: langKey(),
      submissionMethod: recordedBase64 ? 'audio' : 'written',
      description: f.description.value,
      safeContact: f.safeContact ? f.safeContact.value : '',
      city: f.city ? f.city.value : ''
    };

    try {
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');

      if (recordedBase64 && data.report && data.report.id) {
        const audioResult = await fetch('/api/reports/audio', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            caseId: data.report.id,
            audioUploadToken: data.report.audioUploadToken,
            base64Audio: recordedBase64,
            mimeType: recordedMime,
            durationSeconds: recordSeconds,
            language: langKey()
          })
        });
        if (!audioResult.ok) throw new Error(`${tr('submittedOk')} ${data.report.referenceCode} · Audio not received`);
      }

      statusEl.innerHTML = `<div class="card" style="border-color:var(--ac);margin-top:12px"><strong>${tr('submittedOk')}</strong> <code style="font-size:1.1em">${data.report.referenceCode}</code></div>`;
      f.reset();
      window.amanClearAudio();
    } catch (err) {
      statusEl.textContent = 'Error: ' + err.message;
    }
    return false;
  };

  function renderReportPage(group, titleKey, subKey, categories) {
    const isChild = group === 'child';
    return `
      <section class="wrap" style="max-width:760px;margin:24px auto;padding:0 16px">
        <div class="card" style="margin-bottom:16px">
          <h1 style="margin-top:0">${tr(titleKey)}</h1>
          <p>${tr(subKey)}</p>
          ${isChild ? `<p class="note">${tr('childNext')}</p>` : ''}
          <p style="font-weight:700;color:#b91c1c">${tr('emergencyNote')}</p>
        </div>
        <form class="card" onsubmit="return amanSubmitReport(event, '${group}')">
          <label>${tr('category')}</label>
          <select name="category" required style="width:100%;padding:10px;margin-bottom:12px">
            ${categories.map((c) => `<option value="${c}">${c}</option>`).join('')}
          </select>
          <label>${tr('urgency')}</label>
          <select name="urgency" style="width:100%;padding:10px;margin-bottom:12px">
            <option value="normal">${tr('urgNormal')}</option>
            <option value="high">${tr('urgHigh')}</option>
            <option value="urgent">${tr('urgUrgent')}</option>
          </select>
          <label>${tr('desc')}</label>
          <textarea name="description" rows="4" maxlength="2000" style="width:100%;padding:10px;margin-bottom:12px"></textarea>
          ${!isChild ? `<label>${tr('safeContact')}</label><input type="text" name="safeContact" maxlength="150" style="width:100%;padding:10px;margin-bottom:12px">` : ''}
          <label>${tr('city')}</label>
          <input type="text" name="city" placeholder="Laâyoune" maxlength="100" style="width:100%;padding:10px;margin-bottom:12px">
          <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:12px 0">
            <button type="button" class="btn o" onclick="amanStartAudio()">🎙️ ${tr('recordStart')}</button>
            <button type="button" class="btn o" onclick="amanStopAudio()">⏹️ ${tr('recordStop')}</button>
            <button type="button" class="btn o" onclick="amanClearAudio()">🗑️ ${tr('recordDelete')}</button>
            <span id="aman-rec-time">0s</span>
          </div>
          <audio id="aman-audio-preview" controls style="display:none;width:100%;margin-bottom:12px"></audio>
          <button type="submit" class="btn d" style="width:100%;padding:14px;font-size:1.05em">${tr('submitBtn')}</button>
          <div id="aman-report-status"></div>
        </form>
      </section>
    `;
  }

  window.amanCheckFollowUp = async function (e) {
    e.preventDefault();
    const code = e.target.refCode.value.trim();
    const out = document.getElementById('aman-followup-out');
    try {
      const res = await fetch('/api/followup/' + encodeURIComponent(code));
      const data = await res.json();
      if (!res.ok) throw new Error('Not found');
      out.innerHTML = `<div class="card" style="margin-top:12px"><p><strong>Code:</strong> ${data.followup.referenceCode}</p><p><strong>Status:</strong> <span class="tag">${data.followup.status}</span></p><p><strong>Updated:</strong> ${data.followup.updatedAt}</p></div>`;
    } catch {
      out.innerHTML = `<p style="color:#b91c1c;margin-top:10px">Reference code not found.</p>`;
    }
    return false;
  };

  window.amanLoadMap = async function () {
    const city = (document.getElementById('map-city') || {}).value || '';
    const cat = (document.getElementById('map-cat') || {}).value || '';
    const out = document.getElementById('aman-map-list');
    if (!out) return;
    try {
      const res = await fetch(`/api/directory?city=${encodeURIComponent(city)}&category=${encodeURIComponent(cat)}`);
      const data = await res.json();
      const k = langKey();
      out.innerHTML = data.organizations.length
        ? data.organizations.map((o) => `
          <div class="card" style="margin-top:10px">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px">
              <strong>${amanEsc(k === 'fr' ? o.name_fr : k === 'en' ? o.name_en : o.name_ar)}</strong>
              <span class="tag">${amanEsc(o.city)} · ${amanEsc(o.region)}</span>
            </div>
            <p style="margin:6px 0">${amanEsc(o.address || '')} · ${amanEsc(o.phone || '')}</p>
            <small>${amanEsc(o.operating_hours || '')} · ${amanEsc(o.accessibility_info || '')}</small>
            ${Number.isFinite(o.latitude) && Number.isFinite(o.longitude) ? `<div style="margin-top:8px"><a class="btn o" target="_blank" rel="noopener" href="https://www.openstreetmap.org/?mlat=${o.latitude}&mlon=${o.longitude}#map=15/${o.latitude}/${o.longitude}">${k === 'fr' ? 'Itinéraire' : k === 'en' ? 'Directions' : 'الاتجاهات'}</a></div>` : ''}
          </div>
        `).join('')
        : '<p>No verified services found for this filter.</p>';
    } catch {
      out.innerHTML = '<p>Error loading services map.</p>';
    }
  };

  window.amanLoadDirectory = async function () {
    const city = (document.getElementById('aman-dir-city') || {}).value || '';
    const out = document.getElementById('aman-dir-list');
    if (!out) return;
    try {
      const res = await fetch('/api/directory?city=' + encodeURIComponent(city));
      const data = await res.json();
      out.innerHTML = data.organizations.length
        ? data.organizations.map((o) => `
          <div class="card" style="margin-top:10px">
            <strong>${amanEsc(langKey() === 'fr' ? o.name_fr : langKey() === 'en' ? o.name_en : o.name_ar)}</strong>
            <span class="tag">${amanEsc(o.city)}</span>
            <p>${amanEsc(o.address || '')} · ${amanEsc(o.phone || '')}</p>
            <small>${amanEsc(o.operating_hours || '')} · ${amanEsc(o.accessibility_info || '')}</small>
          </div>
        `).join('')
        : '<p>No verified services found.</p>';
    } catch {
      out.innerHTML = '<p>Error loading directory.</p>';
    }
  };

  window.amanRegisterPartner = async function (e) {
    e.preventDefault();
    const f = e.target;
    const out = document.getElementById('aman-partner-status');
    try {
      const res = await fetch('/api/partners/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nameAr: f.nameAr.value,
          nameFr: f.nameFr.value,
          category: f.category.value,
          city: f.city.value,
          region: f.region.value,
          phone: f.phone.value,
          email: f.email.value
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      out.innerHTML = `<p style="color:green">Submitted for verification (ID: ${data.organization.id}).</p>`;
      f.reset();
    } catch (err) {
      out.innerHTML = `<p style="color:#b91c1c">${amanEsc(err.message)}</p>`;
    }
    return false;
  };

  window.amanPublishedResources = async (offset=0,audience='general') => {
    const target=document.getElementById('aman-published');
    if (!target) return;
    const k=langKey();
    try {
      const res=await fetch(`/api/cms?offset=${offset}&audience=${audience}`);
      if (!res.ok) throw new Error('unavailable');
      const data=await res.json();
      if (!Array.isArray(data.items)) throw new Error('unavailable');
      target.innerHTML=data.items.map(item=>`<article class="card" style="margin-top:10px"><h2>${amanEsc(item['title_'+k])}</h2>${item.image?`<img class="aman-public-illustration" src="/api/cms/images/${encodeURIComponent(item.image.id)}" alt="${amanEsc(item.image['alt_'+k])}" width="${Number(item.image.width)}" height="${Number(item.image.height)}" loading="lazy" decoding="async">`:''}<p style="white-space:pre-wrap">${amanEsc(item['body_'+k])}</p></article>`).join('') || `<p>${['لا توجد موارد منشورة بعد.','Aucune ressource publiée.','No resources have been published yet.'][L]}</p>`;
      for (const [show,next,label] of [[offset>0,offset-20,['السابق','Précédent','Previous'][L]],[data.hasMore,offset+20,['التالي','Suivant','Next'][L]]]) {
        if (!show) continue;
        const btn=document.createElement('button');btn.type='button';btn.className='btn o';btn.textContent=label;
        btn.addEventListener('click',()=>window.amanPublishedResources(next,audience));target.append(btn);
      }
    } catch {target.textContent=['الموارد غير متاحة حاليًا.','Ressources indisponibles pour le moment.','Resources are currently unavailable.'][L];}
  };

  let platformConfig;
  const applyBrand = () => {
    if (!platformConfig) return;
    const palette={purple:'',plum:'#742754',indigo:'#47368B'};
    const tone=palette[platformConfig.palette];
    if (tone) document.documentElement.style.setProperty('--ac',tone);
    else document.documentElement.style.removeProperty('--ac');
    const lang=langKey();
    const name=platformConfig[{ar:'nameAr',fr:'nameFr',en:'nameEn'}[lang]];
    if(typeof name==='string'){
      document.title=name;
      const label=document.querySelector('header .logo span');
      if(label) label.textContent=name;
    }
    const logo=document.querySelector('header .logo img');
    if(logo && ['logo.png','mark.png'].includes(platformConfig.logo))logo.src=platformConfig.logo;
    let banner=document.getElementById('aman-maintenance');
    if(platformConfig.maintenance){
      if(!banner){banner=document.createElement('div');banner.id='aman-maintenance';banner.className='aman-eco-bar';banner.setAttribute('role','status');document.querySelector('header')?.after(banner);}
      banner.textContent=['صيانة جارية. قنوات المساعدة والطوارئ تبقى متاحة.','Maintenance en cours. Les canaux d’aide et d’urgence restent accessibles.','Maintenance is in progress. Help and emergency channels remain accessible.'][L];
    }
  };
  fetch('/api/platform/config',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(cfg=>{if(cfg){platformConfig=cfg;applyBrand();}}).catch(()=>{});
  document.addEventListener('DOMContentLoaded',()=>setTimeout(applyBrand,0),{once:true});
  let langApplied=document.documentElement.lang;
  new MutationObserver(()=>{if(langApplied!==document.documentElement.lang){langApplied=document.documentElement.lang;applyBrand();}}).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});

  // Register routes into existing P object if available
  if (typeof P !== 'undefined') {
    const resourceLink=audience=>`<div class="wrap"><a class="btn o" href="#${audience}-resources">${['موارد منشورة','Ressources publiées','Published resources'][L]}</a></div>`;
    P.women = () => resourceLink('women')+renderReportPage('women', 'womenTitle', 'womenSub', ['Domestic Violence', 'Physical Violence', 'Psychological Violence', 'Economic Violence', 'Digital Harassment', 'Workplace Harassment']);
    P.girls = () => renderReportPage('girls', 'girlsTitle', 'girlsSub', ['Bullying', 'Cyberbullying', 'Harassment', 'Family Violence', 'School Violence']);
    P.child = () => resourceLink('child')+renderReportPage('child', 'childTitle', 'childSub', ['Physical Abuse', 'Psychological Abuse', 'Neglect', 'Bullying', 'Online Exploitation', 'School Violence']);
    P.followup = () => `
      <section class="wrap" style="max-width:600px;margin:24px auto;padding:0 16px">
        <div class="card">
          <h1>${tr('followupTitle')}</h1>
          <form onsubmit="return amanCheckFollowUp(event)">
            <input type="text" name="refCode" placeholder="${tr('followupPlaceholder')}" required style="width:100%;padding:10px;margin-bottom:12px">
            <button class="btn d" type="submit">${tr('followupBtn')}</button>
          </form>
          <div id="aman-followup-out"></div>
        </div>
      </section>
    `;
    P.map = () => {
      setTimeout(() => window.amanLoadMap(), 50);
      const k = langKey();
      return `
        <section class="wrap" style="max-width:900px;margin:24px auto;padding:0 16px">
          <div class="card" style="margin-bottom:16px">
            <h1 style="margin-top:0">${k === 'fr' ? 'AMAN MAP — Annuaire des services vérifiés' : k === 'en' ? 'AMAN MAP — Verified Services Directory' : 'خريطة أمان — دليل الخدمات الموثقة (العيون والمغرب)'}</h1>
            <p class="note">${k === 'fr' ? 'Confidentialité : aucune localisation de bénéficiaire ou de refuge confidentiel n’est affichée.' : k === 'en' ? 'Privacy: no beneficiary or confidential shelter locations are ever displayed.' : 'الخصوصية: لا يتم أبداً عرض مواقع المستفيدات أو الأطفال أو دور الإيواء السرية.'}</p>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
              <input id="map-city" type="text" placeholder="Laâyoune / Rabat..." value="Laâyoune" style="flex:1;min-width:160px;padding:10px">
              <select id="map-cat" style="padding:10px">
                <option value="">All Categories</option>
                <option value="women_support">Women Support</option>
                <option value="child_protection">Child Protection</option>
                <option value="ngo">NGO</option>
              </select>
              <button type="button" class="btn d" onclick="amanLoadMap()">${k === 'fr' ? 'Filtrer' : k === 'en' ? 'Filter' : 'بحث'}</button>
            </div>
            <div id="aman-map-list" style="margin-top:12px"></div>
          </div>
        </section>
      `;
    };
    P.partners = () => {
      setTimeout(() => window.amanLoadDirectory(), 50);
      return `
        <section class="wrap" style="max-width:860px;margin:24px auto;padding:0 16px">
          <div class="card" style="margin-bottom:16px">
            <h1>${tr('partnersTitle')}</h1>
            <div style="display:flex;gap:8px;margin-top:10px">
              <input id="aman-dir-city" type="text" placeholder="Laâyoune / Rabat..." style="flex:1;padding:10px">
              <button type="button" class="btn d" onclick="amanLoadDirectory()">Search</button>
            </div>
            <div id="aman-dir-list" style="margin-top:12px"></div>
          </div>
          <div class="card">
            <h2>Partner Registration (Pending Verification)</h2>
            <form onsubmit="return amanRegisterPartner(event)">
              <input name="nameAr" placeholder="Organization Name (AR)" required style="width:100%;padding:10px;margin-bottom:8px">
              <input name="nameFr" placeholder="Organization Name (FR)" required style="width:100%;padding:10px;margin-bottom:8px">
              <select name="category" style="width:100%;padding:10px;margin-bottom:8px">
                <option value="ngo">NGO</option>
                <option value="women_support">Women Support Center</option>
                <option value="child_protection">Child Protection</option>
                <option value="legal_aid">Legal Aid</option>
                <option value="health">Health Service</option>
              </select>
              <input name="city" placeholder="City (e.g. Laâyoune)" required style="width:100%;padding:10px;margin-bottom:8px">
              <input name="region" placeholder="Region" required style="width:100%;padding:10px;margin-bottom:8px">
              <input name="phone" placeholder="Phone" style="width:100%;padding:10px;margin-bottom:8px">
              <input name="email" type="email" placeholder="Official Email" style="width:100%;padding:10px;margin-bottom:8px">
              <button class="btn d" type="submit">Register Organization</button>
              <div id="aman-partner-status" style="margin-top:8px"></div>
            </form>
          </div>
        </section>
      `;
    };
    P.response = () => `<section class="wrap"><div class="card"><h1>${tr('responseTitle')}</h1><a class="btn d" href="./admin/?lang=${langKey()}">${tr('loginBtn')}</a></div></section>`;
    const resourcesPage = (audience) => {
      setTimeout(() => window.amanPublishedResources(0,audience),0);
      return `<section class="wrap"><div class="card"><h1>${['موارد منشورة','Ressources publiées','Published resources'][L]}</h1><div id="aman-published" aria-live="polite"></div></div></section>`;
    };
    P.resources=()=>resourcesPage('general');
    P['women-resources']=()=>resourcesPage('women');
    P['child-resources']=()=>resourcesPage('child');
  }
  // Remove duplicate SOS buttons even if injected dynamically later
  const dedupeSos = () => {
    const sosBtns = [...document.querySelectorAll('button, a')].filter((el) => /\bSOS\b/i.test(el.textContent || ''));
    sosBtns.slice(1).forEach((el) => el.remove());
  };
  dedupeSos();
  new MutationObserver(dedupeSos).observe(document.body, { childList: true, subtree: true });

  // Privacy & anti-screenshot/print deterrents across devices
  document.body.classList.add('aman-privacy-lock');
  document.addEventListener('contextmenu', (e) => e.preventDefault());
  document.addEventListener('keydown', (e) => {
    if (e.key === 'PrintScreen' || ((e.ctrlKey || e.metaKey) && ['p', 'P', 's', 'S'].includes(e.key))) {
      e.preventDefault();
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText('').catch(() => {});
      }
    }
  });
  document.addEventListener('visibilitychange', () => {
    document.body.style.filter = document.hidden ? 'blur(12px)' : '';
  });

  window.amanSelectAge = function (group) {
    localStorage.setItem('aman_age_group', group);
    const gate = document.getElementById('aman-onboarding-gate');
    if (gate) gate.remove();
    location.hash = group;
    if (typeof window.draw === 'function') window.draw();
  };

  if (typeof window.draw === 'function') {
    window.draw();
  }
})();
