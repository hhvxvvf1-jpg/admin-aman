/* Run from a trusted terminal. The password is read from stdin, never from argv. */
const fs = require('node:fs');
const crypto = require('node:crypto');
const { db } = require('../src/db/database');
const { registerUser } = require('../src/services/auth.service');
const { hashPassword, encryptSensitive, logAudit } = require('../src/middleware/security');
const { isStaff } = require('../src/admin/permissions');
const { encodeBase32 } = require('../src/admin/mfa');
const [action, rawEmail, role, fullName, organizationId] = process.argv.slice(2);
try {
  const email = rawEmail?.trim().toLowerCase();
  if (!email || !['create','recover'].includes(action)) throw new Error('Usage: staff.js create EMAIL ROLE NAME [ORG_ID] | staff.js recover EMAIL (password from stdin)');
  const password = fs.readFileSync(0, 'utf8').replace(/\r?\n$/, '');
  if (password.length < 14 || password.length > 128) throw new Error('Password must be 14–128 characters');
  db.exec('BEGIN IMMEDIATE');
  let user;
  if (action === 'create') {
    if (!isStaff(role)) throw new Error('A valid staff role is required');
    if (role === 'partner_admin' && (!organizationId || !db.prepare("SELECT 1 FROM organizations WHERE id=? AND review_state='verified'").get(organizationId))) throw new Error('An approved organization is required');
    user = registerUser({ email, password, role, fullName, organizationId });
  } else {
    user = db.prepare('SELECT id, role FROM users WHERE email=?').get(email);
    if (!user || !isStaff(user.role)) throw new Error('No staff account found');
    db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(hashPassword(password), user.id);
  }
  const secret = crypto.randomBytes(20);
  db.prepare('UPDATE users SET mfa_enabled=1,mfa_secret=?,mfa_last_step=-1 WHERE id=?').run(encryptSensitive(secret.toString('hex')), user.id);
  db.prepare('DELETE FROM sessions WHERE user_id=?').run(user.id);
  logAudit(action === 'create' ? 'staff_mfa_enrolled' : 'staff_access_recovered', { userId: user.id });
  db.exec('COMMIT');
  console.log(`Enroll in an authenticator privately (SHA1, 6 digits, 30 seconds): ${encodeBase32(secret)}`);
} catch (error) {
  if (db.isTransaction) db.exec('ROLLBACK');
  console.error(error.message); process.exitCode = 1;
}
