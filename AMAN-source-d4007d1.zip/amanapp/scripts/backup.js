/* Offline operator CLI. Uses an independent 256-bit key; no HTTP route handles backup contents. */
const fs=require('node:fs');
const fsp=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {Writable}=require('node:stream');
const {pipeline}=require('node:stream/promises');
const {backup,DatabaseSync}=require('node:sqlite');
const magic=Buffer.from('AMAN-SNAPSHOT-1\n');
const overhead=magic.length+12;
const allowedName=name=>typeof name==='string'&&(name==='aman.db'||/^audio\/aud_[a-f0-9-]+\.(enc|webm|ogg|mp4|mpeg|wav)$/.test(name));
const mode=0o600;
const header=(name,size)=>{const payload=Buffer.from(JSON.stringify({name,size}));const len=Buffer.alloc(4);len.writeUInt32BE(payload.length);return Buffer.concat([len,payload]);};
function result(event,bytes,database){
  database.exec('BEGIN IMMEDIATE');
  try{
    database.prepare('INSERT INTO backup_history(action,bytes) VALUES (?,?)').run(event,bytes);
    database.prepare('INSERT INTO audit_logs(action,details) VALUES (?,?)').run(event==='created'?'backup_snapshot_verified':'backup_restore_verified','{}');
    database.exec('COMMIT');
  }catch(e){database.exec('ROLLBACK');throw e;}
}
function verifyDatabase(database){
  if(database.prepare('PRAGMA quick_check').get().quick_check!=='ok')throw Error('SQLite integrity check failed');
  if(!database.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='backup_history'").get())throw Error('Unrecognized AMAN database schema');
}
function refs(database){
  return [...new Set(database.prepare('SELECT file_ref FROM audio_reports ORDER BY file_ref').all().map(r=>{
    const relative='audio/'+r.file_ref;
    if(!allowedName(relative))throw Error('Unsupported audio reference');
    return relative;
  }))];
}
async function decrypt(source,key,output){
  const fd=await fsp.open(source,'r');
  try{
    const {size}=await fd.stat();
    if(size<=overhead+16)throw Error('Unrecognized backup format');
    const prefix=Buffer.alloc(overhead), tag=Buffer.alloc(16);
    if((await fd.read(prefix,0,prefix.length,0)).bytesRead!==prefix.length || !prefix.subarray(0,magic.length).equals(magic) || (await fd.read(tag,0,16,size-16)).bytesRead!==16)throw Error('Unrecognized backup format');
    const dec=crypto.createDecipheriv('aes-256-gcm',key,prefix.subarray(magic.length));
    dec.setAAD(prefix);dec.setAuthTag(tag);
    await pipeline(fs.createReadStream(source,{fd:fd.fd,start:overhead,end:size-17,autoClose:false}),dec,output);
    return size;
  }finally{await fd.close();}
}
async function create(dest,key,stage){
  const {db}=require('../src/db/database');
  const sourceAudio=path.resolve(process.env.AMAN_AUDIO_DIR||path.join(__dirname,'..','data','audio'));
  const snapshot=path.join(stage,'aman.db');
  await backup(db,snapshot);
  const check=new DatabaseSync(snapshot,{readOnly:true});
  let files;
  try{verifyDatabase(check);files=[['aman.db',snapshot],...refs(check).map(name=>[name,path.join(sourceAudio,path.basename(name))])];}
  finally{check.close();}
  const temporary=path.join(path.dirname(dest),'.aman-backup-'+crypto.randomUUID()+'.tmp');
  const nonce=crypto.randomBytes(12);
  const prefix=Buffer.concat([magic,nonce]);
  try{
    const out=await fsp.open(temporary,'wx',mode);
    try{
      await out.writeFile(prefix);
      const cipher=crypto.createCipheriv('aes-256-gcm',key,nonce);cipher.setAAD(prefix);
      async function* payload(){
        for(const [name,file] of files){
          const st=await fsp.lstat(file);
          if(!st.isFile())throw Error('A referenced backup input is not a regular file');
          yield header(name,st.size);
          for await(const block of fs.createReadStream(file))yield block;
        }
        yield Buffer.alloc(4);
      }
      await pipeline(payload(),cipher,fs.createWriteStream(temporary,{fd:out.fd,start:prefix.length,autoClose:false}));
      const st=await out.stat();
      await out.write(cipher.getAuthTag(),0,16,st.size);
      await out.sync();
    }finally{await out.close();}
    const bytes=await decrypt(temporary,key,new Writable({write(chunk,enc,done){done();}}));
    await fsp.link(temporary,dest); // Atomic no-overwrite publication, on the same filesystem.
    result('created',bytes,db);
    console.log('Verified encrypted AMAN snapshot created.');
  }finally{await fsp.rm(temporary,{force:true});db.close();}
}
async function restore(src,dest,key,stage){
  // Finish authentication before extracting any bytes into the requested restore directory.
  const payload=path.join(stage,'verified-payload');
  const bytes=await decrypt(src,key,fs.createWriteStream(payload,{flags:'wx',mode}));
  const fd=await fsp.open(payload,'r');
  let madeTarget=false;
  try{
    const {size}=await fd.stat();
    await fsp.mkdir(dest,{mode:0o700});madeTarget=true;
    await fsp.mkdir(path.join(dest,'audio'),{mode:0o700});
    const seen=new Set();let pos=0;
    const read=async n=>{const b=Buffer.alloc(n);const {bytesRead}=await fd.read(b,0,n,pos);if(bytesRead!==n)throw Error('Incomplete backup record');pos+=n;return b;};
    for(;;){
      const len=(await read(4)).readUInt32BE();
      if(!len){if(pos!==size)throw Error('Trailing backup bytes');break;}
      if(len>512)throw Error('Invalid backup record header');
      const entry=JSON.parse((await read(len)).toString('utf8'));
      if(!entry || !allowedName(entry.name) || seen.has(entry.name) || !Number.isSafeInteger(entry.size) || entry.size<0 || entry.size>size-pos)throw Error('Invalid backup record');
      const output=path.join(dest,...entry.name.split('/'));
      if(entry.size)await pipeline(fs.createReadStream(payload,{fd:fd.fd,start:pos,end:pos+entry.size-1,autoClose:false}),fs.createWriteStream(output,{flags:'wx',mode}));
      else await fsp.writeFile(output,'',{flag:'wx',mode});
      pos+=entry.size;seen.add(entry.name);
    }
    if(!seen.has('aman.db'))throw Error('Missing SQLite snapshot');
    const database=new DatabaseSync(path.join(dest,'aman.db'));
    try{
      verifyDatabase(database);
      const expected=['aman.db',...refs(database)];
      if(seen.size!==expected.length||expected.some(name=>!seen.has(name)))throw Error('Snapshot audio does not match the database');
      database.exec('DELETE FROM sessions');
      if(database.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='staff_invitations'").get()){
        database.exec("UPDATE staff_invitations SET state='revoked',enrollment_secret=NULL,enrollment_nonce=NULL,enrollment_expires_at=NULL WHERE state='pending'");
      }
      result('restored',bytes,database);
      database.exec('PRAGMA wal_checkpoint(TRUNCATE)');
    }finally{database.close();}
    console.log('Verified AMAN snapshot restored into the new directory. Staff sessions and outstanding staff invitations were revoked.');
  }catch(e){if(madeTarget)await fsp.rm(dest,{force:true,recursive:true});throw e;}
  finally{await fd.close();}
}
async function main(){
  const [action,...args]=process.argv.slice(2);
  if(!(action==='create'&&args.length===2&&args[0]==='--offline' || action==='restore'&&args.length===2))throw Error('Usage: backup.js create --offline FILE | backup.js restore FILE NEW_DIRECTORY');
  if(!/^[a-f0-9]{64}$/i.test(process.env.AMAN_BACKUP_KEY||''))throw Error('Set AMAN_BACKUP_KEY to an independent 32-byte hex key');
  if(process.env.AMAN_BACKUP_KEY.toLowerCase()===String(process.env.AMAN_ENCRYPTION_KEY||'').toLowerCase())throw Error('Backup and application encryption keys must differ');
  const key=Buffer.from(process.env.AMAN_BACKUP_KEY,'hex');
  const stage=await fsp.mkdtemp(path.join(os.tmpdir(),'aman-backup-'));
  try{
    if(action==='create')await create(path.resolve(args[1]),key,stage);
    else await restore(path.resolve(args[0]),path.resolve(args[1]),key,stage);
  }finally{await fsp.rm(stage,{recursive:true,force:true});key.fill(0);}
}
main().catch(e=>{console.error('Backup operation failed: '+e.message);process.exitCode=1;});
