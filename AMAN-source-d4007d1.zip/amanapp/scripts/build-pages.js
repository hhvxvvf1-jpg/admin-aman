const fs = require('node:fs');
const path = require('node:path');
const { root } = require('../src/middleware/public-files');
const destination = path.resolve(process.argv[2] || 'dist/pages');
let url = '';
if (process.env.AMAN_ADMIN_URL) {
  // No client-controlled redirect and no possibility of embedding login in Pages.
  const configured = new URL(process.env.AMAN_ADMIN_URL);
  if (configured.protocol !== 'https:' || configured.username || configured.password || configured.port ||
      configured.search || configured.hash || configured.pathname !== '/admin/' || configured.hostname.endsWith('.github.io')) {
    throw new Error('AMAN_ADMIN_URL must be the official HTTPS Node host with the exact path /admin/');
  }
  url = configured.href;
}
const escape = s => s.replace(/[&<>"']/g,c=>`&#${c.charCodeAt(0)};`);
fs.mkdirSync(destination,{recursive:true});
for (const file of root) fs.copyFileSync(path.join(__dirname,'..',file),path.join(destination,file));
fs.writeFileSync(path.join(destination,'.nojekyll'),'');
// The old Pages path has an explanation, not a second copy of the admin application.
const landing = path.join(destination,'admin');
fs.mkdirSync(landing,{recursive:true});
fs.writeFileSync(path.join(landing,'index.html'),`<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>AMAN · الإدارة</title><link rel="icon" href="../mark.png"><style>
*{box-sizing:border-box} body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#f7f3fa;color:#2b193b;font:16px/1.6 system-ui,sans-serif}main{width:min(100%,580px);padding:28px 32px;border-top:5px solid #bd8a37;border-radius:14px;background:white;box-shadow:0 10px 34px #26163718}img{width:55px;height:55px}h1{font-size:28px;line-height:1.2;margin:14px 0}p{margin:12px 0}a{color:#552b77}a.open{display:inline-block;margin:12px 0;padding:8px 14px;background:#552b77;color:white;text-decoration:none;border-radius:8px}a:focus-visible{outline:3px solid #bd8a37;outline-offset:3px}
</style></head><body><main>
<img src="../mark.png" alt="AMAN"><h1>لوحة إدارة أمان</h1>
${url ? `<p>لوحة الإدارة موجودة على خادم أمان الرسمي.</p><p lang="fr" dir="ltr">L’administration est hébergée sur le serveur AMAN.</p><a class="open" href="${escape(url)}" rel="noreferrer">فتح الإدارة · Ouvrir l’administration</a>` : `<p>هذا الرابط يعرض الموقع العام فقط. لم يُربط بخادم الإدارة بعد.</p><p lang="fr" dir="ltr">Ce site public n’est pas encore relié au serveur d’administration.</p><p lang="en" dir="ltr">This public site is not yet linked to the admin server.</p>`}
<p><a href="../#home">الرجوع إلى الموقع العام · Retour au site public</a></p></main></body></html>`);
