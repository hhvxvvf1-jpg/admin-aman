# AMAN · أمان

AMAN is a Moroccan information, prevention and service-orientation platform. This branch extends its existing public PWA and Node.js / SQLite services with a staff administration panel at `/admin/`.

- [Implementation status and known gaps](ADMIN.md)
- [Local setup, staff MFA and deployment](DEPLOYMENT.md)
- [Admin API contracts](ADMIN-API.md)
- [Security review and residual risks](SECURITY_AUDIT.md)

GitHub Pages serves the static public site only. Use Node.js 22.13+ for the connected app and admin panel. Do not use real beneficiary data in this build before legal, safeguarding and security approval.
