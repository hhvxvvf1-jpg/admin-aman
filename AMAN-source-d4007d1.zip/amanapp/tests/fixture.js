const {spawn}=require('node:child_process');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {once}=require('node:events');
const {DatabaseSync}=require('node:sqlite');
const {randomBytes}=require('node:crypto');
const {totp}=require('../src/admin/mfa');
async function fixture(t){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'aman-test-'));
  const dbPath=path.join(dir,'db.sqlite');
  const audio=path.join(dir,'audio');
  const encryptionKey=randomBytes(32).toString('hex');
  const env={...process.env,NODE_ENV:'test',PORT:'0',AMAN_DB_PATH:dbPath,AMAN_AUDIO_DIR:audio,AMAN_ENCRYPTION_KEY:encryptionKey};
  const options={cwd:path.resolve(__dirname,'..'),env};
  const child=spawn(process.execPath,['server.js'],options);
  async function stop(){if(child.exitCode===null&&child.signalCode===null){const stopped=once(child,'exit');child.kill();await stopped;}}
  t.after(async()=>{await stop();fs.rmSync(dir,{recursive:true,force:true});});
  let out='';
  const base=await new Promise((resolve,reject)=>{
    child.stderr.on('data',s=>out+=s);
    child.on('error',reject);
    child.on('exit',code=>reject(new Error(`Server exited: ${code} ${out}`)));
    child.stdout.on('data',chunk=>{out+=chunk;const match=out.match(/URL: http:\/\/localhost:(\d+)/);if(match)resolve('http://127.0.0.1:'+match[1]);});
  });
  const request=async (route,method='GET',body,token)=>{
    const res=await fetch(base+route,{method,headers:{...(body!==undefined?{'Content-Type':'application/json'}:{}),...(token?{Authorization:`Bearer ${token}`}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{})});
    const type=res.headers.get('content-type')||'';
    return {status:res.status,headers:res.headers,data:type.includes('json')?await res.json():/^(audio|image\/png|application\/(pdf|vnd\.openxml))/.test(type)?Buffer.from(await res.arrayBuffer()):await res.text()};
  };
  const create=(role,opts={})=>{
    const suffix=opts.suffix || role;
    const email=`${suffix}@example.test`; const password='test-only-'+randomBytes(16).toString('hex');
    const script=`const {registerUser}=require('./src/services/auth.service'); const {db}=require('./src/db/database'); const {encryptSensitive}=require('./src/middleware/security'); const input=JSON.parse(process.argv[1]); const user=registerUser(input); if(input.secret) db.prepare('UPDATE users SET mfa_enabled=1,mfa_secret=? WHERE id=?').run(encryptSensitive(input.secret),user.id); console.log(JSON.stringify(user));`;
    const secret=randomBytes(20);
    const {status,stdout,stderr}=require('node:child_process').spawnSync(process.execPath,['-e',script,JSON.stringify({email,password,fullName:`Synthetic ${suffix}`,role,organizationId:opts.organizationId,secret:opts.noMfa?null:secret.toString('hex')})],{...options,encoding:'utf8'});
    if(status!==0)throw new Error(stderr);
    const user=JSON.parse(stdout);
    const otp=()=>totp(secret,Math.floor(Date.now()/30000));
    return {...user,password,otp,async login(){let r=await request('/api/auth/login','POST',{email,password,otp:otp()});if(r.status!==200)throw new Error(JSON.stringify(r.data));return r.data.token;}};
  };
  return {base,request,create,audio,stop,dir,env,openDb:()=>new DatabaseSync(dbPath)};
}
module.exports={fixture};
