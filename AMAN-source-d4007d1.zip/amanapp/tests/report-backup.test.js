const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
const {randomBytes}=require('node:crypto');
const {DatabaseSync}=require('node:sqlite');
const {inflateRawSync,crc32}=require('node:zlib');
const {fixture}=require('./fixture');
function workbookFiles(bytes){
  let i=0;const files={};
  while(bytes.readUInt32LE(i)===0x04034b50){
    const length=bytes.readUInt32LE(i+18),size=bytes.readUInt16LE(i+26),extra=bytes.readUInt16LE(i+28);
    const name=bytes.subarray(i+30,i+30+size).toString(),data=inflateRawSync(bytes.subarray(i+30+size+extra,i+30+size+extra+length));
    assert.equal(crc32(data),bytes.readUInt32LE(i+14));files[name]=data.toString();i+=30+size+extra+length;
  }
  assert.equal(bytes.readUInt32LE(i),0x02014b50);return files;
}
function verifyPDF(bytes){
  const data=bytes.toString('ascii');
  assert.match(data,/^%PDF-1.4/);
  const xref=Number(data.match(/startxref\n(\d+)\n%%EOF/)[1]);assert.equal(data.slice(xref,xref+4),'xref');
  assert.match(data,/\/Type \/Page\b/);
  return data;
}
test('authorized activity and finance exports return valid file structures and preserve privacy',async t=>{
  const {request,create}=await fixture(t);
  const admin=await create('super_admin').login(), worker=await create('girls_caseworker').login();
  await request('/api/reports','POST',{beneficiaryGroup:'girls',description:'Synthetic private narrative'});
  for(const suffix of ['xlsx','pdf'])assert.equal((await request(`/api/admin/analytics/${suffix}`,'GET',undefined,worker)).status,403);
  const a=await request('/api/admin/analytics/xlsx?range=week','GET',undefined,admin);
  assert.equal(a.status,200);assert.match(a.headers.get('content-disposition'),/aman-activity.xlsx/);
  const activity=workbookFiles(a.data);
  assert.match(activity['xl/workbook.xml'],/Registrations/);assert.match(activity['xl/worksheets/sheet1.xml'],/&lt;5/);
  assert.doesNotMatch(Object.values(activity).join(''),/private narrative/);
  const pdf=await request('/api/admin/analytics/pdf?range=month','GET',undefined,admin);
  assert.match(verifyPDF(pdf.data),/Page 1 of 2/);
  const d=(await request('/api/admin/finance','POST',{kind:'expense',label:'=لا يُنفّذ',project:'Synthetic private project',amount:'12.75',entryDate:'2026-04-02'},admin)).data;
  await request(`/api/admin/finance/${d.id}/workflow`,'POST',{action:'post',revision:d.revision},admin);
  const excel=workbookFiles((await request('/api/admin/finance/xlsx','GET',undefined,admin)).data);
  assert.match(excel['xl/worksheets/sheet1.xml'],/=لا يُنفّذ/);
  assert.doesNotMatch(excel['xl/worksheets/sheet1.xml'],/<f[> ]/);
  const f=verifyPDF((await request('/api/admin/finance/pdf','GET',undefined,admin)).data);
  assert.match(f,/12\.75/);assert.doesNotMatch(f,/Synthetic private project/);
});

test('offline snapshot encrypts database and audio; restore authenticates, revokes sessions and records health',async t=>{
  const fx=await fixture(t);
  const token=await fx.create('super_admin').login();
  const {data:{report}}=await fx.request('/api/reports','POST',{beneficiaryGroup:'girls',submissionMethod:'audio',description:'Synthetic backup verification'});
  const syntheticAudio=Buffer.from('RIFF0000WAVE synthetic backup');
  assert.equal((await fx.request('/api/reports/audio','POST',{caseId:report.id,audioUploadToken:report.audioUploadToken,base64Audio:syntheticAudio.toString('base64'),mimeType:'audio/wav'})).status,201);
  assert.equal((await fx.request('/api/admin/dashboard','GET',undefined,token)).data.health.backup,null);
  const pending=await fx.request('/api/admin/staff-invitations','POST',{email:'backup-test@example.test',fullName:'Synthetic Operator',role:'tech_support'},token);assert.equal(pending.status,201);
  await fx.stop();
  const key=randomBytes(32).toString('hex'), out=path.join(fx.dir,'vault.aman'), dest=path.join(fx.dir,'verified-restore');
  const run=(args,backupKey=key)=>spawnSync(process.execPath,['scripts/backup.js',...args],{cwd:path.join(__dirname,'..'),env:{...fx.env,AMAN_BACKUP_KEY:backupKey},timeout:6000,encoding:'utf8'});
  assert.notEqual(run(['create',out]).status,0);
  const created=run(['create','--offline',out]);assert.equal(created.status,0,created.stderr);
  assert.doesNotMatch(fs.readFileSync(out).toString('latin1'),/SQLite format 3|Synthetic backup verification/);
  const live=fx.openDb();assert.equal(live.prepare('SELECT action FROM backup_history').get().action,'created');live.close();
  assert.notEqual(run(['create','--offline',out]).status,0);
  assert.notEqual(run(['restore',out,dest],randomBytes(32).toString('hex')).status,0);assert.equal(fs.existsSync(dest),false);
  const corrupt=path.join(fx.dir,'corrupt.aman'), damaged=fs.readFileSync(out);damaged[damaged.length-20]^=1;fs.writeFileSync(corrupt,damaged);
  assert.notEqual(run(['restore',corrupt,dest]).status,0);assert.equal(fs.existsSync(dest),false);
  const result=run(['restore',out,dest]);assert.equal(result.status,0,result.stderr);
  assert.notEqual(run(['restore',out,dest]).status,0);
  const db=new DatabaseSync(path.join(dest,'aman.db'));assert.equal(db.prepare('SELECT count(*) n FROM sessions').get().n,0);
  assert.equal(db.prepare('SELECT id FROM help_requests').get().id,report.id);
  assert.equal(db.prepare('SELECT state FROM staff_invitations WHERE id=?').get(pending.data.id).state,'revoked');
  assert.equal(db.prepare('SELECT action FROM backup_history ORDER BY id DESC').get().action,'restored');
  const file=db.prepare('SELECT file_ref FROM audio_reports').get().file_ref;db.close();
  assert.deepEqual(fs.readFileSync(path.join(dest,'audio',file)),fs.readFileSync(path.join(fx.audio,file)));
});

test('quiz workflow enforces review, full age band, and server-side feedback without logging answers',async t=>{
  const {request,create,openDb}=await fixture(t);
  const writer=await create('content_manager').login(), supervisor=await create('super_admin').login(), worker=await create('girls_caseworker').login();
  const api=(p,m='GET',body,token=supervisor)=>request('/api/admin/'+p,m,body,token);
  const inputs={minAge:16,maxAge:17,correct:'b',...Object.fromEntries(['Ar','Fr','En'].flatMap(l=>[['question'+l,'Synthetic quiz question '+l],['feedback'+l,'Synthetic quiz correct '+l],['aLabel'+l,'Synthetic A '+l],['bLabel'+l,'Synthetic B '+l]]))};
  const older=()=>request('/api/girls/quizzes?ageGroup=16-17');
  assert.equal((await api('quizzes','GET',undefined,worker)).status,403);
  assert.equal((await api('quizzes','POST',{...inputs,minAge:17},writer)).status,400);
  const {data:created}=await api('quizzes','POST',inputs,writer);
  assert.ok(created.id);
  const workflow=`quizzes/${created.id}/workflow`;
  assert.equal((await older()).data.quizzes.some(q=>q.id===created.id),false);
  const {data:review}=await api(workflow,'POST',{action:'submit',revision:created.revision},writer);
  assert.equal((await api(workflow,'POST',{action:'publish',revision:review.revision},writer)).status,403);
  const {data:published}=await api(workflow,'POST',{action:'publish',revision:review.revision});
  const preview=(await older()).data.quizzes.find(q=>q.id===created.id);
  assert.equal(preview.questionEn,'Synthetic quiz question En');
  assert.equal(preview.feedbackEn,undefined);assert.ok(preview.options.every(x=>!Object.hasOwn(x,'correct')));
  assert.equal((await request('/api/girls/quizzes?ageGroup=13-15')).data.quizzes.some(q=>q.id===created.id),false);
  const answer=(ageGroup,option)=>request(`/api/girls/quizzes/${created.id}/answer`,'POST',{ageGroup,option,language:'en'});
  assert.equal((await answer('13-15','b')).status,404);
  assert.deepEqual((await answer('16-17','a')).data,{correct:false,feedback:'Try another answer.'});
  assert.deepEqual((await answer('16-17','b')).data,{correct:true,feedback:'Synthetic quiz correct En'});
  const db=openDb();assert.equal(db.prepare("SELECT count(*) n FROM audit_logs WHERE action LIKE '%answer%'").get().n,0);db.close();
  assert.equal((await api(workflow,'POST',{action:'unpublish',revision:published.revision})).status,200);
  assert.equal((await answer('16-17','b')).status,404);
});
