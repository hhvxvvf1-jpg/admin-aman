const {crc32,deflateSync}=require('node:zlib');
const signature=Buffer.from([137,80,78,71,13,10,26,10]);
function chunk(label,content){
  const marker=Buffer.from(label),length=Buffer.alloc(4),checksum=Buffer.alloc(4);
  length.writeUInt32BE(content.length);checksum.writeUInt32BE(crc32(Buffer.concat([marker,content])));
  return Buffer.concat([length,marker,content,checksum]);
}
function picture({width=4,height=2,filter=0}={}){
  const header=Buffer.alloc(13);header.writeUInt32BE(width);header.writeUInt32BE(height,4);header[8]=8;header[9]=2;
  const pixels=Buffer.alloc((width*3+1)*height);for(let i=0;i<height;i++){pixels[i*(width*3+1)]=filter;pixels.fill(120,i*(width*3+1)+1,(i+1)*(width*3+1));}
  return Buffer.concat([signature,chunk('IHDR',header),chunk('tEXt',Buffer.from('Author\0Do not preserve this metadata')),chunk('IDAT',deflateSync(pixels)),chunk('IEND',Buffer.alloc(0))]);
}
module.exports={picture};
