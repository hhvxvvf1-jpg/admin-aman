const staffInvitations=require('./src/services/staff-invitations.service');
/**
 * AMAN · أمان - Production Server
 * Clean Architecture: Native SQLite (node:sqlite), Security Middleware, Services Layer
 * Platform for Prevention of Violence Against Women in Morocco
 */

const http = require('node:http');
const { isIP } = require('node:net');
const fs = require('node:fs');
const path = require('node:path');
const url = require('node:url');
const zlib = require('node:zlib');

// Services & Database
const { db } = require('./src/db/database');
const communityService = require('./src/services/community.service');
const aiService = require('./src/services/ai.service');
const ops = require('./src/services/operations.service');
const authService = require('./src/services/auth.service');
const casesService = require('./src/services/cases.service');
const partnersService = require('./src/services/partners.service');
const analyticsService = require('./src/services/analytics.service');
const cmsImages=require('./src/services/cms-images.service');
const cmsService = require('./src/services/cms.service');
const girlsService = require('./src/services/girls.service');
const quizzes = require('./src/services/quizzes.service');
const security = require('./src/middleware/security');
const { routeAdmin, flagPublic } = require('./src/admin/routes');
const { AdminError, text: validateText } = require('./src/admin/shared');
const { publicPath } = require('./src/middleware/public-files');

function readBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size <= maxBytes) chunks.push(chunk);
      else if (size - chunk.length <= maxBytes) {
        const error = new Error('Payload too large'); error.status = 413; reject(error);
      }
    });
    req.on('end', () => { if (size <= maxBytes) resolve(Buffer.concat(chunks).toString('utf8')); });
    req.on('error', reject);
    req.on('aborted', () => reject(new Error('Request aborted')));
  });
}
async function readJsonBody(req, maxBytes = 15 * 1024 * 1024) {
  const payload = JSON.parse(await readBody(req,maxBytes) || '{}');
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new AdminError(400,'invalid_input');
  return payload;
}

function sendJson(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = __dirname;

// MIME Types
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8'
};

/**
 * Main HTTP Request Dispatcher
 */
const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname || '/';
  const method = req.method.toUpperCase();
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',').at(-1).trim();
  const clientIp = process.env.AMAN_TRUST_PROXY === '1' && isIP(forwarded) ? forwarded : req.socket.remoteAddress || 'unknown';

  // Apply Security Headers
  security.applySecurityHeaders(res);

  if (method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (pathname.startsWith('/api/')) res.setHeader('Cache-Control','no-store');
  const send = (status, data) => sendJson(res, status, data);
  const sendError = (error, status = 400) => send(error instanceof AdminError ? error.status : error.status || status, {error:error instanceof AdminError ? error.message : error.status===413 ? 'payload_too_large' : 'request_failed'});
  try {
  if (pathname === '/api/admin' || pathname.startsWith('/api/admin/')) {
    return await routeAdmin({req,res,pathname,method,query:parsedUrl.query,read:readJsonBody,send,clientIp});
  }
  if (pathname==='/api/platform/config' && method==='GET') return send(200,ops.publicConfig());
  if (method==='POST' && ['/api/community/publish','/api/community/posts','/api/community/comments','/api/community/like'].includes(pathname) && ops.publicConfig().maintenance) {
    return send(503,{error:'maintenance_mode'});
  }
  if (pathname === '/api/community/flags' && method === 'POST') {
    if (!security.checkRateLimit(`flags:${clientIp}`,12,60_000)) return send(429,{error:'rate_limited'});
    flagPublic(await readJsonBody(req,4096));
    return send(201,{success:true});
  }
  // --- API: CHAT (AI COUNSELING) ---
  if (pathname === '/api/chat' && method === 'POST') {
    if (!security.checkRateLimit(`chat:${clientIp}`,40,60_000)) return send(429,{error:'rate_limited'});
    const payload = await readJsonBody(req,128*1024);
    const userMsg = security.sanitizeText(payload.message).slice(0,10000);
    const replyLang = typeof payload.replyLang==='string' ? payload.replyLang : 'auto';
    const uiLang = ['ar','fr','en'].includes(payload.uiLang) ? payload.uiLang : 'ar';
    let result;
    try { result=aiService.configuredReply({message:userMsg,replyLang,uiLang}); }
    catch (error) {
      // No user inputs or file contents are logged.
      try { ops.aiRun('error'); } catch {}
      throw error;
    }
    try { ops.aiRun(result.outcome); } catch { /* counters cannot block emergency guidance */ }
    if (result.outcome==='unavailable') return send(503,{error:'assistant_unavailable'});
    return send(200,{success:true,reply:result.reply,language:result.language,sources:result.sources});
  }

  // --- API: COMMUNITY SESSION ---
  if (pathname === '/api/community/session' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({
      user: {
        id: 'usr_guest',
        name: 'مشاركة (هوية محفوظة)',
        verified: false,
        kind: 'person'
      }
    }));
    return;
  }

  // --- API: COMMUNITY FEED & POSTS ---
  if (method === 'GET' && ['/api/community/feed','/api/community/mine','/api/community/posts'].includes(pathname)) {
    const category = validateText(parsedUrl.query.category || '',100);
    const search = validateText(parsedUrl.query.q || '',120);
    const page = parseInt(parsedUrl.query.page, 10) || 0;

    const posts = communityService.getFeed({ category, search, page });
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ posts, total: posts.length, page }));
    return;
  }

  // --- API: COMMUNITY PUBLISH & POST CREATE ---
  if ((pathname === '/api/community/publish' || pathname === '/api/community/posts') && method === 'POST') {
    if (!security.checkRateLimit(`post:${clientIp}`,20,60_000)) return send(429,{error:'rate_limited'});
    const max=6*1024*1024;
    let data;
    if (req.headers['content-type']?.includes('application/json')) data=await readJsonBody(req,max);
    else {
      const body=await readBody(req,max);
      data={title:(body.match(/name="title"[\r\n]+([^\r\n]+)/)?.[1]||'').trim(),body:(body.match(/name="body"[\r\n]+([^\r\n]+)/)?.[1]||'').trim(),category:(body.match(/name="category"[\r\n]+([^\r\n]+)/)?.[1]||'general').trim()};
    }
    const post=communityService.createPost({
      authorName:security.sanitizeText(data.author).slice(0,160),isAnonymous:data.isAnonymous!==false,
      category:security.sanitizeText(data.category).slice(0,100)||'general',
      title:security.sanitizeText(data.title).slice(0,200),body:security.sanitizeText(data.body).slice(0,10000),
      imageUrl:typeof data.image==='string' && /^data:image\/(png|jpeg|webp|gif);base64,[\w+/]+=*$/i.test(data.image) ? data.image : null
    });
    security.logAudit('post_created',{id:post.id},clientIp);
    return send(200,{success:true,post});
  }
  if (pathname === '/api/community/like' && method === 'POST') {
    if (!security.checkRateLimit(`like:${clientIp}`,60,60_000)) return send(429,{error:'rate_limited'});
    const {id}=await readJsonBody(req,4096);
    return send(200,communityService.toggleLike(validateText(id,80,1),clientIp));
  }
  if (pathname === '/api/community/comments' && method === 'GET') {
    const comments=db.prepare('SELECT id, author_name AS author, text, is_anonymous, created_at FROM comments WHERE post_id=? AND hidden=0 AND EXISTS(SELECT 1 FROM posts WHERE posts.id=comments.post_id AND posts.hidden=0) ORDER BY created_at ASC LIMIT 200').all(validateText(parsedUrl.query.post || '',80));
    return send(200,{comments});
  }
  if (pathname === '/api/community/comments' && method === 'POST') {
    if (!security.checkRateLimit(`comment:${clientIp}`,25,60_000)) return send(429,{error:'rate_limited'});
    const {postId,text,author}=await readJsonBody(req,8192);
    const comment=communityService.addComment(validateText(postId,80,1),{authorName:security.sanitizeText(author).slice(0,160),text:validateText(security.sanitizeText(text),1000,1),isAnonymous:true});
    return send(200,{success:true,comment});
  }
  if (pathname === '/api/community/read' && method === 'POST') {
    const {id,mode}=await readJsonBody(req,4096);
    const post=db.prepare('SELECT title,body FROM posts WHERE id=? AND hidden=0').get(validateText(id,80,1));
    if (!post) return send(404,{error:'not_found'});
    let text;
    if (mode === 'summary') {
      text = `خلاصة الموضوع: ${post.title}. النقطة الأساسية هي معرفة الإجراءات الوقائية، الشهادة الطبية من المستشفى، والاتصال بالأرقام المعتمدة (19 / 177 / 8350).`;
    } else if (mode === 'simple') {
      text = `توضيح مسطري مبسط: في حال التعرض لأي ضرر، القانون المغربي يتيح لكِ الحماية الفورية. الخطوة الأولى فحص طبي والحصول على شهادة عجز، ثم التوجه للدائرة الأمنية أو مصالح الدرك أو الاتصال بخط 8350.`;
    } else if (mode === 'explain') {
      text = `المصطلحات القانونية المعتمدة:\n• القانون 103-13: الإطار القانوني المغربي لمحاربة العنف ضد النساء وتخويل وكيل الملك تدابير الطرد والحماية.\n• طلاق الشقاق: مسطرة يختص بها قسم قضاء الأسرة وتمنح الحقوق الثابتة للزوجة والأبناء دون اشتراط موافقة الزوج.\n• مدة العجز (ITT): تقدير الضرر البدني المثبت بشهادة طبية معتمدة.`;
    } else {
      text = post.body;
    }
    return send(200,{success:true,text});
  }

  if (pathname==='/api/staff-enrollment/begin'||pathname==='/api/staff-enrollment/redeem') {
    if(method!=='POST')return send(404,{error:'not_found'});
    if(!security.checkRateLimit(`staff-enrollment:${clientIp}`,16,60_000))return send(429,{error:'rate_limited'});
    if(!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type']||''))return send(415,{error:'json_required'});
    const input=await readJsonBody(req,4096);
    if(!input||Array.isArray(input)||typeof input!=='object')return send(400,{error:'invalid_input'});
    const beginning=pathname.endsWith('/begin');
    return send(beginning?200:201,beginning?staffInvitations.begin(input):staffInvitations.redeem(input));
  }

  // --- API: AUTHENTICATION ---
  if (pathname === '/api/auth/login' && method === 'POST') {
    if (!security.checkRateLimit(`auth-ip:${clientIp}`, 15, 60000)) {
      return sendJson(res, 429, { error: 'rate_limited' });
    }
    try {
      const payload = await readJsonBody(req,4096);
      const result = authService.login({ email: payload.email, password: payload.password, otp: payload.otp, ipAddress: clientIp });
      return sendJson(res, 200, { success: true, ...result });
    } catch (err) {
      return send(err.message==='rate_limited'?429:err.status===413?413:401,{error:err.message==='rate_limited'?'rate_limited':'invalid_credentials_or_code'});
    }
  }

  if (pathname === '/api/auth/me' && method === 'GET') {
    const user = authService.getSessionUser(req);
    if (!user) return sendJson(res, 401, { error: 'unauthorized' });
    return sendJson(res, 200, { user });
  }

  if (pathname === '/api/auth/logout' && method === 'POST') {
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
    authService.logout(token,authService.getSessionUser(req)?.id);
    return sendJson(res, 200, { success: true });
  }

  // A production deployment starts without live intake until the operator explicitly enables it.
  if (method==='POST' && ['/api/reports','/api/reports/audio','/api/girls/specialist-request'].includes(pathname)
      && process.env.NODE_ENV==='production' && process.env.AMAN_SENSITIVE_INTAKE!=='1') {
    return send(503,{error:'intake_unavailable'});
  }

  // --- API: HELP REQUESTS & AUDIO REPORTING ---
  if (pathname === '/api/reports' && method === 'POST') {
    if (!security.checkRateLimit(`report:${clientIp}`, 20, 60000)) {
      return sendJson(res, 429, { error: 'rate_limited' });
    }
    try {
      const payload = await readJsonBody(req,64*1024);
      const result = casesService.submitHelpRequest(payload);
      return sendJson(res, 201, { success: true, report: result });
    } catch (err) {
      return sendError(err);
    }
  }

  if (pathname === '/api/reports/audio' && method === 'POST') {
    if (!security.checkRateLimit(`${pathname}:${clientIp}`, 10, 60000)) {
      return sendJson(res, 429, { error: 'rate_limited' });
    }
    try {
      const payload = await readJsonBody(req);
      const result = casesService.saveAudioReport(payload);
      return sendJson(res, 201, { success: true, audio: result });
    } catch (err) {
      return sendError(err);
    }
  }

  if (pathname.startsWith('/api/followup/') && method === 'GET') {
    if (!security.checkRateLimit(`followup:${clientIp}`,30,60_000)) return send(429,{error:'rate_limited'});
    const refCode = decodeURIComponent(pathname.slice('/api/followup/'.length));
    const status = casesService.getPublicFollowUp(refCode);
    if (!status) return sendJson(res, 404, { error: 'not_found' });
    return sendJson(res, 200, { success: true, followup: status });
  }

  // --- API: PROFESSIONAL CASE MANAGEMENT (RBAC) ---
  if (pathname === '/api/cases' && method === 'GET') {
    const user = authService.getSessionUser(req);
    if (!user) return sendJson(res, 401, { error: 'unauthorized' });
    try {
      const cases = casesService.listCasesForUser(user, {
        status: parsedUrl.query.status || '',
        group: parsedUrl.query.group || ''
      });
      return sendJson(res, 200, { success: true, cases });
    } catch (err) {
      return sendError(err,403);
    }
  }

  if (pathname.startsWith('/api/cases/') && pathname.endsWith('/status') && method === 'PATCH') {
    const user = authService.getSessionUser(req);
    if (!user) return sendJson(res, 401, { error: 'unauthorized' });
    const caseId = pathname.split('/')[3];
    try {
      const payload = await readJsonBody(req);
      const updated = casesService.updateCaseStatus(user, caseId, payload);
      return sendJson(res, 200, { success: true, case: updated });
    } catch (err) {
      return sendError(err);
    }
  }

  if (pathname.startsWith('/api/cases/') && pathname.endsWith('/notes') && method === 'POST') {
    const user = authService.getSessionUser(req);
    if (!user) return sendJson(res, 401, { error: 'unauthorized' });
    const caseId = pathname.split('/')[3];
    try {
      const payload = await readJsonBody(req);
      const note = casesService.addCaseNote(user, caseId, payload);
      return sendJson(res, 201, { success: true, note });
    } catch (err) {
      return sendError(err);
    }
  }

  if (pathname.startsWith('/api/cases/') && pathname.endsWith('/redact') && method === 'DELETE') {
    const user = authService.getSessionUser(req);
    if (!user) return sendJson(res, 401, { error: 'unauthorized' });
    const caseId = pathname.split('/')[3];
    try {
      const result = casesService.redactCaseData(user, caseId);
      return sendJson(res, 200, result);
    } catch (err) {
      return sendError(err,404);
    }
  }

  if (pathname.startsWith('/api/audio/') && method === 'GET') {
    const user = authService.getSessionUser(req);
    if (!user) return sendJson(res, 401, { error: 'unauthorized' });
    const audioId = pathname.slice('/api/audio/'.length);
    try {
      const { buffer, mimeType } = casesService.getAudioFileForUser(user, audioId);
      res.writeHead(200, { 'Content-Type': mimeType, 'Cache-Control': 'no-store' });
      return res.end(buffer);
    } catch (err) {
      return sendError(err,404);
    }
  }

  // --- API: DIRECTORY & PARTNERS ---
  if (pathname === '/api/directory' && method === 'GET') {
    const orgs = partnersService.listDirectory({
      region: parsedUrl.query.region || '',
      category: parsedUrl.query.category || '',
      city: parsedUrl.query.city || ''
    });
    return sendJson(res, 200, { success: true, organizations: orgs });
  }

  if (pathname === '/api/partners/register' && method === 'POST') {
    if (!security.checkRateLimit(`${pathname}:${clientIp}`, 10, 60000)) {
      return sendJson(res, 429, { error: 'rate_limited' });
    }
    try {
      const payload = await readJsonBody(req);
      const org = partnersService.registerPartner(payload);
      return sendJson(res, 201, { success: true, organization: org });
    } catch (err) {
      return sendError(err);
    }
  }

  if (pathname === '/api/referrals' && method === 'POST') {
    const user = authService.getSessionUser(req);
    if (!user) return sendJson(res, 401, { error: 'unauthorized' });
    try {
      const payload = await readJsonBody(req);
      const ref = partnersService.createReferral(user, payload);
      return sendJson(res, 201, { success: true, referral: ref });
    } catch (err) {
      return sendError(err);
    }
  }

  if (pathname === '/api/analytics' && method === 'GET') {
    const user = authService.getSessionUser(req);
    if (!user) return sendJson(res, 401, { error: 'unauthorized' });
    try {
      const stats = analyticsService.getAggregatedStats(user);
      return sendJson(res, 200, { success: true, stats });
    } catch (err) {
      return sendError(err,403);
    }
  }

  // --- API: CMS & LEGAL RESOURCES ---
  const cmsImageRoute=/^\/api\/cms\/images\/(image_[0-9a-f-]{36})$/.exec(pathname);
  if(cmsImageRoute&&method==='GET')return cmsImages.publicImage(res,cmsImageRoute[1]);
  if (pathname === '/api/cms' && method === 'GET') {
    const result = cmsService.listContent({type:parsedUrl.query.type || '', offset:parsedUrl.query.offset || 0,audience:parsedUrl.query.audience || 'general'});
    return send(200,{success:true,...result});
  }

  // --- API: AMAN GIRLS ---
  if (pathname === '/api/girls/library' && method === 'GET') {
    const items = girlsService.getLibrary({
      ageGroup: parsedUrl.query.ageGroup || '',
      category: parsedUrl.query.category || '',
      q: parsedUrl.query.q || ''
    });
    return sendJson(res, 200, { success: true, items });
  }

  if (pathname.startsWith('/api/girls/content/') && method === 'GET') {
    const id = pathname.slice('/api/girls/content/'.length);
    const result = girlsService.getContentById(id, parsedUrl.query.ageGroup || '');
    if (result.status !== 200) {
      return sendJson(res, result.status, { error: result.error });
    }
    return sendJson(res, 200, { success: true, item: result.item });
  }

  if (pathname === '/api/girls/quizzes' && method === 'GET') {
    return sendJson(res, 200, {
      success: true,
      quizzes: quizzes.publicQuizzes(parsedUrl.query.ageGroup || '')
    });
  }

  const quizAnswer=/^\/api\/girls\/quizzes\/([a-z0-9_-]{1,80})\/answer$/.exec(pathname);
  if (quizAnswer && method==='POST') {
    if (!security.checkRateLimit(`quiz:${clientIp}`,60,60_000)) return send(429,{error:'rate_limited'});
    return send(200,quizzes.answer(quizAnswer[1],await readJsonBody(req,4096)));
  }

  if (pathname === '/api/girls/specialist-request' && method === 'POST') {
    if (!security.checkRateLimit(clientIp, 15, 60000)) {
      return sendJson(res, 429, { error: 'rate_limited' });
    }
    try {
      const payload = await readJsonBody(req);
      const report = girlsService.requestSpecialistChat(payload);
      return sendJson(res, 201, {
        success: true,
        report,
        availability: 'Mon-Fri 08:30-16:30 (Pilot) · Emergency: 19 / 177 / 8350'
      });
    } catch (err) {
      return sendError(err);
    }
  }

  // --- API: HEALTH CHECK ---
  if (pathname === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({
      status: 'ok',
      service: 'AMAN Institutional Platform',
      database: 'SQLite 3 (WAL mode)',
      uptime: process.uptime(),
      time: new Date().toISOString()
    }));
    return;
  }

  // --- STATIC FILE SERVING ---
  const safePath = publicPath(pathname);
  if (!safePath || !['GET','HEAD'].includes(method)) return send(404,{error:'not_found'});
  const filePath = path.join(PUBLIC_DIR,safePath);
  fs.stat(filePath,(err,stats)=>{
    if (err || !stats.isFile()) return send(404,{error:'not_found'});
    if (safePath.startsWith('admin/')) {
      res.setHeader('Cache-Control','no-store');
      res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' blob:; media-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'self'");
    }
    if (method==='HEAD') {res.setHeader('Content-Type',MIME_TYPES[path.extname(filePath)]||'application/octet-stream');return res.end();}
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    if (safePath.startsWith('admin/')) { /* no-store above */ }
    else if (ext === '.html') {
      res.setHeader('Cache-Control', 'no-cache');
    } else if (['.js', '.css'].includes(ext)) {
      res.setHeader('Cache-Control', 'public, max-age=3600');
    } else if (['.png', '.jpg', '.jpeg', '.svg', '.woff2'].includes(ext)) {
      res.setHeader('Cache-Control', 'public, max-age=86400');
    }

    const acceptEncoding = req.headers['accept-encoding'] || '';
    const isCompressible = ['.html', '.js', '.css', '.json'].includes(ext);
    if (isCompressible && acceptEncoding.includes('gzip')) {
      res.writeHead(200, { 'Content-Type': contentType, 'Content-Encoding': 'gzip' });
      fs.createReadStream(filePath).pipe(zlib.createGzip()).pipe(res);
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      fs.createReadStream(filePath).pipe(res);
    }
  });
  } catch (error) {
    if (error instanceof AdminError || error.status===413 || error instanceof SyntaxError || error instanceof URIError || error.message==='Invalid JSON') return sendError(error);
    console.error('Request failed:',error.code || error.name);
    if (!res.headersSent) return send(500,{error:'internal_error'});
    res.end();
  }
});

const socketPath = process.env.AMAN_SOCKET_PATH;
server.listen(socketPath ? {path:socketPath} : {port:Number(PORT),host:process.env.AMAN_BIND_HOST || '0.0.0.0'}, () => {
  console.log(`===============================================`);
  console.log(`AMAN Platform Server (Native SQLite Layer)`);
  console.log(socketPath ? 'Listening on a local socket.' : `URL: http://localhost:${server.address().port}`);
  console.log(`Database: SQLite (WAL Mode, Persisted)`);
  console.log(`Emergency Hub: 19 (Police) | 177 (Gendarmerie) | 8350 (UNFM)`);
  console.log(`===============================================`);
});
