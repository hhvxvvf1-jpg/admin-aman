# AMAN administration API

`/api/admin/*` is authenticated using `Authorization: Bearer <token>` and returns `Cache-Control: no-store`. Mutations accept JSON. Use HTTPS outside local development. Privileged login requires a password and RFC 6238 TOTP. Tokens expire after one hour for staff, are stored server-side as hashes, and are revoked on account changes and role-permission edits. Public follow-up credentials are not staff tokens.

## Authentication

| Method and path | Contract |
|---|---|
| `POST /api/auth/login` | `{email,password,otp}`; returns `{success,token,expiresAt,user}`. Invalid credentials/code: 401. |
| `GET /api/admin/me` | `{user,permissions}` for the current staff session. |
| `POST /api/auth/logout` | Revokes the presented bearer token. |

## Administration endpoints

| Path under `/api/admin` | Method(s) | Inputs and constraints |
|---|---|---|
| `/dashboard` | GET | `range=week\|month\|year`. Health, permission-filtered tasks and audit activity, and aggregates if authorized. |
| `/analytics`, `/analytics/:format` | GET | Same range filter; `analytics.export` required for `csv`, `xlsx`, or `pdf`. Case metrics below 5 (including zero) are suppressed; other case metrics are banded. |
| `/users`, `/users/:id` | GET | List filters `q`, `role`, `state=active\|suspended`; member contact/name are omitted. |
| `/users/:id` | PATCH | `{active:boolean,role?}`; no self-edit, no remote super-admin modification or transitions into/out of safeguarding roles. |
| `/users/:id/sessions` | DELETE | Revokes sessions; returns `{revoked}`. |
| `/roles`, `/roles/:role` | GET, PATCH respectively | List available and enabled permissions; PATCH `{enabled:[…]}` within the role’s fixed ceiling, except super-admin. |
| `/cases`, `/cases/:id` | GET | Filter list by `group`, `status`, `urgency`, `q` (reference). Only explicit safeguarding roles; workers see assigned cases within their scope. Detail includes scoped notes, audio metadata, referrals and timeline. |
| `/cases/:id/status` | PATCH | `{status,assignedTo?,reason?}`. Legacy status identifiers map to UI labels: `INITIAL_REVIEW` → Review, `HUMAN_ASSESSMENT` → Assessment, `ACTION_REQUIRED` → Assigned. Referral creates `REFERRED`. `FOLLOW_UP` may also follow `ACTION_REQUIRED` when referral isn’t needed. Only authorized supervisors assign/reopen. |
| `/cases/:id/notes` | POST | `{content,noteType?}`; type `assessment`, `follow_up`, `action`. |
| `/cases/:id/referrals` | POST | `{organizationId,notes?}`; verifies case scope and recipient organization. |
| `/referrals`, `/referrals/:id` | GET, PATCH respectively | Verified partner admins see only own organization’s referral IDs and statuses. PATCH `{status}`; no case IDs or narrative. |
| `/cms`, `/cms/:id` | GET | List filters `state`, `q`, `audience`; detail includes content and workflow history. |
| `/cms`, `/cms/:id` | POST, PATCH respectively | `slug`, `contentType`, `titleAr/Fr/En`, `bodyAr/Fr/En`, optional `sourceRef`, `seoDescription`, `audience`; Girls require `minAge/maxAge` integers 10–17. PATCH requires current `revision` and draft state. |
| `/cms/:id/workflow` | POST | `{action,revision,publishAt?}`. `submit`, `return`, `publish`, `unpublish`, `archive`, `restore`. Publishing requires an independent approver; legal/emergency/safety guides require HTTPS source reference. `publishAt` is an ISO UTC timestamp. |
| `/partners`, `/partners/:id` | GET | Filter `state`, `q`; review metadata and private profile visible only by permission. |
| `/partners`, `/partners/:id` | POST, PATCH respectively | Localized name fields, `category`, `city`, `region`, optional contact/location fields. Editing requires renewed verification. |
| `/partners/:id/review` | POST | `{state,evidence,publicListing}`. `verified`, `rejected` or `suspended`. Public listing requires verification and an explicit opt-in. |
| `/community` | GET | `type=post\|comment\|flag`; search `q` for post/comment. |
| `/community/post/:id`, `/community/comment/:id` | GET, PATCH | Moderation view and `{hidden:boolean,reason}` update. |
| `/community/flag/:id` | PATCH | `{status:'reviewed'\|'dismissed'}`. |
| `/audit` | GET | `category=all\|auth`. Redacted event rows; raw audit details are never returned here. |

| `/finance`, `/finance/:id`, `/finance/:id/workflow`, `/finance/:format` | GET, POST, PATCH as applicable | List `from`, `to`, `kind`, `state`, `q`; submit `kind,label,project,amount,entryDate` with a decimal string in MAD; updates require the current revision. Workflow `{action:'post'\|'void',revision,reason?}` requires separate approval capability. Totals use posted records; `csv`, `xlsx`, and aggregate-only `pdf` require export permission. |
| `/settings` | GET, PATCH | `{nameAr,nameFr,nameEn,palette,logo,maintenance,revision}`. Only bundled logos and named palettes. Public community write maintenance does not disable help or flags. |
| `/ai`, `/ai/test`, `/ai/sources/:id` | GET and PATCH `/ai`; POST `/ai/test`; PATCH sources | Config `{enabled,languages,defaultLanguage,includeSources,revision}`; prompt test `{message,language}` is not recorded. Source approval with `{approve}` requires a due, published general item. Revision changes invalidate previous approval. |
| `/notices`, `/notices/inbox`, `/notices/:id/read`, `/notices/:id/withdraw` | GET and POST as applicable | Publish `{template,audience}` only. No arbitrary message text, named recipients or case IDs. Inbox checks role and verified partner status; the read endpoint is idempotent. |

| `/quizzes`, `/quizzes/:id`, `/quizzes/:id/workflow` | GET, POST, PATCH as appropriate | CMS permissions. Localized `questionAr/Fr/En`, `aLabelAr/Fr/En`, `bLabelAr/Fr/En`, `feedbackAr/Fr/En`, `correct` (`a` or `b`), `minAge/maxAge`; revision required for updates/workflow. Review/publication permissions match CMS. |

The dashboard exposes backup verification metadata only to roles with `backup.view`. Neither the data archive nor its key is accessible from the HTTP server. PDF reports are currently in English, while Excel retains Unicode in data cells.

**Security incidents (platform only)**

- `GET /incidents?state=in_progress|open|triage|contained|resolved|closed&severity=…&category=…&q=…` and `GET /incidents/:id` require `incidents.view`. `q` searches incident references only. Details include the last 50 timeline actions; the public API exposes no incidents.
- `POST /incidents` requires `incidents.manage` and accepts exactly `{category,severity,component}`. Create categories: `account_security`, `service_availability`, `data_protection`, `backup_recovery`; severities: `low`, `medium`, `high`, `critical`; components: `admin_portal`, `public_portal`, `data_store`, `operations`.
- `POST /incidents/:id/workflow` accepts `{action,reason,revision}`. Managers can `triage`, `contain`, `resolve` in order. Reviewers can `close` a resolved incident only if a different actor resolved it, and can `reopen` a resolved or closed incident to triage. Reasons are action-specific enums exposed by the interface. The dashboard only shows the non-closed count when authorized. `GET /audit?category=incidents` requires both `audit.view` and `incidents.view`.

**CMS illustrations**

- `GET /cms/:id/image` requires `cms.view`; `PATCH /cms/:id/image` requires `cms.edit`, a general-audience draft and its current `revision`. Upload `{revision,png,altAr,altFr,altEn}` (`png` is base64 PNG bytes, not a data URL) or remove with `{revision,remove:true}`. Image edits increase the CMS revision, update the author for independent review and appear in history. Remove the image before switching to a restricted audience.
- Only non-interlaced 8-bit RGB/RGBA PNGs up to 1200 × 1200 and 1 MiB are accepted. The server regenerates the PNG without ancillary chunks. This removes file metadata, **not** identifying details in the visible pixels.
- The general `GET /api/cms` listing includes image ID, dimensions and trilingual descriptions when present. `GET /api/cms/images/:imageId` returns `image/png` only while its article is published and within schedule, without caching. On unpublish it returns 404. Images are stored in SQLite and covered by database backups.

**Operational staff invitations**

- `GET /staff-invitations` lists paginated invitation metadata. `POST /staff-invitations` accepts `{email,fullName,role}` and returns a one-time `code` once with `expiresAt` (30 minutes). `POST /staff-invitations/:id/revoke` cancels a pending invitation. All three require `staff.invite`. No email or SMS is sent by AMAN; use an approved private channel.
- The public, rate-limited `POST /api/staff-enrollment/begin` accepts `{code}` and returns the enrollment key and nonce. `POST /api/staff-enrollment/redeem` accepts `{code,nonce,password,otp}` and consumes the invitation after a successful TOTP challenge. The role/email always come from the invitation. After activation, the next unused TOTP code is needed at regular sign-in. Never include invitation codes in URLs or logs.
- Allowed roles: Platform Admin, Content Manager, Moderator, Auditor and Tech Support. Super Admin, safeguarding, and partner provisioning remain restricted to trusted operator workflows. Restore invalidates pending invites and active sessions.

List endpoints return `{items,offset,hasMore}` with 20 rows per page unless stated otherwise. Use `offset=0,20,40,…`. Typical errors: 400 input, 401 missing/expired authentication, 403 insufficient permission, 404 absent/out-of-scope ID, 409 invalid workflow/stale revision, 415 unsupported content type, 429 rate limit.

## Connected public/legacy routes

- `GET /api/platform/config` exposes branding and limited public maintenance state only.
- `POST /api/chat` preserves emergency guidance when the assistant is paused and does not log message contents.
- `GET /api/cms?audience=general|women|child&offset=0`: due, published entries only. Restricted Girls entries are excluded. The old `all=1` draft switch has no effect.
- `GET /api/girls/quizzes?ageGroup=10-12|13-15|16-17` returns published quizzes compatible with the full selected band, without answer keys. `POST /api/girls/quizzes/:id/answer` accepts `{ageGroup,option,language}` and does not retain answers.
- `GET /api/girls/library` and `GET /api/girls/content/:id`: require a supported band for restricted educational content. The full requested band must fit within the item’s configured range. This filters content by self-selected age band, **not** identity verification.
- `GET /api/directory`: only verified listings explicitly approved for public display. `all=1` does not change this.
- `POST /api/reports` with `submissionMethod:'audio'` returns a single-use short-lived audio upload token. Include the token with the report ID on `POST /api/reports/audio`. Neither the raw token nor audio is exposed in case lists. `GET /api/audio/:id` requires case-view authorization and audits access.
- `POST /api/community/flags`: `{type,id,reason}`, reason from `privacy`, `harassment`, `spam`, `other`. Duplicate open flags for the same target are coalesced.
- Legacy case, referral and analytics routes use the same service permissions. `DELETE /api/cases/:id/redact` is restricted to safeguarding supervisors; do not use it as a substitute for a reviewed retention/deletion process, including handling backup copies and historic audit data.
