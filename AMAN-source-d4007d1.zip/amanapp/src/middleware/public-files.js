// Only these root assets are public. Never serve the source tree, DB, or uploads.
const root = new Set(`index.html download.html manifest.webmanifest sw.js logo.png mark.png apple-touch-icon.png icon-192.png icon-512.png app.css aman-pro.css content.js app-core.js app-ai.js app-extra.js app-speech.js app-voice.js app-ecosystem.js app-girls.js community.js community.css search.js search.css protect.js protect.css select.js select.css adfm.jpg al-bouraz.jpg aman.jpg amna.jpg amvef.jpg anaouat.jpg arab-feminist-network.jpg cndh.jpg cndp.jpg commission-nationale.jpg dgsn.jpg education.jpg entraide.jpg fldf.jpg fm5.jpg israr.jpg justice.jpg mediateur.jpg ministere-public.jpg ministere-solidarite.jpg onu-femmes.jpg sante.jpg uaf.jpg unfm.jpg unfpa.jpg unhcr.jpg unicef.jpg voix-femmes.jpg`.split(' '));
const admin = new Set(['admin/index.html','admin/admin.css','admin/admin.js','admin/i18n.js','admin/operations.js']);
function publicPath(pathname) {
  if (pathname==='/') return 'index.html';
  if (pathname==='/admin' || pathname==='/admin/') return 'admin/index.html';
  const file=pathname.slice(1);
  return root.has(file) || admin.has(file) ? file : null;
}
module.exports={publicPath,root};
