const { db } = require('../db/database');

// Scope and permission are separate: no administrative capability grants case access.
const defaults = Object.freeze({
  super_admin: ['dashboard.view','backup.view','users.view','users.edit','staff.invite','roles.manage','analytics.view','analytics.export','audit.view','incidents.view','incidents.manage','incidents.review','sessions.manage','cms.view','cms.create','cms.edit','cms.approve','cms.delete','partners.view','partners.create','partners.edit','partners.approve','community.view','community.edit','finance.view','finance.edit','finance.approve','finance.export','settings.view','settings.edit','ai.view','ai.edit','ai.approve','notices.manage'],
  platform_admin: ['dashboard.view','users.view','analytics.view','cms.view','cms.create','cms.edit','cms.approve','partners.view','partners.create','partners.edit','partners.approve','community.view','finance.view','finance.edit','settings.view','ai.view','ai.edit','notices.manage'],
  content_manager: ['cms.view','cms.create','cms.edit'],
  safeguarding_supervisor: ['dashboard.view','analytics.view','analytics.export','cases.view','cases.edit','cases.assign','cases.refer','cases.reopen','cases.redact'],
  women_caseworker: ['cases.view','cases.edit','cases.refer'],
  girls_caseworker: ['cases.view','cases.edit','cases.refer'],
  child_caseworker: ['cases.view','cases.edit','cases.refer'],
  authorized_professional: ['cases.view','cases.edit','cases.refer'],
  partner_admin: ['referrals.view','referrals.edit'],
  moderator: ['community.view','community.edit'],
  auditor: ['dashboard.view','analytics.view','analytics.export','audit.view','backup.view','incidents.view','finance.view','finance.export'],
  tech_support: ['dashboard.view','backup.view','incidents.view','incidents.manage'],
  member: []
});
const roles = Object.keys(defaults);
const ceiling = role => roles.includes(role) ? [...defaults[role], ...(role!=='member'?['notices.view']:[])] : [];
const isStaff = role => roles.includes(role) && role !== 'member';
function permissions(role) {
  if (!roles.includes(role)) return [];
  const disabled = new Set(db.prepare('SELECT permission FROM role_permissions WHERE role = ? AND enabled = 0').all(role).map(x => x.permission));
  return ceiling(role).filter(p => !disabled.has(p));
}
function has(user, permission) { return !!user && permissions(user.role).includes(permission); }
module.exports = { defaults, ceiling, roles, isStaff, permissions, has };
