const crypto = require('node:crypto');
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function encodeBase32(bytes) {
  let value = 0, bits = 0, result = '';
  for (const byte of bytes) {
    value = (value << 8) | byte; bits += 8;
    while (bits >= 5) { bits -= 5; result += alphabet[(value >>> bits) & 31]; }
  }
  if (bits) result += alphabet[(value << (5 - bits)) & 31];
  return result;
}
function totp(bytes, step) {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(step));
  const hmac = crypto.createHmac('sha1', bytes).update(counter).digest();
  return String((hmac.readUInt32BE(hmac[19] & 15) & 0x7fffffff) % 1_000_000).padStart(6, '0');
}
function verify(secretHex, code, lastStep) {
  if (!/^[0-9a-f]{40}$/i.test(secretHex) || typeof code !== 'string' || !/^\d{6}$/.test(code)) return null;
  const step = Math.floor(Date.now() / 30_000);
  const key = Buffer.from(secretHex, 'hex');
  for (const candidate of [step, step - 1, step + 1]) {
    if (candidate > lastStep && crypto.timingSafeEqual(Buffer.from(code), Buffer.from(totp(key, candidate)))) return candidate;
  }
  return null;
}
module.exports = { encodeBase32, totp, verify };
