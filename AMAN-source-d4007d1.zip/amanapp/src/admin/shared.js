const { db } = require('../db/database');
class AdminError extends Error { constructor(status, message) { super(message); this.status = status; } }
function fail(status, code) { throw new AdminError(status, code); }
function text(value, limit, min = 0) {
  if (typeof value !== 'string') fail(400, 'invalid_input');
  const clean = value.trim();
  if (clean.length < min || clean.length > limit || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(clean)) fail(400, 'invalid_input');
  return clean;
}
function one(value, options) { if (!options.includes(value)) fail(400, 'invalid_input'); return value; }
function existing(row) { if (!row) fail(404, 'not_found'); return row; }
function atomic(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const result = fn(); db.exec('COMMIT'); return result; }
  catch (err) { db.exec('ROLLBACK'); throw err; }
}
function audit(user, action, details = {}) {
  db.prepare('INSERT INTO audit_logs (action, actor_id, details) VALUES (?,?,?)').run(action, user.id, JSON.stringify(details));
}
function pagination(query) {
  const offset = Number(query.offset ?? 0);
  if (!Number.isSafeInteger(offset) || offset < 0 || offset > 1000000) fail(400, 'invalid_input');
  return { offset, limit: 20 };
}
function page(query, sql, args = []) {
  const { offset, limit } = pagination(query);
  const rows = db.prepare(`${sql} LIMIT ? OFFSET ?`).all(...args, limit + 1, offset);
  return { items: rows.slice(0, limit), offset, hasMore: rows.length > limit };
}
module.exports = { AdminError, fail, text, one, existing, atomic, audit, page };
