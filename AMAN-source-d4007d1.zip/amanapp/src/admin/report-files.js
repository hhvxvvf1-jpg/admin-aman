// Small, dependency-free serializers for bounded exports. All spreadsheet strings are literal cells.
const {crc32,deflateRawSync}=require('node:zlib');
const xml=s=>String(s).replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]/g,'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
const ns='http://schemas.openxmlformats.org';
const sheetNS=`${ns}/spreadsheetml/2006/main`;
const officeRel=`${ns}/officeDocument/2006/relationships`;
const pkgRel=`${ns}/package/2006/relationships`;
const xDecl='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
function zip(files){
  let position=0, directorySize=0;
  const local=[], central=[];
  for(const [file,contents] of Object.entries(files)){
    const name=Buffer.from(file), value=Buffer.from(contents), compressed=deflateRawSync(value), crc=crc32(value);
    const header=Buffer.alloc(30), entry=Buffer.alloc(46);
    header.writeUInt32LE(0x04034b50);header.writeUInt16LE(20,4);header.writeUInt16LE(8,8);header.writeUInt16LE(0x0021,12);
    header.writeUInt32LE(crc,14);header.writeUInt32LE(compressed.length,18);header.writeUInt32LE(value.length,22);header.writeUInt16LE(name.length,26);
    entry.writeUInt32LE(0x02014b50);entry.writeUInt16LE(20,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(8,10);entry.writeUInt16LE(0x0021,14);
    entry.writeUInt32LE(crc,16);entry.writeUInt32LE(compressed.length,20);entry.writeUInt32LE(value.length,24);entry.writeUInt16LE(name.length,28);entry.writeUInt32LE(position,42);
    local.push(header,name,compressed);central.push(entry,name);position+=header.length+name.length+compressed.length;directorySize+=entry.length+name.length;
  }
  const end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(central.length/2,8);end.writeUInt16LE(central.length/2,10);end.writeUInt32LE(directorySize,12);end.writeUInt32LE(position,16);
  return Buffer.concat([...local,...central,end]);
}
function column(n){let str='';for(let i=n+1;i>0;i=Math.floor((i-1)/26))str=String.fromCharCode(65+(i-1)%26)+str;return str;}
function xlsx(sheets){
  const files={
    '[Content_Types].xml':xDecl+`<Types xmlns="${ns}/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${sheets.map((_,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`,
    '_rels/.rels':xDecl+`<Relationships xmlns="${pkgRel}"><Relationship Id="rId1" Type="${officeRel}/officeDocument" Target="xl/workbook.xml"/></Relationships>`,
    'xl/workbook.xml':xDecl+`<workbook xmlns="${sheetNS}" xmlns:r="${officeRel}"><sheets>${sheets.map(([name],i)=>`<sheet name="${xml(name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')}</sheets></workbook>`,
    'xl/_rels/workbook.xml.rels':xDecl+`<Relationships xmlns="${pkgRel}">${sheets.map((_,i)=>`<Relationship Id="rId${i+1}" Type="${officeRel}/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')}</Relationships>`
  };
  sheets.forEach(([,rows],idx)=>{
    const width=Math.max(1,...rows.map(r=>r.length));
    files[`xl/worksheets/sheet${idx+1}.xml`]=xDecl+`<worksheet xmlns="${sheetNS}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols><col min="1" max="1" width="36" customWidth="1"/>${width>1?`<col min="2" max="${width}" width="23" customWidth="1"/>`:''}</cols><sheetData>${rows.map((row,i)=>`<row r="${i+1}">${row.map((cell,j)=>{const ref=`${column(j)}${i+1}`;return typeof cell==='number'&&Number.isFinite(cell)?`<c r="${ref}"><v>${cell}</v></c>`:`<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xml(cell??'')}</t></is></c>`;}).join('')}</row>`).join('')}</sheetData></worksheet>`;
  });
  return zip(files);
}
// PDF output uses the standard Latin PDF fonts. Only controlled labels and numbers are passed in.
const pdfText=value=>String(value).replace(/[–—]/g,'-').replace(/[^\x20-\x7e]/g,'?').replace(/[\\()]/g,'\\$&');
function pdf(title,subheading,lines){
  const chunks=[];
  for(let i=0;i<lines.length;i+=33)chunks.push(lines.slice(i,i+33));
  const objects=['<< /Type /Catalog /Pages 2 0 R >>','','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>'];
  const pageIDs=[];
  for(const [n,chunk] of chunks.entries()){
    const page=objects.length+1, content=page+1;pageIDs.push(page);
    const txt=(f,pt,x,y,v)=>`BT /${f} ${pt} Tf ${x} ${y} Td (${pdfText(v)}) Tj ET\n`;
    let stream='0.15 0.08 0.24 rg\n48 753 499 45 re f\n1 1 1 rg\n'+txt('Bold',18,61,769,title)+'0.16 0.10 0.23 rg\n'+txt('Regular',11,48,731,subheading);
    chunk.forEach((line,i)=>{const y=703-i*18;const pair=Array.isArray(line)?line:[line];if(i%2===0)stream+=`0.96 0.94 0.98 rg 48 ${y-4} 499 17 re f\n`;stream+='0.16 0.10 0.23 rg\n'+txt(pair.length>1?'Regular':'Bold',10,55,y,pair[0]);if(pair.length>1)stream+=txt('Bold',10,417,y,pair[1]);});
    stream+='0.33 0.27 0.37 rg\n'+txt('Regular',9,48,39,`AMAN Administration  |  Page ${n+1} of ${chunks.length}`);
    objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /Regular 3 0 R /Bold 4 0 R >> >> /Contents ${content} 0 R >>`,`<< /Length ${Buffer.byteLength(stream)} >>\nstream\n${stream}endstream`);
  }
  objects[1]=`<< /Type /Pages /Kids [${pageIDs.map(n=>`${n} 0 R`).join(' ')}] /Count ${pageIDs.length} >>`;
  let result='%PDF-1.4\n';const offsets=[0];
  objects.forEach((o,i)=>{offsets.push(Buffer.byteLength(result));result+=`${i+1} 0 obj\n${o}\nendobj\n`;});
  const start=Buffer.byteLength(result);
  result+=`xref\n0 ${offsets.length}\n0000000000 65535 f \n${offsets.slice(1).map(n=>`${String(n).padStart(10,'0')} 00000 n \n`).join('')}trailer\n<< /Root 1 0 R /Size ${offsets.length} >>\nstartxref\n${start}\n%%EOF\n`;
  return Buffer.from(result);
}
function attachment(res,name,data){
  const type=name.endsWith('.pdf')?'application/pdf':name.endsWith('.xlsx')?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'text/csv; charset=utf-8';
  res.writeHead(200,{'Content-Type':type,'Content-Disposition':`attachment; filename="${name}"`,'Content-Length':Buffer.byteLength(data)});res.end(data);
}
const labels={totalUsers:'Total accounts',registrations:'New registrations',requests:'Help requests',newCases:'New cases',urgent:'Urgent cases',review:'Cases under review',referrals:'Referrals',resolved:'Resolved cases',partners:'Verified organizations',resources:'Published resources',posts:'Visible community posts'};
function analyticsExport(format,stats){
  const metrics=Object.entries(stats.metrics).map(([k,v])=>[labels[k],v]);
  const series=stats.series.map(x=>[x.date,x.registrations]);
  const privacy=`Confidential totals below ${stats.privacyThreshold} are suppressed, including zero.`;
  if(format==='xlsx')return xlsx([['Overview',[['Metric','Value'],...metrics,['From UTC',stats.from],['To UTC',stats.to],['Privacy rule',privacy]]],['Registrations',[['Date (UTC)','Registrations'],...series]]]);
  return pdf('AMAN | Activity report',`${stats.from} to ${stats.to} (UTC)`,[['Activity summary'],...metrics,[privacy],['Registration trend (UTC)'],...series]);
}
module.exports={analyticsExport,attachment,xlsx,pdf};
