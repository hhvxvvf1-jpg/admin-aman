// Existing AMAN Girls quizzes promoted into editorial storage without changing their original IDs.
module.exports = [
  {
    id: 'quiz_10_12',
    ageGroups: ['10-12'],
    questionAr: 'إذا طلب منكِ شخص غريب على الإنترنت إرسال صورتكِ، ماذا تفعلين؟',
    questionFr: 'Si un inconnu en ligne te demande ta photo, que fais-tu ?',
    questionEn: 'If a stranger online asks for your photo, what should you do?',
    options: [
      { id: 'a', labelAr: 'أرفض وأخبر شخصاً بالغاً موثوقاً', labelFr: 'Je refuse et j’en parle à un adulte de confiance', labelEn: 'Refuse and tell a trusted adult', correct: true },
      { id: 'b', labelAr: 'أرسلها له', labelFr: 'Je l’envoie', labelEn: 'Send it', correct: false }
    ],
    feedbackAr: 'أحسنتِ! لا نشارك صورنا مع الغرباء أبداً.',
    feedbackFr: 'Bravo ! On ne partage jamais ses photos avec des inconnus.',
    feedbackEn: 'Great job! Never share photos with strangers.'
  },
  {
    id: 'quiz_13_15',
    ageGroups: ['13-15', '16-17'],
    questionAr: 'إذا تعرضتِ للابتزاز الإلكتروني، هل يجب حذف الرسائل أم الاحتفاظ بلقطة شاشة وطلب المساعدة؟',
    questionFr: 'En cas de chantage en ligne, faut-il garder une capture d’écran et demander de l’aide ?',
    questionEn: 'If you face online blackmail, should you keep a screenshot and ask for help?',
    options: [
      { id: 'a', labelAr: 'الاحتفاظ بالدليل وطلب المساعدة من مختصة', labelFr: 'Garder la preuve et demander de l’aide', labelEn: 'Keep evidence and ask for help', correct: true },
      { id: 'b', labelAr: 'الاستسلام للتهديد', labelFr: 'Céder à la menace', labelEn: 'Give in to the threat', correct: false }
    ],
    feedbackAr: 'صحيح! احتفظي بالأدلة وتواصلي مع مختصة في أمان أو خط 8350.',
    feedbackFr: 'Exact ! Garde les preuves et contacte une spécialiste.',
    feedbackEn: 'Correct! Keep evidence and contact a specialist.'
  }
];
