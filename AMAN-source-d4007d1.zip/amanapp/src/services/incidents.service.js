const {randomUUID}=require('node:crypto');
const {db}=require('../db/database');
const {has}=require('../admin/permissions');
const {page,existing,atomic,one,text,fail,audit}=require('../admin/shared');
const categories=['account_security','service_availability','data_protection','backup_recovery'];
const severities=['low','medium','high','critical'];
const components=['admin_portal','public_portal','data_store','operations'];
const states=['open','triage','contained','resolved','closed'];
const workflows={
  triage:[['open'],'triage','incidents.manage',['assessment_started']],
  contain:[['triage'],'contained','incidents.manage',['exposure_stopped','service_stabilized','precaution_completed']],
  resolve:[['contained'],'resolved','incidents.manage',['remediation_tested','recovery_verified','false_alarm_confirmed']],
  close:[['resolved'],'closed','incidents.review',['independent_check_completed']],
  reopen:[['resolved','closed'],'triage','incidents.review',['new_signal','recurrence','incomplete_remediation']]
};
const columns='id,category,severity,component,state,revision,created_at,updated_at';
function list(query){
  const filter=(key,options)=>query[key]?one(query[key],options):'';
  const q=text(query.q??'',80).toUpperCase(),state=filter('state',['in_progress',...states]),severity=filter('severity',severities),category=filter('category',categories);
  const conditions="(?='' OR state=? OR (?='in_progress' AND state!='closed')) AND (?='' OR severity=?) AND (?='' OR category=?)";
  return page(query,`SELECT ${columns} FROM security_incidents WHERE ${conditions} AND (?='' OR instr(id,?)>0) ORDER BY (state='closed'),CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,updated_at DESC,id`,[state,state,state,severity,severity,category,category,q,q]);
}
function detail(id){
  const item=existing(db.prepare(`SELECT ${columns} FROM security_incidents WHERE id=?`).get(id));
  const timeline=db.prepare('SELECT action,reason,actor_role,created_at FROM security_incident_events WHERE incident_id=? ORDER BY id DESC LIMIT 50').all(id);
  return {...item,timeline};
}
function read(user,id){const item=detail(id);audit(user,'incident_accessed',{incidentId:id});return item;}
function record(user,id,action,reason){
  db.prepare('INSERT INTO security_incident_events(incident_id,actor_id,actor_role,action,reason) VALUES(?,?,?,?,?)').run(id,user.id,user.role,action,reason);
  audit(user,'incident_'+action,{incidentId:id});
}
function validateKeys(input,keys){if(Object.keys(input).some(key=>!keys.includes(key)))fail(400,'invalid_input');}
function create(user,input){
  validateKeys(input,['category','severity','component']);
  const category=one(input.category,categories),severity=one(input.severity,severities),component=one(input.component,components);
  return atomic(()=>{
    const id='INC-'+randomUUID().toUpperCase();
    db.prepare('INSERT INTO security_incidents(id,category,severity,component) VALUES(?,?,?,?)').run(id,category,severity,component);
    record(user,id,'record','operator_reported');return detail(id);
  });
}
function transition(user,id,input){
  validateKeys(input,['action','reason','revision']);
  const {action,reason,revision}=input;
  const [from,to,permission,reasons]=workflows[one(action,Object.keys(workflows))];
  if(!has(user,permission))fail(403,'forbidden');
  one(reason,reasons);
  if(!Number.isSafeInteger(revision)||revision<1)fail(400,'invalid_input');
  return atomic(()=>{
    const current=existing(db.prepare('SELECT state,revision,resolved_by FROM security_incidents WHERE id=?').get(id));
    if(current.revision!==revision||!from.includes(current.state))fail(409,'invalid_revision_or_state');
    if(action==='close'&&current.resolved_by===user.id)fail(403,'independent_reviewer_required');
    const resolver=action==='resolve'?user.id:action==='reopen'?null:current.resolved_by;
    db.prepare('UPDATE security_incidents SET state=?,resolved_by=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(to,resolver,id);
    record(user,id,action,reason);return detail(id);
  });
}
module.exports={list,read,create,transition};
