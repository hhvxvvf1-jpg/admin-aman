const crypto=require('node:crypto');
const {db}=require('../db/database');
const {has}=require('../admin/permissions');
const {text,one,existing,atomic,audit,fail,page}=require('../admin/shared');
const languages=['Ar','Fr','En'];
const states=['draft','review','published','archived'];
const bands={'10-12':[10,12],'13-15':[13,15],'16-17':[16,17]};
const columns='id,title_en,min_age,max_age,state,revision,updated_at';
function list(query){
  const q=text(query.q||'',120),state=query.state?one(query.state,states):'';
  return page(query,`SELECT ${columns} FROM girls_quizzes WHERE (?='' OR state=?) AND (?='' OR instr(lower(title_en),lower(?))>0) ORDER BY updated_at DESC,id`,[state,state,q,q]);
}
function detail(id){
  const row=existing(db.prepare(`SELECT ${columns},author_id,payload FROM girls_quizzes WHERE id=?`).get(id));
  const {payload,...meta}=row;return {...meta,...JSON.parse(payload)};
}
function save(user,id,input){
  const min=input.minAge,max=input.maxAge;
  if(!Number.isInteger(min)||!Number.isInteger(max)||min<10||max>17||min>max||!Object.values(bands).some(([a,b])=>a>=min&&b<=max))fail(400,'invalid_age_range');
  const payload={};
  for(const lang of languages){payload['question'+lang]=text(input['question'+lang],320,1);payload['feedback'+lang]=text(input['feedback'+lang],500,1);}
  const correct=one(input.correct,['a','b']);
  payload.options=['a','b'].map(id=>Object.fromEntries([['id',id],['correct',correct===id],...languages.map(lang=>['label'+lang,text(input[id+'Label'+lang],180,1)])]));
  return atomic(()=>{
    const current=id?detail(id):null;
    if(current && (current.state!=='draft'||current.revision!==input.revision))fail(409,'invalid_revision_or_state');
    const quizId=id||`quiz_${crypto.randomUUID()}`;
    if(current)db.prepare('UPDATE girls_quizzes SET title_en=?,min_age=?,max_age=?,payload=?,author_id=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(payload.questionEn,min,max,JSON.stringify(payload),user.id,quizId);
    else db.prepare('INSERT INTO girls_quizzes(id,title_en,min_age,max_age,payload,author_id) VALUES (?,?,?,?,?,?)').run(quizId,payload.questionEn,min,max,JSON.stringify(payload),user.id);
    audit(user,current?'quiz_edited':'quiz_created',{quizId});return detail(quizId);
  });
}
function transition(user,id,{action,revision}){
  const actions={submit:['cms.edit','draft','review'],return:['cms.approve','review','draft'],publish:['cms.approve','review','published'],unpublish:['cms.approve','published','draft'],archive:['cms.delete','draft','archived'],restore:['cms.delete','archived','draft']};
  if(!Object.hasOwn(actions,action))fail(400,'invalid_input');
  const [perm,from,to]=actions[action];
  if(!has(user,perm))fail(403,'forbidden');
  return atomic(()=>{
    const current=detail(id);
    if(revision!==current.revision||from!==current.state)fail(409,'invalid_revision_or_state');
    if(action==='publish'&&current.author_id===user.id)fail(403,'independent_reviewer_required');
    db.prepare('UPDATE girls_quizzes SET state=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(to,id);
    audit(user,`quiz_${action}`,{quizId:id});return detail(id);
  });
}
function band(value){return typeof value==='string'&&Object.hasOwn(bands,value)?bands[value]:null;}
function publicQuizzes(ageGroup){
  const selected=band(ageGroup);if(!selected)return [];
  return db.prepare("SELECT id,payload FROM girls_quizzes WHERE state='published' AND min_age<=? AND max_age>=? ORDER BY id LIMIT 50").all(...selected).map(({id,payload})=>{
    const content=JSON.parse(payload);
    return {id,...Object.fromEntries(languages.map(l=>['question'+l,content['question'+l]])),options:content.options.map(({correct,...publicOption})=>publicOption)};
  });
}
function answer(id,{ageGroup,option,language}){
  const selected=band(ageGroup);if(!selected)fail(404,'not_found');
  one(option,['a','b']);one(language,['ar','fr','en']);
  const row=existing(db.prepare("SELECT payload FROM girls_quizzes WHERE id=? AND state='published' AND min_age<=? AND max_age>=?").get(id,...selected));
  const content=JSON.parse(row.payload),correct=content.options.some(opt=>opt.id===option&&opt.correct);
  const key={ar:'feedbackAr',fr:'feedbackFr',en:'feedbackEn'}[language];
  const retry={ar:'جرّبي إجابة أخرى.',fr:'Essaie une autre réponse.',en:'Try another answer.'};
  return {correct,feedback:correct?content[key]:retry[language]};
}
module.exports={list,detail,save,transition,publicQuizzes,answer};
