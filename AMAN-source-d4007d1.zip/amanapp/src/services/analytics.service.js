const { db } = require('../db/database');
const { has } = require('../admin/permissions');
const { fail, one } = require('../admin/shared');
const MIN_THRESHOLD=5;
// Banded sensitive aggregates, including zero, to limit inference between adjacent windows.
const band=n=>n<MIN_THRESHOLD?'<5':`${Math.floor(n/5)*5}–${Math.floor(n/5)*5+4}`;
const count=(sql,...params)=>db.prepare(sql).get(...params).n;
const day=86400_000;
function getAggregatedStats(user,range='month') {
  if (!has(user,'analytics.view')) fail(403,'forbidden');
  one(range,['week','month','year']);
  const now=new Date();
  const end=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()+1));
  const start=range==='year' ? new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth()-11,1)) : new Date(+end-(range==='week'?7:30)*day);
  const sqlDate=d=>d.toISOString().slice(0,19).replace('T',' ');
  const bounds=[sqlDate(start),sqlDate(end)];
  const interval=(table,column='created_at',extra='1=1')=>count(`SELECT count(*) n FROM ${table} WHERE ${column}>=? AND ${column}<? AND ${extra}`,...bounds);
  const sinceCases=extra=>band(interval('help_requests','created_at',extra));
  const series=[];
  for (let from=start;from<end;) {
    const next=range==='year'?new Date(Date.UTC(from.getUTCFullYear(),from.getUTCMonth()+1,1)):new Date(+from+day);
    const to=next<end?next:end;
    series.push({date:from.toISOString().slice(0,10),registrations:count('SELECT count(*) n FROM users WHERE created_at>=? AND created_at<?',sqlDate(from),sqlDate(to))});
    from=next;
  }
  return {
    range, from:start.toISOString().slice(0,10), to:new Date(+end-day).toISOString().slice(0,10), series,
    metrics:{
      totalUsers:count('SELECT count(*) n FROM users'), registrations:interval('users'),
      requests:sinceCases('1=1'), newCases:sinceCases("status='NEW'"), urgent:sinceCases("urgency='urgent' AND status NOT IN ('RESOLVED','CLOSED')"),
      review:sinceCases("status IN ('INITIAL_REVIEW','HUMAN_ASSESSMENT')"), referrals:band(interval('referrals')),
      resolved:sinceCases("status IN ('RESOLVED','CLOSED')"),
      partners:count("SELECT count(*) n FROM organizations WHERE is_verified=1 AND review_state='verified'"),
      resources:count("SELECT count(*) n FROM cms_content WHERE review_status='published' AND (publish_at IS NULL OR publish_at<=?)",new Date().toISOString()),
      posts:interval('posts','created_at','hidden=0')
    }, privacyThreshold:MIN_THRESHOLD
  };
}
module.exports={getAggregatedStats};
