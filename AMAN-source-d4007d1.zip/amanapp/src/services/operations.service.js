const crypto=require('node:crypto');
const {db}=require('../db/database');
const {fail,text,one,existing,atomic,audit,page}=require('../admin/shared');
const {has}=require('../admin/permissions');
const casesRoles=['safeguarding_supervisor','women_caseworker','girls_caseworker','child_caseworker','authorized_professional'];
const locales=['ar','fr','en'];
const financeKinds=['budget','grant','contribution','expense','maintenance','allocation'];
const financeStates=['draft','posted','void'];
const templates=['maintenance','training','policy_review'];
const audiences=['staff','safeguarding','partners'];
const id=prefix=>`${prefix}_${crypto.randomUUID()}`;
const bool=v=>{if(typeof v!=='boolean')fail(400,'invalid_input');return v;};
function calendar(value){
  const str=text(value,10,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(str))fail(400,'invalid_date');
  const day=new Date(`${str}T00:00:00Z`);
  if(!Number.isFinite(+day)||day.toISOString().slice(0,10)!==str)fail(400,'invalid_date');
  return str;
}
function getConfig(key){
  const row=db.prepare('SELECT value,revision,updated_at FROM operational_config WHERE key=?').get(key);
  return { ...JSON.parse(row.value),revision:row.revision,updatedAt:row.updated_at };
}
function changeConfig(user,key,input){
  let value;
  if(key==='platform') {
    value={nameAr:text(input.nameAr,40,1),nameFr:text(input.nameFr,40,1),nameEn:text(input.nameEn,40,1),palette:one(input.palette,['purple','plum','indigo']),logo:one(input.logo,['mark.png','logo.png']),maintenance:bool(input.maintenance)};
  } else {
    if(!Array.isArray(input.languages)||input.languages.length<1||input.languages.length>3||new Set(input.languages).size!==input.languages.length||input.languages.some(x=>!locales.includes(x)))fail(400,'invalid_languages');
    value={enabled:bool(input.enabled),languages:input.languages,defaultLanguage:one(input.defaultLanguage,input.languages),includeSources:bool(input.includeSources)};
    if(!has(user,'ai.approve') && value.includeSources!==getConfig('ai').includeSources)fail(403,'forbidden');
  }
  return atomic(()=>{
    if(input.revision!==getConfig(key).revision)fail(409,'stale_revision');
    db.prepare('UPDATE operational_config SET value=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE key=?').run(JSON.stringify(value),key);
    audit(user,key==='platform'?'platform_settings_updated':'ai_settings_updated');
    return getConfig(key);
  });
}
function publicConfig(){const {revision,updatedAt,...branding}=getConfig('platform');return branding;}
function financeQuery(query){
  const from=query.from?calendar(query.from):'';
  const to=query.to?calendar(query.to):'';
  if(from&&to&&from>to)fail(400,'invalid_date_range');
  const kind=query.kind?one(query.kind,financeKinds):'';
  const state=query.state?one(query.state,financeStates):'';
  const q=text(query.q||'',120);
  return {where:`(?='' OR entry_date>=?) AND (?='' OR entry_date<=?) AND (?='' OR kind=?) AND (?='' OR instr(lower(label||' '||project),lower(?))>0)`,values:[from,from,to,to,kind,kind,q,q],state};
}
function postedTotals(f){
  const totals=Object.fromEntries(financeKinds.map(k=>[k,0]));
  for(const r of db.prepare(`SELECT kind, sum(amount_minor) n FROM finance_records WHERE ${f.where} AND state='posted' GROUP BY kind`).all(...f.values))totals[r.kind]=r.n;
  return totals;
}
function finance(user,query){
  const f=financeQuery(query);
  const p=page(query,`SELECT id,kind,label,project,amount_minor,entry_date,state FROM finance_records WHERE ${f.where} AND (?='' OR state=?) ORDER BY entry_date DESC,id`,[...f.values,f.state,f.state]);
  return {...p,totals:postedTotals(f),currency:'MAD'};
}
function financeDetail(id){return existing(db.prepare('SELECT id,kind,label,project,amount_minor,entry_date,state,revision,reason,updated_at FROM finance_records WHERE id=?').get(id));}
function financeSave(user,recordId,input){
  return atomic(()=>{
    const current=recordId?financeDetail(recordId):null;
    if(current && (current.state!=='draft'||input.revision!==current.revision))fail(409,'invalid_revision_or_state');
    const newId=recordId || id('fin');
    if(typeof input.amount!=='string' || !/^\d{1,9}(?:[.,]\d{1,2})?$/.test(input.amount))fail(400,'invalid_amount');
    const [whole,frac='']=input.amount.replace(',','.').split('.');
    const minor=Number(whole)*100+Number(frac.padEnd(2,'0'));
    if(minor<1 || minor>100000000000)fail(400,'invalid_amount');
    const values=[one(input.kind,financeKinds),text(input.label,160,1),text(input.project,100,1),minor,calendar(input.entryDate)];
    if(current)db.prepare('UPDATE finance_records SET kind=?,label=?,project=?,amount_minor=?,entry_date=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(...values,newId);
    else db.prepare('INSERT INTO finance_records (kind,label,project,amount_minor,entry_date,id,created_by) VALUES (?,?,?,?,?,?,?)').run(...values,newId,user.id);
    audit(user,current?'finance_edited':'finance_created',{recordId:newId});
    return financeDetail(newId);
  });
}
function financeTransition(user,recordId,{revision,action,reason=''}){
  return atomic(()=>{
    const row=financeDetail(recordId);
    if(row.revision!==revision)fail(409,'stale_revision');
    one(action,['post','void']);
    if((action==='post'&&row.state!=='draft')||(action==='void'&&row.state==='void'))fail(409,'invalid_transition');
    const state=action==='post'?'posted':'void';
    db.prepare('UPDATE finance_records SET state=?,reason=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(state,action==='void'?text(reason,400,5):null,recordId);
    audit(user,action==='post'?'finance_posted':'finance_voided',{recordId});
    return financeDetail(recordId);
  });
}
function financeExport(user,query,format){
  const f=financeQuery(query);
  const totals=Object.entries(postedTotals(f)).map(([label,value])=>[label,value/100]);
  if(format==='pdf'){
    audit(user,'finance_exported',{format});
    return require('../admin/report-files').pdf('AMAN | Finance summary','Posted operational records only (MAD)',[['Posted totals by selected filters'],...totals.map(([label,value])=>[label,value.toFixed(2)]),['Draft and void entries are not counted.']]);
  }
  const rows=db.prepare(`SELECT id,kind,label,project,amount_minor,entry_date,state FROM finance_records WHERE ${f.where} AND (?='' OR state=?) ORDER BY entry_date DESC,id LIMIT 10001`).all(...f.values,f.state,f.state);
  if(rows.length>10000)fail(409,'narrow_export_filters');
  const header=['id','kind','label','project','amount_mad','entry_date','state'];
  const reportRows=rows.map(r=>[r.id,r.kind,r.label,r.project,r.amount_minor/100,r.entry_date,r.state]);
  audit(user,'finance_exported',{format,rows:rows.length});
  if(format==='xlsx')return require('../admin/report-files').xlsx([['Records',[header,...reportRows]],['Posted totals',[['Type','Amount MAD'],...totals]]]);
  const cell=x=>{const v=String(x);return '"'+(/^[\s\uFEFF]*[=+\-@]/u.test(v)?"'":'')+v.replaceAll('"','""')+'"';};
  const csv=[header.join(','),...reportRows.map(r=>r.map((value,i)=>cell(i===4?value.toFixed(2):value)).join(','))].join('\r\n');
  return '\ufeff'+csv;
}
const availableCMS="c.audience='general' AND c.content_type IN ('article','education','awareness','faq') AND c.review_status='published' AND (c.publish_at IS NULL OR c.publish_at<=?)";
function aiSources(query={}){
  return page(query,`SELECT c.id,c.title_en,c.content_type,s.approved_at, CASE WHEN s.approved_revision=c.revision AND (${availableCMS}) THEN 1 ELSE 0 END AS active
    FROM cms_content c LEFT JOIN ai_sources s ON s.content_id=c.id WHERE s.content_id IS NOT NULL OR (${availableCMS}) ORDER BY c.updated_at DESC,c.id`,[new Date().toISOString(),new Date().toISOString()]);
}
function changeSource(user,contentId,{approve}){
  bool(approve);
  return atomic(()=>{
    if(approve){
      const item=existing(db.prepare(`SELECT c.revision FROM cms_content c WHERE c.id=? AND ${availableCMS}`).get(contentId,new Date().toISOString()));
      db.prepare('INSERT INTO ai_sources (content_id,approved_by,approved_revision) VALUES (?,?,?) ON CONFLICT(content_id) DO UPDATE SET approved_by=excluded.approved_by,approved_revision=excluded.approved_revision,approved_at=CURRENT_TIMESTAMP').run(contentId,user.id,item.revision);
    }else if(!db.prepare('DELETE FROM ai_sources WHERE content_id=?').run(contentId).changes)fail(404,'not_found');
    audit(user,approve?'ai_source_approved':'ai_source_removed',{contentId});return {success:true};
  });
}
function publicSources(language){
  one(language,locales);
  return db.prepare(`SELECT c.title_${language} AS title,c.slug FROM cms_content c JOIN ai_sources s ON s.content_id=c.id AND s.approved_revision=c.revision WHERE ${availableCMS} ORDER BY s.approved_at DESC,c.id LIMIT 3`).all(new Date().toISOString());
}
function aiRun(outcome){
  db.prepare("INSERT INTO ai_run_daily(day,outcome,count) VALUES(date('now'),?,1) ON CONFLICT(day,outcome) DO UPDATE SET count=count+1").run(outcome);
}
function aiMetrics(){return db.prepare("SELECT outcome,sum(count) count FROM ai_run_daily WHERE day>=date('now','-6 days') GROUP BY outcome ORDER BY outcome").all();}
function permittedAudiences(user){
  if(user.role==='partner_admin')return db.prepare("SELECT 1 FROM organizations WHERE id=? AND is_verified=1 AND review_state='verified'").get(user.organizationId||'')?['partners']:[];
  return casesRoles.includes(user.role)?['staff','safeguarding']:['staff'];
}
function inbox(user,query){
  const recipient=permittedAudiences(user);
  if(!recipient.length)fail(403,'forbidden');
  return page(query,`SELECT n.id,n.template,n.audience,n.created_at,a.read_at FROM staff_announcements n LEFT JOIN staff_acknowledgements a ON a.announcement_id=n.id AND a.user_id=? WHERE n.status='active' AND n.audience IN (${recipient.map(()=>'?').join(',')}) ORDER BY n.created_at DESC,n.id`,[user.id,...recipient]);
}
function acknowledge(user,noticeId){
  return atomic(()=>{
    const row=db.prepare("SELECT audience FROM staff_announcements WHERE id=? AND status='active'").get(noticeId);
    if(!row || !permittedAudiences(user).includes(row.audience))fail(404,'not_found');
    db.prepare('INSERT OR IGNORE INTO staff_acknowledgements(user_id,announcement_id) VALUES (?,?)').run(user.id,noticeId);
    return {success:true};
  });
}
function notices(query){
  return page(query,`SELECT n.id,n.template,n.audience,n.status,n.created_at,(SELECT count(*) FROM staff_acknowledgements a WHERE a.announcement_id=n.id) read_count FROM staff_announcements n ORDER BY n.created_at DESC,n.id`);
}
function publishNotice(user,input){
  if(Object.keys(input).some(key=>!['template','audience'].includes(key)))fail(400,'invalid_input');
  const {template,audience}=input;
  return atomic(()=>{
    const noticeId=id('msg');
    db.prepare('INSERT INTO staff_announcements(id,template,audience,published_by) VALUES (?,?,?,?)').run(noticeId,one(template,templates),one(audience,audiences),user.id);
    audit(user,'notice_published',{noticeId,template,audience});return {id:noticeId};
  });
}
function withdrawNotice(user,noticeId){
  return atomic(()=>{
    if(!db.prepare("UPDATE staff_announcements SET status='withdrawn' WHERE id=? AND status='active'").run(noticeId).changes)fail(404,'not_found');
    audit(user,'notice_withdrawn',{noticeId});return {success:true};
  });
}
module.exports={getConfig,changeConfig,publicConfig,finance,financeDetail,financeSave,financeTransition,financeExport,aiSources,changeSource,publicSources,aiRun,aiMetrics,inbox,acknowledge,notices,publishNotice,withdrawNotice};
