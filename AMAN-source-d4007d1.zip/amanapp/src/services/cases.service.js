const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { db } = require('../db/database');
const security = require('../middleware/security');
const auth = require('./auth.service');
const { has } = require('../admin/permissions');
const { fail, text, one, existing, atomic, audit, page } = require('../admin/shared');

const AUDIO_DIR = path.resolve(process.env.AMAN_AUDIO_DIR || path.join(__dirname, '..', '..', 'data', 'audio'));
const VALID_STATUSES = ['NEW','RECEIVED','INITIAL_REVIEW','HUMAN_ASSESSMENT','ACTION_REQUIRED','REFERRED','FOLLOW_UP','RESOLVED','CLOSED'];
const GROUPS = ['women','girls','child'];
const URGENCIES = ['low','normal','high','urgent'];
const LANGS = ['ar','fr','en'];
const id = prefix => `${prefix}_${crypto.randomUUID()}`;
const enc = security.encryptSensitive;
const dec = security.decryptSensitive;
const digest = auth.tokenDigest;
const metadata = 'id,reference_code,beneficiary_group,category,urgency,preferred_language,submission_method,status,assigned_to,created_at,updated_at';

function submitHelpRequest({ beneficiaryGroup = 'women', category = 'general', urgency = 'normal', preferredLanguage = 'ar', submissionMethod = 'written', description = '', safeContact = '', city = '' }) {
  one(beneficiaryGroup, GROUPS); one(urgency, URGENCIES); one(preferredLanguage, LANGS);
  one(submissionMethod, ['written','audio','voice_to_text','callback']);
  const caseId = id('case');
  const prefix = { women: 'AMW', girls: 'AMG', child: 'AMC' }[beneficiaryGroup];
  const referenceCode = `${prefix}-${crypto.randomBytes(16).toString('hex').toUpperCase()}`;
  const audioUploadToken = submissionMethod === 'audio' ? security.generateSecureToken(32) : null;
  db.prepare(`INSERT INTO help_requests (id,reference_code,beneficiary_group,category,urgency,preferred_language,submission_method,description,safe_contact,city,audio_upload_digest,audio_upload_expires)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(caseId, referenceCode, beneficiaryGroup, text(category,120,1), urgency, preferredLanguage, submissionMethod,
    enc(text(description, 10000)), enc(text(safeContact, 500)), enc(text(city,100)), audioUploadToken && digest(audioUploadToken), audioUploadToken && new Date(Date.now()+15*60_000).toISOString());
  security.logAudit('help_request_submitted', { caseId });
  return { id:caseId, referenceCode, status:'NEW', beneficiaryGroup, createdAt:new Date().toISOString(), ...(audioUploadToken && { audioUploadToken }) };
}
function saveAudioReport({ caseId, audioUploadToken, base64Audio, mimeType = 'audio/webm', durationSeconds = 0, language = 'ar' }) {
  const mime = one(mimeType, ['audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav']);
  one(language, LANGS);
  if (!Number.isFinite(durationSeconds) || durationSeconds < 0 || durationSeconds > 3600) fail(400, 'invalid_audio');
  if (typeof audioUploadToken !== 'string' || !/^[a-f0-9]{64}$/.test(audioUploadToken)) fail(403, 'forbidden');
  if (typeof base64Audio !== 'string' || base64Audio.length > Math.ceil(10*1024*1024/3)*4) fail(400, 'invalid_audio');
  const buffer = Buffer.from(base64Audio,'base64');
  if (!buffer.length || buffer.length > 10*1024*1024 || buffer.toString('base64') !== base64Audio) fail(400, 'invalid_audio');
  let filePath;
  try {
    return atomic(() => {
      const updated = db.prepare('UPDATE help_requests SET audio_upload_digest=NULL,audio_upload_expires=NULL WHERE id=? AND audio_upload_digest=? AND audio_upload_expires>?').run(text(caseId,80,1), digest(audioUploadToken), new Date().toISOString());
      if (!updated.changes) fail(403, 'forbidden');
      const audioId = id('aud');
      const fileRef = `${audioId}.enc`;
      fs.mkdirSync(AUDIO_DIR,{ recursive:true, mode:0o700 });
      filePath = path.join(AUDIO_DIR,fileRef);
      fs.writeFileSync(filePath,enc(base64Audio),{ flag:'wx',mode:0o600 });
      db.prepare('INSERT INTO audio_reports (id,case_id,file_ref,mime_type,duration_seconds,language,retention_until) VALUES (?,?,?,?,?,?,?)')
        .run(audioId,caseId,fileRef,mime,durationSeconds,language,new Date(Date.now()+90*86400_000).toISOString());
      return { id: audioId, caseId, durationSeconds, language };
    });
  } catch (error) { if (filePath) fs.rmSync(filePath,{force:true}); throw error; }
}
function getPublicFollowUp(referenceCode) {
  const ref = typeof referenceCode === 'string' && referenceCode.trim().toUpperCase();
  if (!ref || !/^AM[WGC]-[0-9A-F]{32}$/.test(ref)) return null;
  return db.prepare(`SELECT reference_code AS referenceCode, beneficiary_group AS beneficiaryGroup, status, updated_at AS updatedAt, created_at AS createdAt
    FROM help_requests WHERE reference_code=?`).get(ref) || null;
}
function listCasesPage(user, query = {}) {
  if (!has(user,'cases.view')) fail(403,'forbidden');
  const where = [], args = [];
  const groupByRole = { women_caseworker:'women', girls_caseworker:'girls', child_caseworker:'child' };
  if (user.role !== 'safeguarding_supervisor') { where.push('assigned_to=?'); args.push(user.id); }
  if (groupByRole[user.role]) { where.push('beneficiary_group=?'); args.push(groupByRole[user.role]); }
  if (query.group) { where.push('beneficiary_group=?'); args.push(one(query.group,GROUPS)); }
  if (query.status) { where.push('status=?'); args.push(one(query.status,VALID_STATUSES)); }
  if (query.urgency) { where.push('urgency=?'); args.push(one(query.urgency,URGENCIES)); }
  if (query.q) { where.push('instr(lower(reference_code),lower(?))>0'); args.push(text(query.q,80)); }
  const result = page(query,`SELECT ${metadata} FROM help_requests ${where.length ? 'WHERE '+where.join(' AND ') : ''} ORDER BY created_at DESC,id`,args);
  audit(user,'case_queue_viewed',{ count:result.items.length });
  return result;
}
const listCasesForUser = (user, filters) => listCasesPage(user, filters).items;
function authorizedCase(user, caseId, capability = 'view') {
  if (!has(user,`cases.${capability}`)) fail(403, 'forbidden');
  const row = db.prepare('SELECT * FROM help_requests WHERE id=?').get(caseId);
  if (!auth.canAccessCase(user,row,capability)) fail(404,'not_found');
  return row;
}
function getCase(user, caseId) {
  const row = authorizedCase(user,caseId);
  audit(user,'case_accessed',{ caseId });
  return {
    ...db.prepare(`SELECT ${metadata} FROM help_requests WHERE id=?`).get(caseId),
    description:dec(row.description), safe_contact:dec(row.safe_contact), city:dec(row.city), closure_reason:dec(row.closure_reason), reopen_reason:dec(row.reopen_reason),
    notes:db.prepare('SELECT id,note_type,content,created_at FROM case_notes WHERE case_id=? ORDER BY created_at DESC,id LIMIT 100').all(caseId).map(n=>({...n,content:dec(n.content)})),
    referrals:db.prepare('SELECT r.id,o.name_en AS organization,r.status,r.notes,r.response_notes,r.created_at,r.updated_at FROM referrals r JOIN organizations o ON r.organization_id=o.id WHERE r.case_id=? ORDER BY r.created_at DESC,r.id LIMIT 100').all(caseId).map(r=>({...r,notes:dec(r.notes),response_notes:dec(r.response_notes)})),
    audio:db.prepare('SELECT id,mime_type,duration_seconds,created_at FROM audio_reports WHERE case_id=? AND retention_until>? ORDER BY created_at DESC LIMIT 20').all(caseId,new Date().toISOString())
  };
}
function updateCaseStatus(user, caseId, { status, reason = '', assignedTo = null }) {
  return atomic(() => {
    const row = authorizedCase(user,caseId,'edit');
    one(status,VALID_STATUSES);
    const reopening = row.status === 'CLOSED' || (row.status === 'RESOLVED' && status !== 'CLOSED');
    if (reopening) {
      if (!has(user,'cases.reopen') || status !== 'INITIAL_REVIEW' || assignedTo !== null) fail(403,'forbidden');
      reason = text(reason,2000,5);
      db.prepare("UPDATE help_requests SET reopen_reason=?,closure_reason=NULL WHERE id=?").run(enc(reason),caseId);
    } else {
      const next = VALID_STATUSES[VALID_STATUSES.indexOf(row.status)+1];
      // Referrals come from the referral endpoint; optional for an internal follow-up.
      if (status === 'REFERRED' || (status !== next && !(row.status === 'ACTION_REQUIRED' && status === 'FOLLOW_UP'))) fail(409,'invalid_transition');
      if (status === 'ACTION_REQUIRED') {
        if (!has(user,'cases.assign')) fail(403,'forbidden');
        const staff = db.prepare('SELECT id,role FROM users WHERE is_active=1 AND mfa_enabled=1 AND id=?').get(text(assignedTo,80,1));
        const expectedRole = { women:'women_caseworker', girls:'girls_caseworker', child:'child_caseworker' }[row.beneficiary_group];
        if (!staff || ![expectedRole,'authorized_professional'].includes(staff.role) || !has(staff,'cases.view')) fail(400,'invalid_assignee');
      } else if (assignedTo !== null) fail(400,'invalid_assignee');
      if (status === 'RESOLVED' || status === 'CLOSED') db.prepare('UPDATE help_requests SET closure_reason=? WHERE id=?').run(enc(text(reason,2000,5)),caseId);
    }
    db.prepare('UPDATE help_requests SET status=?,assigned_to=COALESCE(?,assigned_to),updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,assignedTo,caseId);
    audit(user,'case_status_updated',{caseId,from:row.status,to:status,assignedTo});
    return db.prepare(`SELECT ${metadata} FROM help_requests WHERE id=?`).get(caseId);
  });
}
function addCaseNote(user, caseId, { content, noteType = 'assessment' }) {
  return atomic(() => {
    const row = authorizedCase(user,caseId,'edit');
    if (row.status === 'CLOSED') fail(409,'invalid_transition');
    one(noteType,['assessment','follow_up','action']);
    const noteId = id('note');
    db.prepare('INSERT INTO case_notes (id,case_id,author_id,note_type,content) VALUES (?,?,?,?,?)').run(noteId,caseId,user.id,noteType,enc(text(content,5000,1)));
    audit(user,'case_note_added',{caseId,noteId});
    return { id:noteId };
  });
}
function getAudioFileForUser(user,audioId) {
  if (!has(user,'cases.view')) fail(403,'forbidden');
  const audio = existing(db.prepare('SELECT * FROM audio_reports WHERE id=? AND retention_until>?').get(audioId,new Date().toISOString()));
  authorizedCase(user,audio.case_id);
  if (!/^aud_[a-f0-9-]+\.(enc|webm|ogg|mp4|mpeg|wav)$/.test(audio.file_ref)) fail(404,'not_found');
  const filePath = path.join(AUDIO_DIR,audio.file_ref);
  if (!fs.existsSync(filePath)) fail(404,'not_found');
  const raw = fs.readFileSync(filePath);
  const decrypted = audio.file_ref.endsWith('.enc') ? dec(raw.toString('utf8')) : null;
  if (decrypted === '[DECRYPTION_ERROR]') fail(500,'audio_unavailable');
  audit(user,'audio_accessed',{audioId,caseId:audio.case_id});
  return { buffer:decrypted === null ? raw : Buffer.from(decrypted,'base64'), mimeType:audio.mime_type };
}
function redactCaseData(user,caseId) {
  const refs = atomic(() => {
    authorizedCase(user,caseId,'redact');
    const audio = db.prepare('SELECT file_ref FROM audio_reports WHERE case_id=?').all(caseId);
    db.prepare('DELETE FROM audio_reports WHERE case_id=?').run(caseId);
    db.prepare('DELETE FROM case_notes WHERE case_id=?').run(caseId);
    db.prepare('UPDATE referrals SET notes=NULL,response_notes=NULL WHERE case_id=?').run(caseId);
    db.prepare("UPDATE help_requests SET description='[REDACTED]', safe_contact='',city='',closure_reason=NULL,reopen_reason=NULL,audio_upload_digest=NULL,audio_upload_expires=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(caseId);
    audit(user,'case_redacted',{caseId});
    return audio;
  });
  for (const {file_ref} of refs) if (/^aud_[a-f0-9-]+\.(enc|webm|ogg|mp4|mpeg|wav)$/.test(file_ref)) fs.rmSync(path.join(AUDIO_DIR,file_ref),{force:true});
  return { success:true, caseId, redacted:true };
}
module.exports = { VALID_STATUSES, GROUPS, URGENCIES, submitHelpRequest, saveAudioReport, getPublicFollowUp, listCasesForUser, listCasesPage, getCase, authorizedCase, updateCaseStatus, addCaseNote, getAudioFileForUser, redactCaseData };
