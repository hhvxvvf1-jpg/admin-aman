const crypto = require('node:crypto');
const { db } = require('../db/database');
const security = require('../middleware/security');
const { has } = require('../admin/permissions');
const { fail, text, one, existing, atomic, audit, page } = require('../admin/shared');
const { authorizedCase } = require('./cases.service');
const LISTING = 'id,name_ar,name_fr,name_en,category,city,region,address,phone,operating_hours,accessibility_info,latitude,longitude,is_verified';
const STATES = ['pending','verified','rejected','suspended'];
function publicDirectory({region='',category='',city=''} = {}) {
  const search = text(city,120);
  return db.prepare(`SELECT ${LISTING} FROM organizations WHERE is_verified=1 AND review_state='verified' AND public_listing=1
    AND (?='' OR region=?) AND (?='' OR category=?) AND (?='' OR instr(lower(city),lower(?))>0) ORDER BY city,name_en LIMIT 200`)
    .all(text(region,120),region,text(category,100),category,search,search);
}
function profile(input) {
  const { nameAr='', nameFr='', nameEn='', category='ngo', city='', region='', address='', phone='', email='', operatingHours='', accessibilityInfo='', latitude=null, longitude=null } = input;
  const fallback = nameEn || nameFr || nameAr;
  function coordinate(n,max) { if (n===null || n==='') return null; if (typeof n !== 'number' || !Number.isFinite(n) || Math.abs(n)>max) fail(400,'invalid_coordinates'); return n; }
  const lat=coordinate(latitude,90), lng=coordinate(longitude,180);
  if ((lat===null)!==(lng===null)) fail(400,'invalid_coordinates');
  return [text(nameAr||fallback,160,1),text(nameFr||fallback,160,1),text(nameEn||fallback,160,1),text(category,100,1),text(city,120,1),text(region,120,1),text(address,250),text(phone,80),text(email,254),text(operatingHours,200),text(accessibilityInfo,500),lat,lng];
}
function registerPartner(input, user) {
  const vals = profile(input);
  return atomic(() => {
    const id='org_'+crypto.randomUUID();
    db.prepare(`INSERT INTO organizations (id,name_ar,name_fr,name_en,category,city,region,address,phone,email,operating_hours,accessibility_info,latitude,longitude) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id,...vals);
    audit(user || {id:null},'partner_registered',{orgId:id});
    return { id, review_state:'pending' };
  });
}
function listAdmin(query) {
  const state=query.state ? one(query.state,STATES) : '';
  const q=text(query.q || '',160);
  return page(query,`SELECT id,name_en,category,city,region,review_state,public_listing FROM organizations WHERE (?='' OR review_state=?) AND (?='' OR instr(lower(name_en||' '||name_ar||' '||name_fr||' '||city),lower(?))>0) ORDER BY created_at DESC,id`,[state,state,q,q]);
}
function detail(id) { return existing(db.prepare('SELECT * FROM organizations WHERE id=?').get(id)); }
function edit(user,id,input) {
  return atomic(() => {
    detail(id);
    db.prepare(`UPDATE organizations SET name_ar=?,name_fr=?,name_en=?,category=?,city=?,region=?,address=?,phone=?,email=?,operating_hours=?,accessibility_info=?,latitude=?,longitude=?,review_state='pending',is_verified=0,verified_at=NULL,verified_by=NULL,verification_ref=NULL,public_listing=0 WHERE id=?`).run(...profile(input),id);
    audit(user,'partner_profile_updated',{orgId:id});
    return detail(id);
  });
}
function review(user,id,{state, evidence='', publicListing=false}) {
  return atomic(() => {
    detail(id);
    one(state,STATES.slice(1));
    const ref=text(evidence,300,5);
    if (typeof publicListing !== 'boolean' || (state !== 'verified' && publicListing)) fail(400,'invalid_input');
    db.prepare(`UPDATE organizations SET review_state=?,verification_ref=?,is_verified=?,verified_by=?,verified_at=CASE WHEN ?=1 THEN CURRENT_TIMESTAMP ELSE NULL END,public_listing=? WHERE id=?`)
      .run(state,ref,Number(state==='verified'),user.id,Number(state==='verified'),Number(publicListing),id);
    audit(user,'partner_reviewed',{orgId:id,state,publicListing});
    return detail(id);
  });
}
function createReferral(user,{caseId,organizationId,notes=''}) {
  return atomic(() => {
    const record=authorizedCase(user,text(caseId,80,1),'refer');
    if (record.status !== 'ACTION_REQUIRED') fail(409,'invalid_transition');
    if (!db.prepare("SELECT 1 FROM organizations WHERE id=? AND is_verified=1 AND review_state='verified'").get(text(organizationId,80,1))) fail(400,'organization_not_verified');
    const id='ref_'+crypto.randomUUID();
    db.prepare('INSERT INTO referrals (id,case_id,organization_id,referred_by,notes) VALUES (?,?,?,?,?)').run(id,caseId,organizationId,user.id,security.encryptSensitive(text(notes,3000)));
    db.prepare("UPDATE help_requests SET status='REFERRED',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(caseId);
    audit(user,'referral_created',{referralId:id,caseId,organizationId});
    return { id, status:'PENDING' };
  });
}
function partnerOrganization(user, perm) {
  if (!has(user,perm) || !db.prepare("SELECT 1 FROM organizations WHERE id=? AND review_state='verified' AND is_verified=1").get(user.organizationId || '')) fail(403,'forbidden');
  return user.organizationId;
}
function referrals(user, query) {
  const organizationId=partnerOrganization(user,'referrals.view');
  return page(query,'SELECT id,status,created_at,updated_at FROM referrals WHERE organization_id=? ORDER BY created_at DESC,id',[organizationId]);
}
function respondToReferral(user,id,{status}) {
  return atomic(() => {
    const organizationId=partnerOrganization(user,'referrals.edit');
    const record=existing(db.prepare('SELECT status FROM referrals WHERE id=? AND organization_id=?').get(id,organizationId));
    const allowed={PENDING:['ACCEPTED','REJECTED'],ACCEPTED:['COMPLETED']}[record.status] || [];
    if (!allowed.includes(status)) fail(409,'invalid_transition');
    db.prepare('UPDATE referrals SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,id);
    audit(user,'referral_responded',{referralId:id,status});
    return { id,status };
  });
}
module.exports = { listDirectory:publicDirectory, registerPartner, listAdmin, detail, edit, review, createReferral, respondToReferral, referrals, STATES };
