const crypto = require('node:crypto');
const { db } = require('../db/database');
const security = require('../middleware/security');
const { isStaff, has } = require('../admin/permissions');
const { verify } = require('../admin/mfa');

const ROLES = {
  SUPER_ADMIN: 'super_admin', PLATFORM_ADMIN: 'platform_admin', SAFEGUARDING_SUPERVISOR: 'safeguarding_supervisor',
  WOMEN_CASEWORKER: 'women_caseworker', CHILD_CASEWORKER: 'child_caseworker', GIRLS_CASEWORKER: 'girls_caseworker',
  PARTNER_ADMIN: 'partner_admin', AUTHORIZED_PROFESSIONAL: 'authorized_professional', CONTENT_MANAGER: 'content_manager',
  AUDITOR: 'auditor', MODERATOR: 'moderator', TECH_SUPPORT: 'tech_support', MEMBER: 'member'
};
const CASE_ACCESS_ROLES = new Set([ROLES.SAFEGUARDING_SUPERVISOR, ROLES.WOMEN_CASEWORKER, ROLES.CHILD_CASEWORKER, ROLES.GIRLS_CASEWORKER, ROLES.AUTHORIZED_PROFESSIONAL]);
const tokenDigest = token => crypto.createHash('sha256').update(token).digest('hex');
const dummyHash = security.hashPassword(crypto.randomBytes(24).toString('hex'));

function registerUser({ email, password, fullName, role = ROLES.MEMBER, organizationId = null }) {
  if (typeof email !== 'string' || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || typeof password !== 'string' || password.length < 14 || password.length > 128) throw new Error('Valid email and a password of 14–128 characters required');
  if (!Object.values(ROLES).includes(role) || !security.sanitizeText(fullName) || fullName.length > 160) throw new Error('Invalid staff name or role');
  const id = 'usr_' + crypto.randomUUID();
  email = email.toLowerCase();
  db.prepare('INSERT INTO users (id,email,password_hash,full_name,role,organization_id) VALUES (?,?,?,?,?,?)')
    .run(id, email, security.hashPassword(password), security.sanitizeText(fullName), role, organizationId);
  security.logAudit('user_registered', { userId: id, role }, null, id);
  return { id, email, fullName, role, organizationId };
}

function identity(user) {
  return { id: user.id, email: user.email, fullName: user.full_name, role: user.role, organizationId: user.organization_id };
}
function login({ email, password, otp, ipAddress }) {
  const normalized = typeof email === 'string' ? email.trim().toLowerCase().slice(0, 254) : '';
  if (!security.checkRateLimit(`auth-account:${tokenDigest(normalized)}`, 8, 300_000)) throw new Error('rate_limited');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(normalized);
  function reject() {
    security.logAudit('login_failed', {}, ipAddress, user?.id || null);
    throw new Error('invalid_credentials_or_code');
  }
  const ok = typeof password === 'string' && password.length <= 128 && security.verifyPassword(password, user?.password_hash || dummyHash);
  if (!ok || !user?.is_active || (!isStaff(user.role) && user.role !== 'member')) reject();
  const staff = isStaff(user.role);
  if (staff) {
    const step = verify(security.decryptSensitive(user.mfa_secret), otp, user.mfa_last_step);
    if (!user.mfa_enabled || step === null) reject();
    const updated = db.prepare('UPDATE users SET mfa_last_step=? WHERE id=? AND mfa_last_step<?').run(step, user.id, step);
    if (!updated.changes) reject();
  }
  const token = security.generateSecureToken(32);
  const expiresInMs = (staff ? 60 : 720) * 60_000;
  const expiresAt = new Date(Date.now() + expiresInMs).toISOString();
  db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(new Date().toISOString());
  db.prepare('INSERT INTO sessions (token,user_id,expires_at,ip_address,mfa_verified) VALUES (?,?,?,?,?)')
    .run(tokenDigest(token), user.id, expiresAt, ipAddress ? security.hashIp(ipAddress) : null, staff ? 1 : 0);
  db.prepare('UPDATE users SET last_login_at=CURRENT_TIMESTAMP WHERE id=?').run(user.id);
  security.logAudit('login_success', { role: user.role }, ipAddress, user.id);
  return { token, expiresAt, expiresInMs, user: identity(user) };
}
function getSessionUser(req) {
  const header = req.headers.authorization || '';
  const token = /^Bearer ([a-f0-9]{64})$/.exec(header)?.[1];
  if (!token) return null;
  const session = db.prepare(`SELECT s.mfa_verified, u.* FROM sessions s JOIN users u ON u.id=s.user_id
    WHERE s.token=? AND s.expires_at>? AND u.is_active=1`).get(tokenDigest(token), new Date().toISOString());
  if (!session || (isStaff(session.role) && (!session.mfa_enabled || !session.mfa_verified))) return null;
  return identity(session);
}
function logout(token, actorId) {
  if (typeof token === 'string' && /^[a-f0-9]{64}$/.test(token)) {
    db.prepare('DELETE FROM sessions WHERE token=?').run(tokenDigest(token));
    if (actorId) security.logAudit('logout', {}, null, actorId);
  }
}
function withinCaseScope(user, record) {
  if (!user || !record) return false;
  switch (user.role) {
    case ROLES.SAFEGUARDING_SUPERVISOR: return true;
    case ROLES.WOMEN_CASEWORKER: return record.beneficiary_group === 'women' && record.assigned_to === user.id;
    case ROLES.GIRLS_CASEWORKER: return record.beneficiary_group === 'girls' && record.assigned_to === user.id;
    case ROLES.CHILD_CASEWORKER: return record.beneficiary_group === 'child' && record.assigned_to === user.id;
    case ROLES.AUTHORIZED_PROFESSIONAL: return record.assigned_to === user.id;
    default: return false;
  }
}
function canAccessCase(user, record, capability = 'view') {
  return withinCaseScope(user, record) && has(user, 'cases.view') && has(user, `cases.${capability}`);
}
module.exports = { ROLES, CASE_ACCESS_ROLES, registerUser, login, getSessionUser, logout, canAccessCase, withinCaseScope, tokenDigest };
