const crypto=require('node:crypto');
const {db}=require('../db/database');
const auth=require('./auth.service');
const {has}=require('../admin/permissions');
const mfa=require('../admin/mfa');
const security=require('../middleware/security');
const {atomic,audit,existing,fail,one,page,text}=require('../admin/shared');
const inviteRoles=['platform_admin','content_manager','moderator','auditor','tech_support'];
const digest=code=>crypto.createHash('sha256').update(code).digest('hex');
const date=()=>new Date().toISOString();
const fields="id,email,full_name,role,created_at,expires_at,CASE WHEN state='pending' AND expires_at<=? THEN 'expired' ELSE state END AS state";
function list(query){return page(query,`SELECT ${fields} FROM staff_invitations ORDER BY created_at DESC,id`,[date()]);}
function issue(actor,input){
  const email=text(input.email,254,3).toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))fail(400,'invalid_input');
  const fullName=security.sanitizeText(text(input.fullName,100,1));
  if(!fullName)fail(400,'invalid_input');
  const role=one(input.role,inviteRoles);
  return atomic(()=>{
    const now=date();
    if(db.prepare('SELECT 1 FROM users WHERE email=?').get(email))fail(409,'staff_email_unavailable');
    if(db.prepare("SELECT 1 FROM staff_invitations WHERE email=? AND state='pending' AND expires_at>?").get(email,now))fail(409,'staff_invite_exists');
    const id=crypto.randomUUID(),code=crypto.randomBytes(24).toString('hex'),expiresAt=new Date(Date.now()+30*60_000).toISOString();
    db.prepare('INSERT INTO staff_invitations(id,token_hash,email,full_name,role,issued_by,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?)').run(id,digest(code),email,fullName,role,actor.id,now,expiresAt);
    audit(actor,'staff_invitation_issued',{invitationId:id,role});return {id,code,expiresAt};
  });
}
function clearProof(id,newState){db.prepare('UPDATE staff_invitations SET state=?,enrollment_nonce=NULL,enrollment_secret=NULL,enrollment_expires_at=NULL WHERE id=?').run(newState,id);}
function revoke(actor,id){return atomic(()=>{
  const row=existing(db.prepare('SELECT state,expires_at FROM staff_invitations WHERE id=?').get(id));
  if(row.state!=='pending')fail(409,'invalid_revision_or_state');
  clearProof(id,'revoked');audit(actor,'staff_invitation_revoked',{invitationId:id});return {id,state:'revoked'};
});}
function ticket(code){
  if(typeof code!=='string'||!/^[a-f0-9]{48}$/i.test(code))fail(400,'staff_invite_invalid');
  const row=db.prepare("SELECT * FROM staff_invitations WHERE token_hash=? AND state='pending' AND expires_at>?").get(digest(code.toLowerCase()),date());
  const issuer=row&&db.prepare('SELECT id,role,is_active,mfa_enabled FROM users WHERE id=?').get(row.issued_by);
  if(!row||!issuer?.is_active||!issuer.mfa_enabled||!has(issuer,'staff.invite')||db.prepare('SELECT 1 FROM users WHERE email=?').get(row.email))fail(400,'staff_invite_invalid');
  return row;
}
function begin({code}){return atomic(()=>{
  const row=ticket(code),secret=crypto.randomBytes(20),nonce=crypto.randomBytes(16).toString('hex');
  const expiresAt=new Date(Math.min(Date.parse(row.expires_at),Date.now()+10*60_000)).toISOString();
  db.prepare('UPDATE staff_invitations SET enrollment_secret=?,enrollment_nonce=?,enrollment_expires_at=? WHERE id=?').run(security.encryptSensitive(secret.toString('hex')),nonce,expiresAt,row.id);
  const key=mfa.encodeBase32(secret);secret.fill(0);return {email:row.email,key,nonce};
});}
function redeem({code,nonce,otp,password}){return atomic(()=>{
  const row=ticket(code);
  if(typeof nonce!=='string'||nonce!==row.enrollment_nonce||!row.enrollment_expires_at||row.enrollment_expires_at<=date())fail(400,'staff_invite_invalid');
  if(typeof password!=='string'||password.length<14||password.length>128)fail(400,'invalid_input');
  const secret=security.decryptSensitive(row.enrollment_secret),step=mfa.verify(secret,otp,-1);
  if(step===null)fail(400,'staff_invite_code_invalid');
  const user=auth.registerUser({email:row.email,fullName:row.full_name,password,role:row.role});
  db.prepare('UPDATE users SET mfa_enabled=1,mfa_secret=?,mfa_last_step=? WHERE id=?').run(row.enrollment_secret,step,user.id);
  clearProof(row.id,'redeemed');audit(user,'staff_invitation_redeemed',{invitationId:row.id,role:row.role});return {created:true};
});}
module.exports={list,issue,revoke,begin,redeem};
