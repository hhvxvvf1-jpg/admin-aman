# AMAN — administration deployment and handover

This branch extends the existing Node/SQLite application. It is suitable for **local or synthetic-data staging**, not cleared for live safeguarding operations. No changes have been deployed to the linked site.

## Run locally

Requires Node.js **22.13+** (Node 22 LTS recommended); no runtime npm dependencies. From the AMAN repository root:

```bash
cp .env.example .env
mkdir -p data
chmod 700 data
chmod 600 .env
node --env-file=.env server.js
```

Open `http://localhost:3000/admin/`. The existing public PWA is still at `/`. No admin account or default password is shipped. For a **new** environment, generate a unique value with `node -p "require('node:crypto').randomBytes(32).toString('hex')"` and put it in `AMAN_ENCRYPTION_KEY` before enrollment. For an **existing** environment, first identify the encryption key used for existing records. Replacing that key does not re-encrypt old data and can make it unreadable. A legacy development fallback or non-hex key requires an approved key-migration plan before production.

### Enroll and recover staff

Run on a trusted admin terminal; use a secret prompt or password manager and avoid password arguments, shell history, recordings, and CI logs:

```bash
# Bash; enter a unique password of 14–128 characters at the prompt.
read -rs -p 'New staff password: ' AMAN_STAFF_PASSWORD; printf '\n'
printf '%s' "$AMAN_STAFF_PASSWORD" | node --env-file=.env scripts/staff.js create admin@example.test super_admin 'AMAN Administrator'
unset AMAN_STAFF_PASSWORD
```

The command prints a TOTP enrollment secret **once**. Transfer it privately to the named operator for enrollment in an authenticator (six digits, SHA-1, 30 seconds); then clear the terminal output. Do not send or log it. Provision a separate `content_manager` or `platform_admin` account for authoring and independent review. Provision safeguarding staff separately with `safeguarding_supervisor`, `women_caseworker`, `girls_caseworker`, or `child_caseworker`. To enroll an existing account or recover a lost authenticator, use the same password prompt with `scripts/staff.js recover STAFF_EMAIL`. This replaces the password and MFA secret and revokes all sessions. Provisioning and recovery require verified out-of-band identity checks and are not self-service. For `partner_admin`, provide the verified organization ID as the final argument to `create`.

### GitHub Pages vs. the application server

GitHub Pages hosts only the static public site; it cannot run Node.js or open SQLite. The Pages workflow now copies an explicit public asset allowlist into `dist/pages` and excludes backend source and the real admin client. It generates only a static `/admin/` notice or link. After verifying the real server and HTTPS, set `AMAN_ADMIN_URL` as a GitHub Actions repository variable to the official `https://YOUR_HOST/admin/` and rerun Pages. To run the connected public APIs and administration together, deploy **this repo’s Node server** to a stateful host with persistent storage and HTTPS. The browser expects a same-origin `/api` and `/admin/`; don’t expose the database to Pages or commit it. If using a separate Pages site, keep it a public information site or plan a separate, reviewed integration. Its static deployment does not offer live intake, a service directory, or the connected CMS.

### If you only have GitHub Pages: managed staging on Render

This repository contains `render.yaml` for a paid Node web service with a persistent disk. Use it for synthetic staging only. This configuration has not been deployed to a Render account from this workspace.

1. Apply the Git patch to a new branch, push it to your GitHub repository, and review it. In your Render account, select **New → Blueprint**, connect the AMAN repo, and select the branch containing `render.yaml`. Review the price before confirming; do not use a free service or an ephemeral disk for this SQLite build.
2. Generate the new environment's hex key locally with `node -p "require('node:crypto').randomBytes(32).toString('hex')"`. Enter it as the `AMAN_ENCRYPTION_KEY` prompt in the Render dashboard, privately. Keep `AMAN_SENSITIVE_INTAKE=0`.
3. When `/api/health` is healthy, open the service’s **Shell** and use the enrollment procedure above to create your own staff account and enroll MFA. Your official URL is the service’s HTTPS address plus `/admin/`. Never share the MFA secret, password, or encryption key.
4. Verify the URL using generated records only. Then merge the reviewed branch and, under GitHub **Settings → Secrets and variables → Actions → Variables**, create `AMAN_ADMIN_URL` with the official HTTPS URL ending in `/admin/`. Run the Pages workflow to publish the link. Unauthenticated requests to `/api/admin/dashboard` must return HTTP 401.

Read [Render’s persistent disk docs](https://render.com/docs/disks) and the [Blueprint spec](https://render.com/docs/blueprint-spec). The included region is for staging, not a decision about lawful hosting of real beneficiary records.

### Deploy the permanent admin server on a VPS

Use a VPS with Docker Engine and Compose, a DNS name pointed at the VPS, and incoming ports 80 and 443 open. Upload or clone this branch; keep `.env` private. Set `AMAN_DOMAIN` to the confirmed host name without a scheme or path and `AMAN_ENCRYPTION_KEY` as described above. Then run:

```bash
docker compose up --build -d
docker compose ps
curl -fsS "https://YOUR_HOST/api/health"
```

Compose keeps SQLite and audio in the persistent `aman_data` volume and exposes only the Caddy HTTPS entry point. Do not run `docker compose down -v` against an environment that needs to retain data. The shipped Compose configuration keeps sensitive intake off. To enroll the first privileged user, run the private password prompt in the setup section, but use this command for the final pipe (do not run both enrollment commands):

```bash
printf '%s' "$AMAN_STAFF_PASSWORD" | docker compose exec -T aman node scripts/staff.js create admin@example.test super_admin 'AMAN Administrator'
unset AMAN_STAFF_PASSWORD
```

Open `https://YOUR_HOST/admin/`, enroll MFA, and test with synthetic records. Only after verifying this address should you set the Pages Actions variable and redeploy Pages. Do not set it to an Arena preview address or share any deployment credentials in chat.

### Migration and security checklist

1. Before the first startup on a legacy database, make an encrypted offline backup and rehearse the upgrade and rollback on a sanitized copy. Migrations apply transactionally at startup without changing existing case IDs. Migration `admin-001` invalidates legacy sessions and returns previous CMS publications and directory verifications to review because the previous schema did not retain reliable verification evidence. Public short legacy follow-up codes are no longer accepted; arrange assisted follow-up through an approved process for users affected by this change.
2. Re-enroll staff. Configure a reverse proxy with HTTPS and HTTP request/connection limits; ensure the Node listener is reachable only through that proxy. Set `AMAN_TRUST_PROXY=1` **only** if the proxy overwrites `X-Forwarded-For` and cannot be bypassed. Run under an unprivileged account. Use private, encrypted volumes and restrictive filesystem permissions (`umask 077`). Do not log request bodies, bearer tokens, TOTP secrets or follow-up URLs.
3. Existing plaintext audio, notes, referral notes and some metadata are not retroactively re-encrypted by this migration. Review and migrate or lawfully remove legacy material before using live data. Audit rows are access-controlled in the application, not tamper-proof against direct database or host access. Send minimal audit signals to an approved separately controlled system for production. Per-process rate limits are not distributed.
4. Validate review capacity, access controls, staffing, emergency routes, verification evidence, safe communication, retention, hosting/transfers, deletion, and incident handling with qualified safeguarding and legal reviewers. Confirm applicable Moroccan Law 09-08 and CNDP formalities/authorizations. This release does not certify compliance. Keep `AMAN_SENSITIVE_INTAKE=0`; in production the server rejects case/audio/specialist intake unless explicitly enabled. Setting this flag is not a substitute for approval.

### Backup and rollback

`scripts/backup.js` supports an authenticated encrypted export of the SQLite database and all database-referenced audio. Generate a separate 32-byte hex `AMAN_BACKUP_KEY` and keep it protected separately from the backup file and the original application encryption key. The application key is not included in the snapshot. Use a protected encrypted volume for the operating-system temporary directory and the backup output; verification and recovery need temporary space for plaintext archived data there.

Stop all Node processes and other database/audio writers **before** creation. `--offline` is an explicit operator acknowledgement, not automatic proof that all writers are stopped. From the repository root, on an operator-controlled host:

```bash
node --env-file=.env scripts/backup.js create --offline /protected-backups/aman-2026-11-20.snapshot
node --env-file=.env scripts/backup.js restore /protected-backups/aman-2026-11-20.snapshot /protected-restore/staging-copy
```

The output file must not exist. Restore requires a nonexistent directory, checks authentication and SQLite/audio consistency, and revokes all restored staff sessions. It never overwrites your live DB. After restoring, verify against an isolated staging server by pointing `AMAN_DB_PATH` at `staging-copy/aman.db` and `AMAN_AUDIO_DIR` at `staging-copy/audio`, using the **unchanged original application encryption key**. Keep real restore sets off public infrastructure. After a rehearsal, coordinate any live cutover or schema rollback and reconcile post-snapshot submissions using an approved procedure. Restore older pre-migration database/audio sets separately using the original recovery plan.

The admin dashboard shows the last verified **local** backup or restore for permitted roles, or that no verification is recorded. It does not verify off-site replication, retention schedules, or your recovery time objective. Operators are responsible for scheduling, transporting, expiring, and regularly rehearsing recovery. The service need not receive `AMAN_BACKUP_KEY`; use it in the trusted offline operator environment only.

## Verification commands

```bash
npm test
node scripts/build-pages.js
# Optional Chromium smoke test:
npm install --no-save playwright
npx playwright install chromium
node --test tests/browser-smoke.js
```

Tests use temporary SQLite databases, generated credentials and synthetic records only. See [ADMIN.md](ADMIN.md) for feature coverage and [ADMIN-API.md](ADMIN-API.md) for API contracts.

### Local Windows edition (single operator)

The separate Windows x64 package uses the launchers in `deploy/windows/` and bundles a Node.js runtime. It is not the Arena demo and does not seed any data. The first run creates your private Super Admin with TOTP and stores the durable database, audio directory and application encryption key under `%LOCALAPPDATA%\AMAN-Admin`. The service is only reachable via `http://127.0.0.1:3030/admin/` on that computer. Windows file protections and disk encryption are the operator’s responsibility. Close the running instance before using the account recovery launcher. Live safeguarding intake is forced off in this edition; do not use it as a shared or Internet-facing deployment.

For offline operation from that package, use `NOUVELLE-CLE-SAUVEGARDE.cmd` to generate the independent backup key, `SAUVEGARDER-AMAN.cmd` to create a verified archive and `RESTAURER-COPIE-AMAN.cmd` to extract a verified copy into a new directory. The launchers refuse to run while the local service is using port 3030. Close other writers separately. Use an existing folder on an NTFS volume for the archive, and keep Windows profile/restore locations on protected encrypted storage. Preserve the original `application.key` separately. These launchers do not switch the live database or schedule backups.
