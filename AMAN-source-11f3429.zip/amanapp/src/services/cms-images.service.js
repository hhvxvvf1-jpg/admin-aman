const {randomUUID}=require('node:crypto');
const {crc32,inflateSync,deflateSync}=require('node:zlib');
const {db}=require('../db/database');
const {fail,text,existing}=require('../admin/shared');
const maxBytes=1024*1024;
const signature=Buffer.from([137,80,78,71,13,10,26,10]);
const meta='id,width,height,alt_ar,alt_fr,alt_en';
const failImage=()=>fail(400,'unsupported_cms_image');
function chunk(type,data){
  const prefix=Buffer.alloc(8),tail=Buffer.alloc(4);prefix.writeUInt32BE(data.length);prefix.write(type,4,'ascii');
  tail.writeUInt32BE(crc32(data,crc32(prefix.subarray(4))));return Buffer.concat([prefix,data,tail]);
}
// Read an intentionally narrow PNG subset and regenerate the PNG with no optional chunks.
function sanitizePng(encoded){
  if(typeof encoded!=='string'||encoded.length>Math.ceil(maxBytes/3)*4||!encoded.length||!(/^[A-Za-z0-9+/]+={0,2}$/.test(encoded))||encoded.length%4)failImage();
  const input=Buffer.from(encoded,'base64');
  if(input.length>maxBytes||!input.subarray(0,8).equals(signature))failImage();
  let offset=8,header=null,width=0,height=0,channels=0,closed=false,endedData=false,count=0;
  const data=[];
  while(offset<input.length){
    if(input.length-offset<12||++count>256)failImage();
    const size=input.readUInt32BE(offset),end=offset+8+size;
    if(end+4>input.length)failImage();
    const type=input.toString('latin1',offset+4,offset+8),body=input.subarray(offset+8,end);
    if(!/^[A-Za-z]{2}[A-Z][A-Za-z]$/.test(type)||crc32(input.subarray(offset+4,end))!==input.readUInt32BE(end))failImage();
    if(!header&&type!=='IHDR')failImage();
    if(data.length>0&&type!=='IDAT')endedData=true;
    if(type==='IHDR'){
      if(header||size!==13)failImage();
      width=body.readUInt32BE();height=body.readUInt32BE(4);
      channels=body[9]===2?3:body[9]===6?4:0;
      if(!width||!height||width>1200||height>1200||body[8]!==8||!channels||body[10]||body[11]||body[12])failImage();
      header=body;
    }else if(type==='IDAT'){
      if(endedData)failImage();data.push(body);
    }else if(type==='IEND'){
      if(size||!data.length||end+4!==input.length)failImage();closed=true;break;
    }else if(/^[A-Z]/.test(type)||['acTL','fcTL','fdAT','tRNS'].includes(type))failImage();
    offset=end+4;
  }
  if(!closed)failImage();
  const stride=1+width*channels,expected=stride*height,compressed=Buffer.concat(data);
  let decoded;
  try{
    const result=inflateSync(compressed,{maxOutputLength:expected,info:true});
    if(result.engine.bytesWritten!==compressed.length)failImage();
    decoded=result.buffer;
  }catch{failImage();}
  if(decoded.length!==expected)failImage();
  for(let i=0;i<expected;i+=stride)if(decoded[i]>4)failImage();
  const png=Buffer.concat([signature,chunk('IHDR',header),chunk('IDAT',deflateSync(decoded,{level:3})),chunk('IEND',Buffer.alloc(0))]);
  if(png.length>maxBytes)failImage();
  return {png,width,height};
}
function metadata(contentId){return db.prepare(`SELECT ${meta} FROM cms_images WHERE content_id=?`).get(contentId)||null;}
function write(contentId,input){
  if(input.remove===true){db.prepare('DELETE FROM cms_images WHERE content_id=?').run(contentId);return;}
  const [ar,fr,en]=['altAr','altFr','altEn'].map(key=>text(input[key],180,1));
  const {png,width,height}=sanitizePng(input.png);
  db.prepare(`INSERT INTO cms_images(id,content_id,png,width,height,alt_ar,alt_fr,alt_en) VALUES(?,?,?,?,?,?,?,?)
    ON CONFLICT(content_id) DO UPDATE SET id=excluded.id,png=excluded.png,width=excluded.width,height=excluded.height,alt_ar=excluded.alt_ar,alt_fr=excluded.alt_fr,alt_en=excluded.alt_en`)
    .run('image_'+randomUUID(),contentId,png,width,height,ar,fr,en);
}
function sendImage(res,png){
  res.writeHead(200,{'Content-Type':'image/png','Content-Length':png.length,'Content-Disposition':'inline','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Cross-Origin-Resource-Policy':'same-origin'});
  res.end(png);
}
function privateImage(res,contentId){sendImage(res,existing(db.prepare('SELECT png FROM cms_images WHERE content_id=?').get(contentId)).png);}
function publicImage(res,id){
  const row=existing(db.prepare(`SELECT i.png FROM cms_images i JOIN cms_content c ON c.id=i.content_id
    WHERE i.id=? AND c.audience='general' AND c.review_status='published' AND (c.publish_at IS NULL OR c.publish_at<=?)`).get(id,new Date().toISOString()));
  sendImage(res,row.png);
}
function remember(contentId){
  db.prepare(`INSERT OR IGNORE INTO cms_snapshot_images(id,png,width,height,alt_ar,alt_fr,alt_en)
    SELECT id,png,width,height,alt_ar,alt_fr,alt_en FROM cms_images WHERE content_id=?`).run(contentId);
  return metadata(contentId)?.id||null;
}
function restore(contentId,imageId){
  db.prepare('DELETE FROM cms_images WHERE content_id=?').run(contentId);
  if(imageId)db.prepare(`INSERT INTO cms_images(id,content_id,png,width,height,alt_ar,alt_fr,alt_en)
    SELECT ?,?,png,width,height,alt_ar,alt_fr,alt_en FROM cms_snapshot_images WHERE id=?`).run('image_'+randomUUID(),contentId,imageId);
}
function snapshotMetadata(imageId){
  return imageId?existing(db.prepare(`SELECT ${meta} FROM cms_snapshot_images WHERE id=?`).get(imageId)):null;
}
function snapshotImage(res,imageId){sendImage(res,existing(imageId&&db.prepare('SELECT png FROM cms_snapshot_images WHERE id=?').get(imageId)).png);}
module.exports={metadata,write,privateImage,publicImage,remember,restore,snapshotMetadata,snapshotImage};
