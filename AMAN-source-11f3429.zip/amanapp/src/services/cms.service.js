const crypto = require('node:crypto');
const { db } = require('../db/database');
const images=require('./cms-images.service');
const { has } = require('../admin/permissions');
const { text, one, existing, atomic, audit, fail, page } = require('../admin/shared');
const TYPES=['article','education','awareness','faq','legal','emergency','announcement','video','safety_guide'];
const STATES=['draft','review','published','archived'];
const AUDIENCES=['general','women','girls','child'];
const publicColumns='id,slug,content_type,title_ar,title_fr,title_en,body_ar,body_fr,body_en,source_ref,seo_description,publish_at';
const snapshotKeys=['slug','content_type','audience','min_age','max_age','title_ar','title_fr','title_en','body_ar','body_fr','body_en','source_ref','seo_description'];
const publicCondition="review_status='published' AND (publish_at IS NULL OR publish_at<=?)";
function listContent({type='',offset=0,audience='general'}={}) {
  one(audience,['general','women','child']);
  const result=page({offset},`SELECT ${publicColumns} FROM cms_content WHERE ${publicCondition} AND audience=? AND (?='' OR content_type=?) ORDER BY publish_at DESC,id`,[new Date().toISOString(),audience,text(type,80),type]);
  if(audience==='general')result.items=result.items.map(item=>({...item,image:images.metadata(item.id)}));
  return result;
}
function listAdmin(query) {
  const q=text(query.q || '',120);
  const state=query.state ? one(query.state,STATES) : '';
  const audience=query.audience ? one(query.audience,AUDIENCES) : '';
  return page(query,`SELECT id,slug,content_type,title_en,review_status,publish_at,updated_at,audience FROM cms_content WHERE (?='' OR audience=?) AND (?='' OR review_status=?) AND (?='' OR instr(lower(slug||' '||title_en||' '||title_fr||' '||title_ar),lower(?))>0) ORDER BY updated_at DESC,id`,[audience,audience,state,state,q,q]);
}
function row(id) { return existing(db.prepare('SELECT * FROM cms_content WHERE id=?').get(id)); }
function detail(id) {
  const item=row(id);
  return { ...item, image:images.metadata(id), history:db.prepare('SELECT event,actor_id,revision,created_at FROM cms_history WHERE content_id=? ORDER BY id DESC LIMIT 100').all(id) };
}
function history(user,id,event,revision,extra={}) {
  const current=row(id);
  const payload=JSON.stringify(Object.fromEntries(snapshotKeys.map(key=>[key,current[key]])));
  db.prepare('INSERT INTO cms_snapshots(content_id,revision,state,event,payload,image_id) VALUES(?,?,?,?,?,?)').run(id,revision,current.review_status,event,payload,images.remember(id));
  db.prepare('INSERT INTO cms_history(content_id,event,actor_id,revision) VALUES (?,?,?,?)').run(id,event,user.id,revision);
  audit(user,'cms_'+event,{contentId:id,revision,...extra});
}
function save(user,id,input) {
  return atomic(() => {
    const old=id ? row(id) : null;
    if (!has(user,old?'cms.edit':'cms.create')) fail(403,'forbidden');
    if (old && (old.revision !== input.revision || old.review_status !== 'draft')) fail(409,'invalid_revision_or_state');
    const slug=text(input.slug,100,1);
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) fail(400,'invalid_slug');
    const conflict=db.prepare('SELECT id FROM cms_content WHERE slug=?').get(slug);
    if (conflict && conflict.id!==id) fail(409,'slug_in_use');
    const type=one(input.contentType,TYPES);
    const audience=one(input.audience||'general',AUDIENCES);
    if(old&&audience!=='general'&&images.metadata(id))fail(409,'remove_image_before_restricting_audience');
    const minAge=audience==='girls'?input.minAge:null, maxAge=audience==='girls'?input.maxAge:null;
    if (audience==='girls' && (!Number.isInteger(minAge) || !Number.isInteger(maxAge) || minAge<10 || maxAge>17 || maxAge<minAge)) fail(400,'invalid_age_range');
    const vals=[slug,type,audience,minAge,maxAge,...['titleAr','titleFr','titleEn','bodyAr','bodyFr','bodyEn'].map((k,i)=>text(input[k],i<3?200:20000,1)),text(input.sourceRef||'',500),text(input.seoDescription||'',320),user.id];
    const newId=id || 'cms_'+crypto.randomUUID();
    const revision=old ? old.revision+1 : 1;
    if (old) db.prepare(`UPDATE cms_content SET slug=?,content_type=?,audience=?,min_age=?,max_age=?,title_ar=?,title_fr=?,title_en=?,body_ar=?,body_fr=?,body_en=?,source_ref=?,seo_description=?,author_id=?,revision=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(...vals,revision,newId);
    else db.prepare(`INSERT INTO cms_content (id,slug,content_type,audience,min_age,max_age,title_ar,title_fr,title_en,body_ar,body_fr,body_en,source_ref,seo_description,author_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(newId,...vals);
    history(user,newId,old?'edited':'created',revision);
    return detail(newId);
  });
}
function transition(user,id,{action,revision,publishAt=''}) {
  return atomic(() => {
    const old=row(id);
    if (revision!==old.revision) fail(409,'invalid_revision_or_state');
    const policy={submit:['cms.edit','draft','review'],return:['cms.approve','review','draft'],publish:['cms.approve','review','published'],unpublish:['cms.approve','published','draft'],archive:['cms.delete','draft','archived'],restore:['cms.delete','archived','draft']};
    if (!Object.hasOwn(policy,action)) fail(400,'invalid_input');
    const [perm,from,to]=policy[action];
    if (!has(user,perm)) fail(403,'forbidden');
    if (old.review_status!==from) fail(409,'invalid_transition');
    let when=null;
    if (action==='publish') {
      if (old.author_id===user.id) fail(403,'independent_reviewer_required');
      if (['legal','emergency','safety_guide'].includes(old.content_type) && !/^https:\/\/[^\s]+$/i.test(old.source_ref || '')) fail(400,'official_source_required');
      if (publishAt && (typeof publishAt!=='string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(publishAt) || !Number.isFinite(Date.parse(publishAt)))) fail(400,'invalid_schedule');
      when=publishAt || new Date().toISOString();
    }
    db.prepare('UPDATE cms_content SET review_status=?,reviewed_by=?,publish_at=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(to,action==='publish'?user.id:null,when,id);
    history(user,id,action,old.revision+1);
    return detail(id);
  });
}
function eligibleGirls(ageGroup,{id='',category='',q=''}={}) {
  const band=Object.hasOwn({ '10-12':true,'13-15':true,'16-17':true },ageGroup) ? ageGroup.split('-').map(Number) : null;
  if (!band) return [];
  const [min,max]=band;
  return db.prepare(`SELECT ${publicColumns} FROM cms_content WHERE ${publicCondition} AND audience='girls' AND min_age<=? AND max_age>=?
    AND (?='' OR id=?) AND (?='' OR content_type=?) AND (?='' OR instr(lower(title_ar||title_fr||title_en||body_ar||body_fr||body_en),lower(?))>0)
    ORDER BY publish_at DESC,id LIMIT 100`).all(new Date().toISOString(),min,max,text(id,80),id,text(category,80),category,text(q,120),q).map(x=>({id:x.id,category:x.content_type,categoryAr:x.content_type,categoryFr:x.content_type,categoryEn:x.content_type,titleAr:x.title_ar,titleFr:x.title_fr,titleEn:x.title_en,bodyAr:x.body_ar,bodyFr:x.body_fr,bodyEn:x.body_en}));
}
function changeImage(user,id,input){
  return atomic(()=>{
    const old=row(id);
    if(old.revision!==input.revision||old.review_status!=='draft')fail(409,'invalid_revision_or_state');
    if(old.audience!=='general')fail(400,'cms_image_requires_general_audience');
    images.write(id,input);
    db.prepare('UPDATE cms_content SET revision=revision+1,author_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(user.id,id);
    history(user,id,input.remove===true?'image_removed':'image_updated',old.revision+1);
    return detail(id);
  });
}
function revisionNumber(value){
  const n=typeof value==='number'?value:/^[1-9][0-9]{0,14}$/.test(value??'')?Number(value):NaN;
  if(!Number.isSafeInteger(n)||n<1)fail(400,'invalid_input');return n;
}
function listSnapshots(id,query){
  row(id);
  return page(query,`SELECT revision,state,event,created_at,image_id IS NOT NULL AS has_image,
    json_extract(payload,'$.title_en') AS title_en FROM cms_snapshots WHERE content_id=? ORDER BY revision DESC`,[id]);
}
function snapshotRow(id,revision){return existing(db.prepare('SELECT revision,state,event,payload,image_id,created_at FROM cms_snapshots WHERE content_id=? AND revision=?').get(id,revisionNumber(revision)));}
function readSnapshot(id,revision){
  const {payload,image_id,...meta}=snapshotRow(id,revision);
  return {...meta,...JSON.parse(payload),image:images.snapshotMetadata(image_id)};
}
function readSnapshotImage(res,id,revision){images.snapshotImage(res,snapshotRow(id,revision).image_id);}
function restoreSnapshot(user,id,{revision,targetRevision}){
  return atomic(()=>{
    const current=row(id);
    if(current.review_status!=='draft'||current.revision!==revision)fail(409,'invalid_revision_or_state');
    const saved=snapshotRow(id,targetRevision),target=JSON.parse(saved.payload);
    if(saved.revision===current.revision)fail(409,'invalid_revision_or_state');
    // Rollback must not widen or change audience and age targeting.
    if(target.audience!==current.audience||target.min_age!==current.min_age||target.max_age!==current.max_age)fail(409,'cms_snapshot_scope_mismatch');
    if(saved.image_id&&target.audience!=='general')fail(409,'cms_snapshot_scope_mismatch');
    if(db.prepare('SELECT 1 FROM cms_content WHERE slug=? AND id!=?').get(target.slug,id))fail(409,'slug_in_use');
    db.prepare(`UPDATE cms_content SET ${snapshotKeys.map(k=>`${k}=?`).join(',')},author_id=?,reviewed_by=NULL,publish_at=NULL,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(...snapshotKeys.map(k=>target[k]),user.id,id);
    images.restore(id,saved.image_id);
    history(user,id,'snapshot_restored',current.revision+1,{restoredRevision:saved.revision});
    return detail(id);
  });
}
module.exports={ listSnapshots,readSnapshot,readSnapshotImage,restoreSnapshot,changeImage, eligibleGirls, TYPES, STATES, listContent, listAdmin, detail, save, transition };
