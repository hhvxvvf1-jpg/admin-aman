// Additive migration for the administration layer. Applied once, including on existing databases.
module.exports = function migrateAdmin(db) {
  db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)');
  db.exec('BEGIN IMMEDIATE');
  try {
    if (!db.prepare("SELECT 1 FROM schema_migrations WHERE version = 'admin-001'").get()) {
      db.exec(`
        ALTER TABLE users ADD COLUMN mfa_secret TEXT;
        ALTER TABLE users ADD COLUMN mfa_last_step INTEGER NOT NULL DEFAULT -1;
        ALTER TABLE sessions ADD COLUMN mfa_verified INTEGER NOT NULL DEFAULT 0;
        DELETE FROM sessions;
        ALTER TABLE organizations ADD COLUMN review_state TEXT NOT NULL DEFAULT 'pending';
        ALTER TABLE organizations ADD COLUMN verification_ref TEXT;
        ALTER TABLE organizations ADD COLUMN verified_by TEXT;
        ALTER TABLE organizations ADD COLUMN public_listing INTEGER NOT NULL DEFAULT 0;
        UPDATE organizations SET is_verified = 0, verified_at = NULL;
        ALTER TABLE cms_content ADD COLUMN publish_at TEXT;
        ALTER TABLE cms_content ADD COLUMN seo_description TEXT NOT NULL DEFAULT '';
        ALTER TABLE cms_content ADD COLUMN author_id TEXT;
        ALTER TABLE cms_content ADD COLUMN revision INTEGER NOT NULL DEFAULT 1;
        UPDATE cms_content SET review_status='draft', reviewed_by=NULL;
        CREATE TABLE cms_history (
          id INTEGER PRIMARY KEY, content_id TEXT NOT NULL REFERENCES cms_content(id),
          event TEXT NOT NULL, actor_id TEXT NOT NULL REFERENCES users(id),
          revision INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE role_permissions (
          role TEXT NOT NULL, permission TEXT NOT NULL, enabled INTEGER NOT NULL CHECK(enabled IN (0,1)),
          PRIMARY KEY(role, permission)
        );
        ALTER TABLE help_requests ADD COLUMN audio_upload_digest TEXT;
        ALTER TABLE help_requests ADD COLUMN audio_upload_expires TEXT;
        CREATE INDEX help_requests_created ON help_requests(created_at);
        CREATE INDEX cases_scope ON help_requests(beneficiary_group, assigned_to, status);
        CREATE INDEX audit_events_created ON audit_logs(created_at);
        ALTER TABLE posts ADD COLUMN hidden INTEGER NOT NULL DEFAULT 0;
        ALTER TABLE comments ADD COLUMN hidden INTEGER NOT NULL DEFAULT 0;
        CREATE TABLE community_flags (
          id TEXT PRIMARY KEY, target_type TEXT NOT NULL CHECK(target_type IN ('post','comment')),
          target_id TEXT NOT NULL, reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE UNIQUE INDEX community_open_flag ON community_flags(target_type, target_id) WHERE status='open';
        INSERT INTO schema_migrations(version) VALUES ('admin-001');
      `);
    }
    if (!db.prepare("SELECT 1 FROM schema_migrations WHERE version = 'admin-002'").get()) {
      db.exec(`
        ALTER TABLE cms_content ADD COLUMN audience TEXT NOT NULL DEFAULT 'general' CHECK(audience IN ('general','women','girls','child'));
        ALTER TABLE cms_content ADD COLUMN min_age INTEGER CHECK(min_age BETWEEN 10 AND 17);
        ALTER TABLE cms_content ADD COLUMN max_age INTEGER CHECK(max_age BETWEEN 10 AND 17 AND max_age>=min_age);
        CREATE INDEX cms_audience_idx ON cms_content(audience,review_status,publish_at);
        INSERT INTO schema_migrations(version) VALUES ('admin-002');
      `);
    }
    if (!db.prepare("SELECT 1 FROM schema_migrations WHERE version='admin-003'").get()) {
      db.exec(`
        CREATE TABLE operational_config (
          key TEXT PRIMARY KEY, value TEXT NOT NULL CHECK(json_valid(value)), revision INTEGER NOT NULL DEFAULT 1,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        INSERT INTO operational_config (key,value) VALUES
          ('platform','{"nameAr":"أمان","nameFr":"AMAN","nameEn":"AMAN","palette":"purple","logo":"mark.png","maintenance":false}'),
          ('ai','{"enabled":true,"languages":["ar","fr","en"],"defaultLanguage":"ar","includeSources":false}');
        CREATE TABLE finance_records (
          id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('budget','grant','contribution','expense','maintenance','allocation')),
          label TEXT NOT NULL, project TEXT NOT NULL, amount_minor INTEGER NOT NULL CHECK(amount_minor BETWEEN 1 AND 100000000000),
          entry_date TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'draft' CHECK(state IN ('draft','posted','void')),
          revision INTEGER NOT NULL DEFAULT 1, reason TEXT, created_by TEXT NOT NULL REFERENCES users(id),
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX finance_period ON finance_records(entry_date,state,kind);
        CREATE TABLE ai_sources (
          content_id TEXT PRIMARY KEY REFERENCES cms_content(id), approved_by TEXT NOT NULL REFERENCES users(id), approved_revision INTEGER NOT NULL,
          approved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE ai_run_daily (
          day TEXT NOT NULL, outcome TEXT NOT NULL CHECK(outcome IN ('answered','emergency','unavailable','error')),
          count INTEGER NOT NULL CHECK(count>=0), PRIMARY KEY(day,outcome)
        );
        CREATE TABLE staff_announcements (
          id TEXT PRIMARY KEY, template TEXT NOT NULL CHECK(template IN ('maintenance','training','policy_review')),
          audience TEXT NOT NULL CHECK(audience IN ('staff','safeguarding','partners')),
          status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','withdrawn')),
          published_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE staff_acknowledgements (
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          announcement_id TEXT NOT NULL REFERENCES staff_announcements(id),
          read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,announcement_id)
        );
        CREATE INDEX announcement_audience ON staff_announcements(audience,status,created_at);
        INSERT INTO schema_migrations(version) VALUES ('admin-003');
      `);
    }
    if (!db.prepare("SELECT 1 FROM schema_migrations WHERE version='admin-004'").get()) {
      db.exec(`
        CREATE TABLE backup_history (
          id INTEGER PRIMARY KEY, action TEXT NOT NULL CHECK(action IN ('created','restored')),
          bytes INTEGER NOT NULL CHECK(bytes>0), verified_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        INSERT INTO schema_migrations(version) VALUES ('admin-004');
      `);
    }
    if (!db.prepare("SELECT 1 FROM schema_migrations WHERE version='admin-005'").get()) {
      db.exec(`
        CREATE TABLE girls_quizzes (
          id TEXT PRIMARY KEY, title_en TEXT NOT NULL, min_age INTEGER NOT NULL CHECK(min_age BETWEEN 10 AND 17),
          max_age INTEGER NOT NULL CHECK(max_age BETWEEN min_age AND 17), payload TEXT NOT NULL CHECK(json_valid(payload)),
          state TEXT NOT NULL DEFAULT 'draft' CHECK(state IN ('draft','review','published','archived')),
          author_id TEXT REFERENCES users(id), revision INTEGER NOT NULL DEFAULT 1,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX girls_quiz_visibility ON girls_quizzes(state,min_age,max_age);
      `);
      const write=db.prepare("INSERT INTO girls_quizzes(id,title_en,min_age,max_age,payload,state) VALUES(?,?,?,?,?,'published')");
      for(const {id,ageGroups,...content} of require('./quiz-seeds')) {
        const min=Number(ageGroups[0].split('-')[0]),max=Number(ageGroups.at(-1).split('-')[1]);
        write.run(id,content.questionEn,min,max,JSON.stringify(content));
      }
      db.prepare("INSERT INTO schema_migrations(version) VALUES('admin-005')").run();
    }
    if (!db.prepare("SELECT 1 FROM schema_migrations WHERE version='admin-006'").get()) {
      db.exec(`
        CREATE TABLE security_incidents (
          id TEXT PRIMARY KEY,
          category TEXT NOT NULL CHECK(category IN ('account_security','service_availability','data_protection','backup_recovery')),
          severity TEXT NOT NULL CHECK(severity IN ('low','medium','high','critical')),
          component TEXT NOT NULL CHECK(component IN ('admin_portal','public_portal','data_store','operations')),
          state TEXT NOT NULL DEFAULT 'open' CHECK(state IN ('open','triage','contained','resolved','closed')),
          resolved_by TEXT REFERENCES users(id),
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          revision INTEGER NOT NULL DEFAULT 1
        );
        CREATE INDEX security_incident_queue ON security_incidents(state,severity,updated_at);
        CREATE TABLE security_incident_events (
          id INTEGER PRIMARY KEY,
          incident_id TEXT NOT NULL REFERENCES security_incidents(id),
          actor_id TEXT NOT NULL REFERENCES users(id),
          actor_role TEXT NOT NULL,
          action TEXT NOT NULL CHECK(action IN ('record','triage','contain','resolve','close','reopen')),
          reason TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX security_incident_timeline ON security_incident_events(incident_id,id DESC);
        INSERT INTO schema_migrations(version) VALUES ('admin-006');
      `);
    }
    if (!db.prepare("SELECT 1 FROM schema_migrations WHERE version='admin-007'").get()) {
      db.exec(`
        CREATE TABLE staff_invitations (
          id TEXT PRIMARY KEY, token_hash TEXT UNIQUE NOT NULL,
          email TEXT NOT NULL, full_name TEXT NOT NULL,
          role TEXT NOT NULL CHECK(role IN ('platform_admin','content_manager','moderator','auditor','tech_support')),
          issued_by TEXT NOT NULL REFERENCES users(id),
          created_at TEXT NOT NULL, expires_at TEXT NOT NULL,
          state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','redeemed','revoked')),
          enrollment_nonce TEXT, enrollment_secret TEXT, enrollment_expires_at TEXT
        );
        CREATE INDEX staff_invite_email_state ON staff_invitations(email,state);
        CREATE INDEX staff_invite_order ON staff_invitations(created_at DESC);
        INSERT INTO schema_migrations(version) VALUES ('admin-007');
      `);
    }
    if (!db.prepare("SELECT 1 FROM schema_migrations WHERE version='admin-008'").get()) {
      db.exec(`
        CREATE TABLE cms_images (
          id TEXT PRIMARY KEY,
          content_id TEXT NOT NULL UNIQUE REFERENCES cms_content(id) ON DELETE CASCADE,
          png BLOB NOT NULL CHECK(length(png) BETWEEN 1 AND 1048576),
          width INTEGER NOT NULL CHECK(width BETWEEN 1 AND 1200),
          height INTEGER NOT NULL CHECK(height BETWEEN 1 AND 1200),
          alt_ar TEXT NOT NULL, alt_fr TEXT NOT NULL, alt_en TEXT NOT NULL
        );
        INSERT INTO schema_migrations(version) VALUES ('admin-008');
      `);
    }
    if (!db.prepare("SELECT 1 FROM schema_migrations WHERE version='admin-009'").get()) {
      db.exec(`
        CREATE TABLE cms_snapshot_images (
          id TEXT PRIMARY KEY, png BLOB NOT NULL CHECK(length(png) BETWEEN 1 AND 1048576),
          width INTEGER NOT NULL, height INTEGER NOT NULL, alt_ar TEXT NOT NULL, alt_fr TEXT NOT NULL, alt_en TEXT NOT NULL
        );
        CREATE TABLE cms_snapshots (
          content_id TEXT NOT NULL REFERENCES cms_content(id) ON DELETE CASCADE,
          revision INTEGER NOT NULL, state TEXT NOT NULL, event TEXT NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)),
          image_id TEXT REFERENCES cms_snapshot_images(id), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY(content_id,revision)
        );
        INSERT INTO cms_snapshot_images(id,png,width,height,alt_ar,alt_fr,alt_en)
          SELECT id,png,width,height,alt_ar,alt_fr,alt_en FROM cms_images;
        INSERT INTO cms_snapshots(content_id,revision,state,event,payload,image_id)
          SELECT c.id,c.revision,c.review_status,'snapshot_baseline',
            json_object('slug',c.slug,'content_type',c.content_type,'audience',c.audience,'min_age',c.min_age,'max_age',c.max_age,
            'title_ar',c.title_ar,'title_fr',c.title_fr,'title_en',c.title_en,'body_ar',c.body_ar,'body_fr',c.body_fr,'body_en',c.body_en,
            'source_ref',c.source_ref,'seo_description',c.seo_description),i.id
          FROM cms_content c LEFT JOIN cms_images i ON i.content_id=c.id;
        INSERT INTO schema_migrations(version) VALUES ('admin-009');
      `);
    }
    db.exec('COMMIT');
  } catch (error) { db.exec('ROLLBACK'); throw error; }
};
