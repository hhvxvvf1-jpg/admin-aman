const crypto = require('node:crypto');
const { db } = require('../db/database');
const auth = require('../services/auth.service');
const cases = require('../services/cases.service');
const cms = require('../services/cms.service');
const quizzes=require('../services/quizzes.service');
const incidents=require('../services/incidents.service');
const cmsImages=require('../services/cms-images.service');
const staffInvitations=require('../services/staff-invitations.service');
const partners = require('../services/partners.service');
const analytics = require('../services/analytics.service');
const ops = require('../services/operations.service');
const ai = require('../services/ai.service');
const reportFiles = require('./report-files');
const { has, permissions, ceiling, roles } = require('./permissions');
const { AdminError, fail, text, one, existing, page, atomic, audit } = require('./shared');
const security = require('../middleware/security');
const accountCols='id,role,is_active,mfa_enabled,organization_id,last_login_at,created_at';
const events = "action IN ('login_success','login_failed','logout','user_registered','staff_mfa_enrolled','staff_access_recovered','account_updated','sessions_revoked','role_permission_changed','cms_created','cms_edited','cms_image_updated','cms_image_removed','cms_snapshot_restored','cms_submit','cms_return','cms_publish','cms_unpublish','cms_archive','cms_restore','partner_registered','partner_profile_updated','partner_reviewed','community_moderated','community_flag_reviewed','analytics_exported','case_queue_viewed','case_accessed','case_status_updated','case_note_added','referral_created','referral_responded','audio_accessed','case_redacted','finance_created','finance_edited','finance_posted','finance_voided','finance_exported','platform_settings_updated','ai_settings_updated','ai_source_approved','ai_source_removed','notice_published','notice_withdrawn','backup_snapshot_verified','backup_restore_verified','quiz_created','quiz_edited','quiz_submit','quiz_return','quiz_publish','quiz_unpublish','quiz_archive','quiz_restore','staff_invitation_issued','staff_invitation_revoked','staff_invitation_redeemed')";
const incidentEvents="action IN ('incident_record','incident_accessed','incident_triage','incident_contain','incident_resolve','incident_close','incident_reopen')";
const authEvents="action IN ('login_success','login_failed','logout','sessions_revoked','staff_access_recovered')";
function eventProjection(row) { return {id:row.id, action:row.action, created_at:row.created_at}; }
const targetTables={post:'posts',comment:'comments'};
function flagPublic({type,id,reason}) {
  one(type,Object.keys(targetTables));
  one(reason,['privacy','harassment','spam','other']);
  const targetId=text(id,80,1);
  const table=targetTables[type];
  if (!db.prepare(`SELECT 1 FROM ${table} WHERE id=? AND hidden=0`).get(targetId)) fail(404,'not_found');
  db.prepare(`INSERT OR IGNORE INTO community_flags (id,target_type,target_id,reason) VALUES (?,?,?,?)`).run(crypto.randomUUID(),type,targetId,reason);
}
function lookupCaseOptions(user,caseId) {
  const row=cases.authorizedCase(user,caseId);
  const role={women:'women_caseworker',girls:'girls_caseworker',child:'child_caseworker'}[row.beneficiary_group];
  return {
    assignees:has(user,'cases.assign') ? db.prepare("SELECT id,full_name FROM users WHERE is_active=1 AND mfa_enabled=1 AND role IN (?,'authorized_professional') ORDER BY full_name LIMIT 200").all(role) : [],
    organizations:has(user,'cases.refer') ? db.prepare("SELECT id,name_en FROM organizations WHERE review_state='verified' AND is_verified=1 ORDER BY name_en LIMIT 200").all() : [],
    timeline:db.prepare("SELECT action,created_at FROM audit_logs WHERE action IN ('case_status_updated','case_note_added','referral_created','referral_responded','case_redacted') AND json_valid(details) AND json_extract(details,'$.caseId')=? ORDER BY id DESC LIMIT 100").all(caseId)
  };
}
async function routeAdmin(ctx) {
  const { req,res,pathname,method,query,read,send,clientIp }=ctx;
  res.setHeader('Cache-Control','no-store');
  if (!security.checkRateLimit(`admin:${clientIp}`,240,60_000)) return send(429,{error:'rate_limited'});
  const user=auth.getSessionUser(req);
  if (!user) return send(401,{error:'unauthorized'});
  const permitted=p=>{if(!has(user,p)) fail(403,'forbidden');};
  const body=async(limit=256*1024)=>{
    if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type']||'')) fail(415,'json_required');
    let result;
    try { result=await read(req,limit); } catch(e) { fail(e.status || 400,e.status===413?'payload_too_large':'invalid_json'); }
    if (!result || typeof result!=='object' || Array.isArray(result)) fail(400,'invalid_input');
    return result;
  };
  const parts=pathname.slice('/api/admin'.length).split('/').slice(1);
  const [section,id,action]=parts;
  if (parts.length>3 || parts.some(x=>!x || !/^[a-zA-Z0-9_-]+$/.test(x))) return send(404,{error:'not_found'});
  try {
    if (section==='me' && !id && method==='GET') {
      const caps=permissions(user.role);
      if (!caps.length) fail(403,'forbidden');
      return send(200,{user,permissions:caps});
    }
    if (section==='staff-invitations') {
      permitted('staff.invite');
      if (!id && method==='GET') return send(200,staffInvitations.list(query));
      if (!id && method==='POST') return send(201,staffInvitations.issue(user,await body()));
      if (id && action==='revoke' && method==='POST') return send(200,staffInvitations.revoke(user,id));
    }
    if (section==='incidents') {
      permitted('incidents.view');
      if (!action && method==='GET') return send(200,id?incidents.read(user,id):incidents.list(query));
      if (!id && method==='POST') { permitted('incidents.manage'); return send(201,incidents.create(user,await body())); }
      if (id && action==='workflow' && method==='POST') return send(200,incidents.transition(user,id,await body()));
    }
    if (section==='finance') {
      if (!id && method==='GET') { permitted('finance.view'); return send(200,ops.finance(user,query)); }
      if (['csv','xlsx','pdf'].includes(id) && !action && method==='GET') {
        permitted('finance.view'); permitted('finance.export');
        return reportFiles.attachment(res,`aman-finance.${id}`,ops.financeExport(user,query,id));
      }
      if (id && !action && method==='GET') { permitted('finance.view'); return send(200,ops.financeDetail(id)); }
      if (!id && method==='POST') { permitted('finance.edit'); return send(201,ops.financeSave(user,null,await body())); }
      if (id && !action && method==='PATCH') { permitted('finance.edit'); return send(200,ops.financeSave(user,id,await body())); }
      if (id && action==='workflow' && method==='POST') { permitted('finance.approve'); return send(200,ops.financeTransition(user,id,await body())); }
    }
    if (section==='settings' && !id) {
      if (method==='GET') { permitted('settings.view'); return send(200,ops.getConfig('platform')); }
      if (method==='PATCH') { permitted('settings.edit'); return send(200,ops.changeConfig(user,'platform',await body())); }
    }
    if (section==='ai') {
      if (!id && method==='GET') { permitted('ai.view'); return send(200,{settings:ops.getConfig('ai'),metrics:ops.aiMetrics(),sources:ops.aiSources(query)}); }
      if (!id && method==='PATCH') { permitted('ai.edit'); return send(200,ops.changeConfig(user,'ai',await body())); }
      if (id==='sources' && action && method==='PATCH') { permitted('ai.approve'); return send(200,ops.changeSource(user,action,await body())); }
      if (id==='test' && !action && method==='POST') {
        permitted('ai.view');
        const input=await body();
        const result=ai.configuredReply({message:text(input.message,1000,1),uiLang:one(input.language,['ar','fr','en'])});
        return send(200,result);
      }
    }
    if (section==='notices') {
      if (!id && method==='GET') { permitted('notices.manage'); return send(200,ops.notices(query)); }
      if (!id && method==='POST') { permitted('notices.manage'); return send(201,ops.publishNotice(user,await body())); }
      if (id==='inbox' && !action && method==='GET') { permitted('notices.view'); return send(200,ops.inbox(user,query)); }
      if (id && action==='read' && method==='POST') { permitted('notices.view'); return send(200,ops.acknowledge(user,id)); }
      if (id && action==='withdraw' && method==='POST') { permitted('notices.manage'); return send(200,ops.withdrawNotice(user,id)); }
    }
    if (section==='dashboard' && !id && method==='GET') {
      permitted('dashboard.view');
      const stats=has(user,'analytics.view')?analytics.getAggregatedStats(user,query.range || 'month'):null;
      const activity=has(user,'audit.view')?db.prepare(`SELECT id,action,created_at FROM audit_logs WHERE ${events} AND action NOT LIKE 'case_%' AND action NOT LIKE 'referral_%' AND action!='audio_accessed' ORDER BY id DESC LIMIT 8`).all().map(eventProjection):[];
      const pending={};
      if (has(user,'cms.approve')) {
        pending.cms=db.prepare("SELECT count(*) n FROM cms_content WHERE review_status='review'").get().n;
        pending.quizzes=db.prepare("SELECT count(*) n FROM girls_quizzes WHERE state='review'").get().n;
      }
      if (has(user,'incidents.view')) pending.incidents=db.prepare("SELECT count(*) n FROM security_incidents WHERE state!='closed'").get().n;
      if (has(user,'partners.approve')) pending.partners=db.prepare("SELECT count(*) n FROM organizations WHERE review_state='pending'").get().n;
      if (has(user,'community.edit')) pending.community=db.prepare("SELECT count(*) n FROM community_flags WHERE status='open'").get().n;
      return send(200,{stats,activity,pending,health:{api:'ok',database:db.prepare('SELECT 1 AS ok').get().ok===1?'ok':'unavailable',backup:has(user,'backup.view')?db.prepare('SELECT action,verified_at FROM backup_history ORDER BY id DESC LIMIT 1').get()||null:null,backupVisible:has(user,'backup.view')},checkedAt:new Date().toISOString()});
    }
    if (section==='analytics' && !action && method==='GET') {
      permitted('analytics.view');
      const stats=analytics.getAggregatedStats(user,query.range || 'month');
      if (!id) return send(200,stats);
      if (['csv','xlsx','pdf'].includes(id)) {
        permitted('analytics.export'); audit(user,'analytics_exported',{range:stats.range,format:id});
        const data=id==='csv'?['metric,value,from,to',...Object.entries(stats.metrics).map(([key,value])=>[key,value,stats.from,stats.to].join(','))].join('\r\n'):reportFiles.analyticsExport(id,stats);
        return reportFiles.attachment(res,`aman-activity.${id}`,data);
      }
    }
    if (section==='users') {
      if (method==='GET' && !action) {
        permitted('users.view');
        if (id) {
          const account=existing(db.prepare(`SELECT ${accountCols},CASE WHEN role!='member' THEN full_name END AS full_name,CASE WHEN role!='member' THEN email END AS email FROM users WHERE id=?`).get(id));
          return send(200,{...account, canManage:account.role!=='super_admin' && account.id!==user.id, active_sessions:has(user,'sessions.manage')?db.prepare('SELECT count(*) n FROM sessions WHERE user_id=? AND expires_at>?').get(id,new Date().toISOString()).n:null});
        }
        const q=text(query.q || '',160);
        const role=query.role ? one(query.role,roles):'';
        const active=query.state?one(query.state,['active','suspended']):'';
        return send(200,page(query,`SELECT ${accountCols},CASE WHEN role!='member' THEN full_name END AS full_name FROM users WHERE (?='' OR role=?) AND (?='' OR is_active=?) AND (?='' OR id=? OR (role!='member' AND instr(lower(full_name),lower(?))>0)) ORDER BY created_at DESC,id`,[role,role,active,Number(active==='active'),q,q,q]));
      }
      if (id && method==='PATCH' && !action) {
        permitted('users.edit');
        const input=await body();
        const result=atomic(()=>{
          const current=existing(db.prepare('SELECT id,role,is_active,organization_id FROM users WHERE id=?').get(id));
          if (id===user.id || current.role==='super_admin') fail(403,'forbidden');
          const role=input.role===undefined?current.role:one(input.role,roles);
          if (role!==current.role && (!['platform_admin','content_manager','moderator','auditor','tech_support'].includes(role) || !['platform_admin','content_manager','moderator','auditor','tech_support'].includes(current.role))) fail(403,'role_requires_trusted_provisioning');
          if (typeof input.active!=='boolean') fail(400,'invalid_input');
          db.prepare('UPDATE users SET is_active=?,role=? WHERE id=?').run(Number(input.active),role,id);
          db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
          audit(user,'account_updated',{userId:id,active:input.active,role});
          return { id, role, is_active:Number(input.active) };
        });
        return send(200,result);
      }
      if (id && action==='sessions' && method==='DELETE') {
        permitted('sessions.manage');
        return send(200,atomic(()=>{
          const account=existing(db.prepare('SELECT role FROM users WHERE id=?').get(id));
          if (account.role==='super_admin' && id!==user.id) fail(403,'forbidden');
          const removed=db.prepare('DELETE FROM sessions WHERE user_id=?').run(id).changes;
          audit(user,'sessions_revoked',{userId:id}); return { revoked:removed };
        }));
      }
    }
    if (section==='roles' && !action) {
      permitted('roles.manage');
      if (!id && method==='GET') return send(200,{items:roles.map(role=>({role,available:ceiling(role),enabled:permissions(role)}))});
      if (id && method==='PATCH') {
        one(id,roles);
        if (id==='super_admin') fail(403,'forbidden');
        const input=await body();
        if (!Array.isArray(input.enabled) || input.enabled.length>ceiling(id).length || new Set(input.enabled).size!==input.enabled.length || input.enabled.some(p=>!ceiling(id).includes(p))) fail(400,'invalid_permissions');
        return send(200,atomic(()=>{
          db.prepare('DELETE FROM role_permissions WHERE role=?').run(id);
          const disable=db.prepare('INSERT INTO role_permissions (role,permission,enabled) VALUES (?,?,0)');
          for (const permission of ceiling(id)) if (!input.enabled.includes(permission)) disable.run(id,permission);
          db.prepare('DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE role=?)').run(id);
          audit(user,'role_permission_changed',{role:id,enabled:input.enabled}); return {role:id,enabled:permissions(id)};
        }));
      }
    }
    if (section==='cases') {
      if (!id && method==='GET') return send(200,cases.listCasesPage(user,query));
      if (id && !action && method==='GET') return send(200,{...cases.getCase(user,id),...lookupCaseOptions(user,id)});
      if (id && action==='status' && method==='PATCH') return send(200,cases.updateCaseStatus(user,id,await body()));
      if (id && action==='notes' && method==='POST') return send(201,cases.addCaseNote(user,id,await body()));
      if (id && action==='referrals' && method==='POST') return send(201,partners.createReferral(user,{...(await body()),caseId:id}));
    }
    if (section==='referrals' && !action) {
      if (!id && method==='GET') return send(200,partners.referrals(user,query));
      if (id && method==='PATCH') return send(200,partners.respondToReferral(user,id,await body()));
    }
    if (section==='quizzes') {
      if (!action && method==='GET') { permitted('cms.view'); return send(200,id?quizzes.detail(id):quizzes.list(query)); }
      if (!id && method==='POST') { permitted('cms.create'); return send(201,quizzes.save(user,null,await body())); }
      if (id && !action && method==='PATCH') { permitted('cms.edit'); return send(200,quizzes.save(user,id,await body())); }
      if (id && action==='workflow' && method==='POST') return send(200,quizzes.transition(user,id,await body()));
    }
    if (section==='cms') {
      if (id && action==='snapshots' && method==='GET') { permitted('cms.view'); return send(200,query.revision!==undefined?cms.readSnapshot(id,query.revision):cms.listSnapshots(id,query)); }
      if (id && action==='snapshot-image' && method==='GET') { permitted('cms.view'); return cms.readSnapshotImage(res,id,query.revision); }
      if (id && action==='snapshots' && method==='POST') { permitted('cms.edit'); return send(200,cms.restoreSnapshot(user,id,await body())); }
      if (id && action==='image' && method==='GET') { permitted('cms.view'); return cmsImages.privateImage(res,id); }
      if (id && action==='image' && method==='PATCH') { permitted('cms.edit'); return send(200,cms.changeImage(user,id,await body(1400*1024))); }
      if (!action && method==='GET') { permitted('cms.view'); return send(200,id?cms.detail(id):cms.listAdmin(query)); }
      if (!id && method==='POST') { permitted('cms.create'); return send(201,cms.save(user,null,await body())); }
      if (id && !action && method==='PATCH') { permitted('cms.edit'); return send(200,cms.save(user,id,await body())); }
      if (id && action==='workflow' && method==='POST') return send(200,cms.transition(user,id,await body()));
    }
    if (section==='partners') {
      if (!action && method==='GET') { permitted('partners.view'); return send(200,id?partners.detail(id):partners.listAdmin(query)); }
      if (!id && method==='POST') { permitted('partners.create'); return send(201,partners.registerPartner(await body(),user)); }
      if (id && !action && method==='PATCH') { permitted('partners.edit'); return send(200,partners.edit(user,id,await body())); }
      if (id && action==='review' && method==='POST') { permitted('partners.approve'); return send(200,partners.review(user,id,await body())); }
    }
    if (section==='community') {
      if (!id && method==='GET') {
        permitted('community.view'); const type=one(query.type || 'post',['post','comment','flag']); const q=text(query.q || '',120);
        if (type==='flag') return send(200,page(query,"SELECT id,target_type,target_id,reason,status,created_at FROM community_flags WHERE status='open' ORDER BY created_at DESC,id"));
        const cols=type==='post'?'id,title,substr(body,1,200) AS excerpt,category,hidden,created_at':'id,post_id,substr(text,1,200) AS excerpt,hidden,created_at';
        const field=type==='post'?"title||' '||body":'text';
        return send(200,page(query,`SELECT ${cols} FROM ${targetTables[type]} WHERE (?='' OR instr(lower(${field}),lower(?))>0) ORDER BY created_at DESC,id`,[q,q]));
      }
      if (id && action && ['post','comment','flag'].includes(id)) {
        const table=targetTables[id];
        if (method==='GET' && table) {
          permitted('community.view');
          const cols=id==='post'?'id,title,body,category,hidden,created_at':'id,post_id,text,hidden,created_at';
          return send(200,existing(db.prepare(`SELECT ${cols} FROM ${table} WHERE id=?`).get(action)));
        }
        if (method==='PATCH') {
          permitted('community.edit'); const input=await body();
          return send(200,atomic(()=>{
            if (id==='flag') {
              const status=one(input.status,['dismissed','reviewed']);
              if (!db.prepare("UPDATE community_flags SET status=? WHERE id=? AND status='open'").run(status,action).changes) fail(404,'not_found');
              audit(user,'community_flag_reviewed',{flagId:action,status});
            } else {
              if (typeof input.hidden!=='boolean') fail(400,'invalid_input');
              const reason=one(input.reason,['privacy','harassment','spam','other']);
              if (!db.prepare(`UPDATE ${table} SET hidden=? WHERE id=?`).run(Number(input.hidden),action).changes) fail(404,'not_found');
              audit(user,'community_moderated',{type:id,contentId:action,hidden:input.hidden,reason});
            }
            return {success:true};
          }));
        }
      }
    }
    if (section==='audit' && !id && method==='GET') {
      permitted('audit.view');
      const category=one(query.category || 'all',['all','auth','incidents']);
      if(category==='incidents')permitted('incidents.view');
      const source=category==='auth'?authEvents:category==='incidents'?incidentEvents:has(user,'incidents.view')?`(${events} OR ${incidentEvents})`:events;
      return send(200,page(query,`SELECT id,action,actor_id,created_at FROM audit_logs WHERE ${source} ORDER BY id DESC`));
    }
    return send(404,{error:'not_found'});
  } catch (error) {
    if (error instanceof AdminError) return send(error.status,{error:error.message});
    console.error('Admin request failed:',error.code || error.name); return send(500,{error:'internal_error'});
  }
}
module.exports={routeAdmin, flagPublic};
