# AMAN Super Admin — implementation status

**Base**: public repository `hhvxvvf1-jpg/amanapp`, revision `76ae7c9dae57e2f086f59e9dd8be8ff2457c9675`. This is an extension of the existing Node HTTP router, SQLite data model, PWA and services. It is an operational foundation, **not the complete 19-section scope and not approved for real beneficiary data**.

## Implemented and exercised

| Area | Verified capability |
|---|---|
| Dashboard and analytics | SQLite account totals, registrations and trend, protected case/referral counts, organization and published-resource counts, week/month/year windows, permission-filtered tasks and recent activity, API/SQLite status, and aggregate CSV, XLSX and PDF. Age/sex account counts are not inferred from the existing schema. |
| Staff accounts and permissions | Filtered account list and detail; activate/suspend; operational role changes; revocation; trusted CLI provisioning and access recovery; one-time operational staff invitations from the web panel with verified TOTP enrollment; mandatory staff TOTP and replay protection; configurable per-role permission ceilings enforced on APIs. |
| Safeguarding and referrals | Group-scoped, assignment-scoped case queue; detail; sequential status transitions; assignment; notes and case activity; reasoned reopening; private audio; verified organization referrals and scoped partner responses. Super admins have no automatic case permission. |
| CMS and programs | Arabic/French/English draft editing, plain-text preview, independent review, scheduling, publish/unpublish, reversible archive, saved versions, and revision-safe restoration of text and illustration as a new draft. Published resources feed the public resources pages. Women and Child resources are separated by audience; Girls CMS resources require a configured age range. Public Girls detail and search use the same age-band rule. |
| CMS illustrations | One PNG per general-audience draft, trilingual alternative text, editorial preview, replacement/removal and history. Files are normalized without metadata and inherit independent review, the publication schedule and withdrawal. Do not upload identifying photos. |
| Girls quizzes | Existing quizzes migrated into the editor. Trilingual two-option drafts, full selected-age-band matching, independent approval, unpublish and archive. Answer feedback is evaluated server-side; individual answers are not kept. |
| Backup and recovery | Offline encrypted database/audio snapshots, verification, non-overwriting restore into a new directory, session revocation, and permissioned last-verified status. No web endpoint exposes the snapshot. |
| Partners and map | Create and edit profiles, review using documented evidence, reject/suspend, explicitly publish public information. Editing a verified profile returns it to review. No seeded pilot organizations are presented as verified. |
| Community | Report queue, post/comment detail, hide/restore, report review/dismissal, and removal from public API reads. This does not add an authenticated member identity model. |
| Operational finance | MAD budgets, grants, institutional contributions, expenses, maintenance and allocations. Revision-safe drafts, posting and reasoned voiding; filtered posted totals and protected CSV/XLSX and an aggregate-only PDF. No payments or integration with bank accounts. |
| Platform settings | Editable localized public name, bundled logo, accent palette and limited community maintenance mode. Reporting, safety resources and emergency guidance are not disabled by the maintenance toggle. |
| Assistant operations | Configure supported reply languages and availability for the connected assistant; observe seven-day aggregate counters and test synthetic prompts. Approve published general-audience CMS resources for display alongside responses. Unpublished or age-restricted items are excluded. |
| Security incidents | Manually record platform incidents as coded metadata; filter the queue, triage, contain, resolve, review independently, close or reopen. Dedicated permissions, dashboard count and audit timeline. No narrative fields, beneficiary links or automatic monitoring. |
| Staff notices | Localized in-app templates, staff/safeguarding/verified partner scopes, inbox, read acknowledgements and withdrawal. No beneficiary recipients and no email, SMS or push. |
| Audit and interface | Redacted audit/login activity; responsive purple/gold staff interface, search, filters, pagination, confirmations, empty/error states and Arabic RTL. Some legacy content and diagnostic identifiers remain source language. |

## Not implemented or not production-ready

- No external AI providers, private document ingestion or editable safeguarding decision rules. No outbound notification delivery or editable free-text templates. Platform settings do not replace hard-coded homepage/footer/navigation, emergency numbers or policy pages. No accounting integrations, bank reconciliation, or automated backup/restore telemetry.
- CMS does not yet replace the hard-coded home, menu, footer, legal libraries, or all existing content. No video upload, document workflow, or automatic verification of source evidence. Snapshots start at the version present during migration; earlier bodies and images cannot be reconstructed. No permanent media purge or revision retention scheduler. Age selection remains self-declared; controls on CMS resources do not establish platform-wide verified age enforcement. Do not use age bands as a security boundary for private material.
- No regional or longitudinal safeguarding analytics, supervised referral sharing of confidential records, full user activity exports, or partner-level assignment management. Public community identity restriction and pre-publication review remain open requirements.
- Security audit includes event views, not external immutable logging, automated incident detection or external escalation, device-specific session management, independent penetration testing, or a privacy review of longitudinal statistical differencing. Existing pre-migration records need separate handling; see `DEPLOYMENT.md`.
- Public and admin production hosting, disclosure/retention policies, partner verification, and Moroccan Law 09-08 / CNDP requirements must be settled before real intake is enabled.

## Modified areas

- `admin/`: new authenticated staff UI, localized labels and responsive layouts.
- `src/admin/`: route dispatcher, explicit permissions, MFA, and audited validation/paging primitives.
- `src/db/`: schema startup integration and versioned admin migrations.
- `src/services/`: existing auth, cases, partners/referrals, CMS, Girls library, community, and analytics adapted to the new permissions and workflows.
- `server.js`, `src/middleware/`, `sw.js`: API integration, static serving allowlist, request limits and cache protection.
- `app-ecosystem.js`, `app-girls.js`, `community.js`, `index.html`: public integration without replacing the home page or existing design.
- `scripts/`, `.github/workflows/`, `.env.example`, `package.json`: staff enrollment, Pages asset staging, and environment/run configuration.
- `tests/`: isolated SQLite integration fixtures and optional Chromium smoke test. No real people, reports or audio used in tests.

See [deployment](DEPLOYMENT.md) and [API contracts](ADMIN-API.md).
