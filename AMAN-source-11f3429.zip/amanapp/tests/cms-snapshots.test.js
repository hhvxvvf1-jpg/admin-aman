const test=require('node:test');
const assert=require('node:assert/strict');
const {fixture}=require('./fixture');
const {picture}=require('./png-fixture');
const old={slug:'synthetic-revision',audience:'general',contentType:'education',titleAr:'نسخة قديمة',titleFr:'Ancienne version fictive',titleEn:'Original sample title',bodyAr:'النص الأصلي',bodyFr:'Texte d’origine',bodyEn:'Original sample body'};
const fields={altAr:'صورة توضيحية',altFr:'Illustration fictive',altEn:'Example illustration'};

test('CMS snapshots restore text and artwork into a new private revision without reviving an old image URL',async t=>{
 const {request,create,openDb}=await fixture(t);
 const author=await create('content_manager').login(), approver=await create('super_admin').login(), outsider=await create('girls_caseworker').login();
 const {data:item}=await request('/api/admin/cms','POST',old,author);const route=`/api/admin/cms/${item.id}`;
 const exec=(relative='',method='GET',body,token=author)=>request(route+relative,method,body,token);
 const save=await exec('/image','PATCH',{...fields,png:picture().toString('base64'),revision:item.revision});assert.equal(save.status,200);
 const rev=save.data.revision,oldImageId=save.data.image.id;
 const changed=await exec('','PATCH',{...old,titleEn:'Newer fictional title',bodyEn:'Newer fictional body',revision:rev});assert.equal(changed.status,200);
 const remove=await exec('/image','PATCH',{remove:true,revision:changed.data.revision});assert.equal(remove.status,200);
 const entries=await exec('/snapshots');assert.deepEqual(entries.data.items.map(x=>x.revision),[4,3,2,1]);assert.equal(entries.data.items[1].has_image,1);
 const prior=await exec(`/snapshots?revision=${rev}`);assert.equal(prior.data.title_en,old.titleEn);assert.equal(prior.data.image.alt_ar,fields.altAr);
 assert.equal((await exec(`/snapshots?revision=${rev}`,'GET',undefined,outsider)).status,403);
 const bytes=await exec(`/snapshot-image?revision=${rev}`);assert.equal(bytes.status,200);assert.equal(bytes.headers.get('cache-control'),'no-store');
 assert.equal((await request('/api/cms/images/'+oldImageId)).status,404);
 assert.equal((await exec('/snapshots','POST',{revision:3,targetRevision:rev})).status,409);
 const restored=await exec('/snapshots','POST',{revision:remove.data.revision,targetRevision:rev},approver);assert.equal(restored.status,200);
 assert.equal(restored.data.revision,5);assert.equal(restored.data.review_status,'draft');assert.equal(restored.data.title_en,old.titleEn);assert.equal(restored.data.publish_at,null);assert.notEqual(restored.data.image.id,oldImageId);
 assert.deepEqual((await exec('/image')).data,bytes.data);
 const submitted=(await exec('/workflow','POST',{action:'submit',revision:5})).data;
 assert.equal((await exec('/snapshots','POST',{revision:submitted.revision,targetRevision:rev},approver)).status,409);
 assert.equal((await exec('/workflow','POST',{action:'publish',revision:submitted.revision},approver)).data.error,'independent_reviewer_required');
 const db=openDb();const audit=JSON.parse(db.prepare("SELECT details FROM audit_logs WHERE action='cms_snapshot_restored'").get().details);assert.equal(audit.restoredRevision,rev);assert.doesNotMatch(JSON.stringify(audit),/sample body/);db.close();
});

test('saved versions cannot silently change a child audience or broaden its age range',async t=>{
 const {request,create}=await fixture(t);const author=await create('content_manager').login();
 const input={...old,audience:'girls',minAge:10,maxAge:17};const {data:item}=await request('/api/admin/cms','POST',input,author);const route=`/api/admin/cms/${item.id}`;
 const narrow=await request(route,'PATCH',{...input,minAge:13,maxAge:15,revision:item.revision},author);assert.equal(narrow.status,200);
 const invalid=await request(route+'/snapshots','POST',{revision:narrow.data.revision,targetRevision:item.revision},author);
 assert.equal(invalid.status,409);assert.equal(invalid.data.error,'cms_snapshot_scope_mismatch');
 assert.equal((await request(route+'/snapshots?revision=two','GET',undefined,author)).status,400);
 assert.equal((await request(route,'GET',undefined,author)).data.min_age,13);
});
